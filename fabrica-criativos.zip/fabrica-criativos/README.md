# Fábrica de Criativos — motor de edição

Modelos de edição em Remotion. O editor entrega o vídeo bruto; o pipeline corta pausas, enquadra em 9:16, normaliza o áudio, legenda e aplica o modelo com o kit da marca.

## Estrutura

- `src/modelos/fala-legendada/` — modelo **Fala legendada v1** (legenda dinâmica, gancho, logo, tarja legal, cartela de CTA, punch-in de zoom).
- `src/kit.ts` — formato do kit de marca.
- `public/kits/<marca>/kit.json` — cores, logo e aviso legal de cada marca.
- `public/jobs/<id>/` — arquivos de cada edição (vídeo limpo, legendas, mapa de cortes, props).
- `scripts/editar.mjs` — pipeline completo.
- `scripts/transcrever.mjs` e `scripts/instalar-whisper.mjs` — transcrição local com Whisper.

## Uso

```bash
npm i
node scripts/instalar-whisper.mjs        # uma vez por máquina (precisa de github.com e huggingface.co)

node scripts/editar.mjs \
  --video bruto.mp4 --marca exemplo \
  --gancho "Você está pagando caro demais" \
  --cta-titulo "Assine o clube" --cta-subtitulo "Link na bio" \
  --destaques "economizar,30%" --zooms "2600,7200"
```

Opções: `--legendas arquivo.json` (pula a transcrição e usa legendas prontas, reajustadas aos cortes), `--pausa-min 0.4` (silêncio mínimo que vira corte), `--sem-cortes`, `--sem-render`, `--id nome`.

Saída: `out/<marca>_fala-legendada-v1_<id>.mp4` (1080x1920, H.264).

## Pré-visualização

```bash
npx remotion studio
```

## Licença

Remotion é gratuito para equipes de até 3 pessoas; acima disso exige licença de empresa (remotion.pro).

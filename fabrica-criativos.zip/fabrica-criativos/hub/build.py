#!/usr/bin/env python3
"""Monta o Hub OTG: junta o portal da Fábrica (portal/index.html) ao molde do hub.
Saídas: hub/artifact.html (para publicar como Artifact) e hub/index.html (página completa,
para abrir no navegador ou hospedar; é nela que as chamadas de API funcionam)."""
import re, pathlib
raiz = pathlib.Path(__file__).resolve().parent.parent
portal = (raiz / "portal/index.html").read_text(encoding="utf8")
css = re.search(r"<style>(.*?)</style>", portal, re.S).group(1)
js = re.search(r"<script>(.*?)</script>", portal, re.S).group(1)
html = portal[portal.index("</style>") + 8 : portal.index("<script>")]
tpl = (raiz / "hub/hub.tpl.html").read_text(encoding="utf8")
out = tpl.replace("/*{{CSS_FABRICA}}*/", css).replace("<!--{{HTML_FABRICA}}-->", html).replace("/*{{JS_FABRICA}}*/", js)
(raiz / "hub/artifact.html").write_text(out, encoding="utf8")
cabeca, corpo = out[: out.index("<div class=\"hub\">")], out[out.index("<div class=\"hub\">") :]
(raiz / "hub/index.html").write_text(
    '<!doctype html>\n<html lang="pt-BR">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
    "<style>body{margin:0}[hidden]{display:none!important}img{max-width:100%}</style>\n" + cabeca + "</head>\n<body>\n" + corpo + "\n</body>\n</html>\n", encoding="utf8")
# cópia limpa para hospedar (Vercel: Root Directory = site)
(raiz / "site").mkdir(exist_ok=True)
(raiz / "site/index.html").write_text((raiz / "hub/index.html").read_text(encoding="utf8"), encoding="utf8")
print("ok", len(out))

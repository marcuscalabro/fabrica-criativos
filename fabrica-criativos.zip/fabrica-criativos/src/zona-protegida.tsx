// ---------------------------------------------------------------------------
// REGRA PRIMORDIAL DA FÁBRICA
// Nenhum texto, imagem, print, sticker, legenda ou elemento gráfico pode ficar
// na frente do rosto do expert. O rosto é detectado no vídeo
// (scripts/detectar-rosto.py -> rostos.json) e vira uma ZONA PROTEGIDA; todo
// modelo posiciona seus elementos fora dela, em todos os quadros.
// ---------------------------------------------------------------------------
import { z } from "zod";
import { AbsoluteFill } from "remotion";

export const rostosSchema = z
  .object({
    largura: z.number(),
    altura: z.number(),
    intervaloMs: z.number().optional(),
    amostras: z.array(
      z.object({
        tMs: z.number(),
        rosto: z.array(z.number()).length(4),
        zona: z.array(z.number()).length(4),
      }),
    ),
    uniao: z.array(z.number()).length(4).nullable(),
  })
  .nullable()
  .optional();

export type Rostos = z.infer<typeof rostosSchema>;
export type Caixa = { x: number; y: number; w: number; h: number };

const caixa = (a: number[]): Caixa => ({ x: a[0], y: a[1], w: a[2], h: a[3] });
export const fundo = (c: Caixa) => c.y + c.h;

export const intersecta = (a: Caixa, b: Caixa, folga = 0) =>
  a.x < b.x + b.w + folga && b.x < a.x + a.w + folga && a.y < b.y + b.h + folga && b.y < a.y + a.h + folga;

// União das zonas protegidas num intervalo de tempo (ms). null = sem rosto.
export function zonaNoIntervalo(rostos: Rostos, ms0: number, ms1: number): Caixa | null {
  if (!rostos || !rostos.amostras.length) return null;
  const meio = rostos.intervaloMs ?? 170;
  const dentro = rostos.amostras.filter((a) => a.tMs >= ms0 - meio && a.tMs <= ms1 + meio);
  const usar = dentro.length
    ? dentro
    : [rostos.amostras.reduce((m, a) => (Math.abs(a.tMs - ms0) < Math.abs(m.tMs - ms0) ? a : m))];
  const zs = usar.map((a) => caixa(a.zona));
  const x0 = Math.min(...zs.map((z) => z.x));
  const y0 = Math.min(...zs.map((z) => z.y));
  const x1 = Math.max(...zs.map((z) => z.x + z.w));
  const y1 = Math.max(...zs.map((z) => z.y + z.h));
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}

export const zonaDoVideo = (rostos: Rostos): Caixa | null =>
  rostos?.uniao ? caixa(rostos.uniao) : null;

export const deslocar = (c: Caixa | null, dy: number): Caixa | null => (c ? { ...c, y: c.y + dy } : null);

/**
 * Escolhe a posição vertical (topo, em px) de um elemento de altura `altura`
 * que precisa ficar fora de todos os `obstaculos`. Tenta primeiro a posição
 * preferida; depois logo abaixo e logo acima de cada obstáculo; por fim a
 * faixa livre mais alta. Retorna também se coube sem encostar em nada.
 */
export function posicaoLivre(
  altura: number,
  preferido: number,
  obstaculos: (Caixa | null)[],
  limites: { min: number; max: number; folga?: number },
): { y: number; cabe: boolean } {
  const folga = limites.folga ?? 30;
  const obs = obstaculos.filter(Boolean) as Caixa[];
  const livre = (y: number) =>
    y >= limites.min &&
    y + altura <= limites.max &&
    obs.every((o) => y + altura + folga <= o.y || y >= o.y + o.h + folga);
  const candidatos = [
    preferido,
    ...obs.flatMap((o) => [o.y + o.h + folga, o.y - folga - altura]),
    limites.min,
    limites.max - altura,
  ].sort((a, b) => Math.abs(a - preferido) - Math.abs(b - preferido));
  const ok = candidatos.find(livre);
  if (ok !== undefined) return { y: ok, cabe: true };

  // não coube inteiro: usa o maior vão livre (o elemento deve encolher para caber)
  const cortes = [limites.min, ...obs.flatMap((o) => [o.y - folga, o.y + o.h + folga]), limites.max]
    .map((v) => Math.min(limites.max, Math.max(limites.min, v)))
    .sort((a, b) => a - b);
  let melhor = { y: limites.min, h: 0 };
  for (let i = 0; i < cortes.length - 1; i++) {
    const a = cortes[i];
    const b = cortes[i + 1];
    const meio = (a + b) / 2;
    const bloqueado = obs.some((o) => meio > o.y - folga && meio < o.y + o.h + folga);
    if (!bloqueado && b - a > melhor.h) melhor = { y: a, h: b - a };
  }
  return { y: melhor.y, cabe: false };
}

// Contorno da zona protegida, para conferência (prop mostrarZona)
export const ZonaDebug: React.FC<{ zona: Caixa | null; rotulo?: string }> = ({ zona, rotulo = "ZONA PROTEGIDA · ROSTO" }) =>
  zona ? (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <div
        style={{
          position: "absolute",
          left: zona.x,
          top: zona.y,
          width: zona.w,
          height: zona.h,
          border: "6px dashed #FF2D2D",
          backgroundColor: "rgba(255,45,45,0.10)",
          borderRadius: 24,
        }}
      >
        <div
          style={{
            position: "absolute",
            left: 16,
            top: 16,
            backgroundColor: "#FF2D2D",
            color: "white",
            fontFamily: "Inter",
            fontWeight: 700,
            fontSize: 26,
            padding: "6px 14px",
            borderRadius: 8,
          }}
        >
          {rotulo}
        </div>
      </div>
    </AbsoluteFill>
  ) : null;

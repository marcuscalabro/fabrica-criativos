import { Composition } from "remotion";
import {
  FalaLegendada,
  calcularMetadata,
  falaLegendadaSchema,
  type FalaLegendadaProps,
} from "./modelos/fala-legendada/FalaLegendada";
import exemplo from "../public/jobs/exemplo/props.json";

// Cada modelo de edição é uma Composition. O pipeline renderiza passando
// as props do job (vídeo limpo, legendas, textos, kit da marca).
export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="FalaLegendada"
      component={FalaLegendada}
      schema={falaLegendadaSchema}
      calculateMetadata={calcularMetadata}
      durationInFrames={300}
      fps={30}
      width={1080}
      height={1920}
      defaultProps={exemplo as FalaLegendadaProps}
    />
  );
};

import { z } from "zod";
import { zColor } from "@remotion/zod-types";
import { loadFont } from "@remotion/fonts";
import { staticFile } from "remotion";

// Kit de marca: tudo que é identidade fica aqui, fora do modelo.
// O mesmo modelo serve qualquer marca trocando só o kit.
export const kitSchema = z.object({
  id: z.string(),
  nome: z.string(),
  corPrimaria: zColor(), // fundo do gancho e da cartela final
  corDestaque: zColor(), // palavra falada e palavras de destaque
  corTextoSobrePrimaria: zColor(),
  logo: z.string().nullable(), // caminho dentro de public/, ex.: "kits/tylty/logo.png"
  avisoLegal: z.string().nullable(), // tarja fixa (ex.: +18), o editor não remove
});

export type Kit = z.infer<typeof kitSchema>;

export const FONTE = "Montserrat";

// Fontes locais (o render não depende de internet).
const FONTES: { family: string; arquivo: string; weight: string; style?: string }[] = [
  { family: "Montserrat", arquivo: "montserrat-latin-600-normal", weight: "600" },
  { family: "Montserrat", arquivo: "montserrat-latin-800-normal", weight: "800" },
  { family: "Montserrat", arquivo: "montserrat-latin-900-normal", weight: "900" },
  { family: "Anton", arquivo: "anton-latin-400-normal", weight: "400" },
  { family: "Inter", arquivo: "inter-latin-500-normal", weight: "500" },
  { family: "Inter", arquivo: "inter-latin-700-normal", weight: "700" },
  { family: "Inter", arquivo: "inter-latin-400-normal", weight: "400" },
  { family: "Inter", arquivo: "inter-latin-800-normal", weight: "800" },
  { family: "Inter", arquivo: "inter-latin-900-normal", weight: "900" },
  { family: "Inter", arquivo: "inter-latin-900-italic", weight: "900", style: "italic" },
  { family: "Playfair Display", arquivo: "playfair-display-latin-600-normal", weight: "600" },
  { family: "Playfair Display", arquivo: "playfair-display-latin-700-normal", weight: "700" },
  { family: "Playfair Display", arquivo: "playfair-display-latin-700-italic", weight: "700", style: "italic" },
];

export const fontesProntas = Promise.all(
  FONTES.map((f) =>
    loadFont({
      family: f.family,
      url: staticFile(`fonts/${f.arquivo}.woff2`),
      weight: f.weight,
      style: f.style ?? "normal",
    }),
  ),
);

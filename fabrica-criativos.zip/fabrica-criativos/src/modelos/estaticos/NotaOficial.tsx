import { z } from "zod";
import { AbsoluteFill, Img, staticFile, useVideoConfig, type CalculateMetadataFunction } from "remotion";
import { fontesProntas, kitSchema } from "../../kit";
import { AvisoCartao, FORMATOS, Marcado, avisoSchema, formatoSchema, useMedida } from "./comum";

// ---------------------------------------------------------------------------
// Modelo estático "Nota oficial" v1
// Imita um comunicado oficial (do próprio expert / grupo, nunca de terceiros):
// emblema, título NOTA OFICIAL, data, corpo, assinatura, CTA e aviso legal.
// O conteúdo se ajusta sozinho a 9:16, 4:5 e 1:1.
// ---------------------------------------------------------------------------

export const notaOficialSchema = z.object({
  formato: formatoSchema,
  titulo: z.string().default("NOTA OFICIAL"),
  data: z.string(), // ex.: "3 de novembro de 2026"
  paragrafos: z.array(z.string()), // **palavra** = cor de destaque
  assinatura: z.object({
    nome: z.string(),
    cargo: z.string().optional(),
    iniciais: z.string().optional(), // emblema quando não há logo
  }),
  cta: z.string().optional(),
  corDestaque: z.string().optional(),
  aviso: avisoSchema,
  kit: kitSchema,
});
export type NotaOficialProps = z.input<typeof notaOficialSchema>;

export const calcularMetadataNota: CalculateMetadataFunction<NotaOficialProps> = async ({ props }) => {
  await fontesProntas;
  return { ...FORMATOS[props.formato], durationInFrames: 1, defaultOutName: `nota-oficial-${props.formato.replace(":", "x")}` };
};

export const NotaOficial: React.FC<NotaOficialProps> = (props) => {
  const { height } = useVideoConfig();
  const cor = props.corDestaque || props.kit.corDestaque;
  const { ref, altura } = useMedida<HTMLDivElement>();
  const margem = height > 1500 ? 110 : 70;
  const espacoAviso = 150;
  const disponivel = height - margem * 2 - espacoAviso;
  const escala = altura ? Math.min(1, disponivel / altura) : 1;
  const sobra = altura ? Math.max(0, disponivel - altura * escala) : 0;

  return (
    <AbsoluteFill
      style={{
        backgroundColor: "#0A0A0B",
        backgroundImage: `radial-gradient(ellipse 90% 55% at 50% 0%, ${cor}22 0%, rgba(0,0,0,0) 70%), repeating-linear-gradient(135deg, rgba(255,255,255,0.025) 0px, rgba(255,255,255,0.025) 2px, transparent 2px, transparent 14px)`,
      }}
    >
      {/* filetes de topo e base */}
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 10, backgroundColor: cor }} />
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 10, backgroundColor: cor }} />

      <div
        ref={ref}
        style={{
          position: "absolute",
          top: margem + sobra * 0.45,
          left: 90,
          right: 90,
          scale: escala,
          transformOrigin: "top center",
          opacity: altura === null ? 0 : 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {/* emblema */}
        {props.kit.logo ? (
          <Img src={staticFile(props.kit.logo)} style={{ height: 140, width: "auto", marginBottom: 34 }} />
        ) : (
          <div
            style={{
              width: 150,
              height: 150,
              borderRadius: 999,
              border: `5px solid ${cor}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontFamily: "Instrument Serif",
              fontStyle: "italic",
              fontSize: 76,
              color: cor,
              marginBottom: 34,
              boxShadow: `0 0 40px ${cor}33`,
            }}
          >
            {props.assinatura.iniciais ?? props.assinatura.nome.slice(0, 2)}
          </div>
        )}

        <div style={{ fontFamily: "Bebas Neue", fontSize: 170, lineHeight: 0.9, color: "white", letterSpacing: 4 }}>
          {props.titulo}
        </div>
        <div style={{ width: 180, height: 6, backgroundColor: cor, margin: "22px 0 18px", borderRadius: 3 }} />
        <div style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 30, color: "#9A9AA2", letterSpacing: 1 }}>
          {props.data}
        </div>

        <div style={{ marginTop: 56, display: "flex", flexDirection: "column", gap: 34, width: "100%" }}>
          {props.paragrafos.map((p, i) => (
            <div
              key={i}
              style={{ fontFamily: "Inter", fontWeight: 500, fontSize: 42, lineHeight: 1.42, color: "#E9E9EC", textAlign: "left" }}
            >
              <Marcado texto={p} corDestaque={cor} peso={700} />
            </div>
          ))}
        </div>

        <div style={{ alignSelf: "flex-start", marginTop: 54 }}>
          <div style={{ fontFamily: "Instrument Serif", fontStyle: "italic", fontSize: 76, lineHeight: 1, color: cor }}>
            {props.assinatura.nome}
          </div>
          {props.assinatura.cargo ? (
            <div style={{ fontFamily: "Inter", fontWeight: 600, fontSize: 28, color: "#9A9AA2", marginTop: 10 }}>
              {props.assinatura.cargo}
            </div>
          ) : null}
        </div>

        {props.cta ? (
          <div
            style={{
              marginTop: 60,
              fontFamily: "Bebas Neue",
              fontSize: 62,
              letterSpacing: 1,
              color: "#111",
              backgroundColor: cor,
              padding: "14px 54px 8px",
              borderRadius: 999,
              boxShadow: `0 0 34px ${cor}55`,
            }}
          >
            {props.cta}
          </div>
        ) : null}
      </div>

      <div style={{ position: "absolute", left: 70, right: 70, bottom: margem * 0.6 + 10 }}>
        <AvisoCartao aviso={props.aviso} compacto={height < 1500} />
      </div>
    </AbsoluteFill>
  );
};

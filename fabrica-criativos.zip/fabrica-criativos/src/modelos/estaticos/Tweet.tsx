import { z } from "zod";
import { AbsoluteFill, Img, staticFile, useVideoConfig, type CalculateMetadataFunction } from "remotion";
import { fontesProntas, kitSchema } from "../../kit";
import { ZonaDebug, rostosSchema } from "../../zona-protegida";
import { FORMATOS, formatoSchema, useMedida } from "./comum";

// ---------------------------------------------------------------------------
// Modelo estático "Tweet" v2 — fiel ao padrão real dos estáticos OTG
// (referências em docs/estaticos-otg.md):
//  - fundo liso (branco por padrão), conteúdo centralizado na zona segura
//    (topo e base do 9:16 ficam vazios, por causa da interface do Reels/Stories)
//  - cabeçalho de perfil (avatar, nome, selo, @) e texto em 2 níveis:
//    manchete em CAIXA ALTA + corpo com trechos em negrito / marcador colorido
//  - foto do expert num QUADRO SEPARADO (cantos arredondados) — nada sobrepõe a
//    foto, então a regra do rosto é cumprida por construção; o enquadramento
//    usa a zona do rosto para nunca cortar o rosto
//  - botão de CTA retangular cheio + aviso legal em linha com o selo +18
// ---------------------------------------------------------------------------

const imagemSchema = z.object({
  src: z.string(),
  rostos: rostosSchema, // opcional: centraliza o recorte no rosto
  posicao: z.string().optional(), // objectPosition manual (ex.: "50% 30%")
});

export const tweetSchema = z.object({
  formato: formatoSchema,
  variante: z.enum(["perfil", "manchete"]).default("perfil"),
  // perfil   = avatar pequeno + nome/@ em cima; manchete e corpo abaixo
  // manchete = avatar grande à esquerda; manchete sublinhada ao lado do avatar
  tema: z.enum(["claro", "escuro"]).default("claro"),
  autor: z.object({
    nome: z.string(),
    usuario: z.string().optional(),
    avatar: z.string().optional(),
    verificado: z.boolean().default(true),
  }),
  manchete: z.string().optional(), // CAIXA ALTA
  corpo: z.string().optional(), // **negrito**  ==marcador colorido==  \n quebra
  midia: z
    .object({
      imagens: z.array(imagemSchema).min(1).max(2),
      altura: z.number().default(480),
    })
    .optional(),
  cta: z
    .object({
      texto: z.string(),
      fundo: z.string().default("#E31212"),
      cor: z.string().default("#FFFFFF"),
    })
    .optional(),
  corMarcador: z.string().default("#FF1A00"),
  aviso: z.string().optional(),
  mostrarZona: z.boolean().optional(),
  kit: kitSchema,
});
export type TweetProps = z.input<typeof tweetSchema>;

export const AVISO_PADRAO =
  "Jogue com responsabilidade. Palpite não é investimento. Esse conteúdo segue todas as diretrizes impostas pela regulamentação e é um conteúdo publicitário sobre jogo responsável. Ganhos passados não garantem ganhos futuros.";

export const calcularMetadataTweet: CalculateMetadataFunction<TweetProps> = async ({ props }) => {
  await fontesProntas;
  return { ...FORMATOS[props.formato], durationInFrames: 1, defaultOutName: `tweet-${props.formato.replace(":", "x")}` };
};

// "**negrito**" e "==marcador==" -> spans
const Rico: React.FC<{ texto: string; corMarcador: string; corTextoMarcador: string }> = ({ texto, corMarcador, corTextoMarcador }) => (
  <>
    {texto.split("\n").map((linha, i) => (
      <div key={i}>
        {linha
          .split(/(\*\*[^*]+\*\*|==[^=]+==)/g)
          .filter(Boolean)
          .map((p, j) =>
            p.startsWith("**") ? (
              <b key={j} style={{ fontWeight: 800 }}>
                {p.slice(2, -2)}
              </b>
            ) : p.startsWith("==") ? (
              <span
                key={j}
                style={{ backgroundColor: corMarcador, color: corTextoMarcador, fontWeight: 800, padding: "0 8px", boxDecorationBreak: "clone", WebkitBoxDecorationBreak: "clone" }}
              >
                {p.slice(2, -2)}
              </span>
            ) : (
              <span key={j}>{p}</span>
            ),
          )}
      </div>
    ))}
  </>
);

const Selo: React.FC<{ tamanho: number }> = ({ tamanho }) => (
  <svg width={tamanho} height={tamanho} viewBox="0 0 24 24" style={{ flexShrink: 0 }}>
    <path
      fill="#1D9BF0"
      d="M22.25 12c0-1.43-.88-2.67-2.19-3.34.46-1.39.2-2.9-.81-3.91s-2.52-1.27-3.91-.81C14.67 2.63 13.43 1.75 12 1.75s-2.67.88-3.34 2.19c-1.39-.46-2.9-.2-3.91.81s-1.27 2.52-.81 3.91C2.63 9.33 1.75 10.57 1.75 12s.88 2.67 2.19 3.34c-.46 1.39-.2 2.9.81 3.91s2.52 1.27 3.91.81c.67 1.31 1.91 2.19 3.34 2.19s2.67-.88 3.34-2.19c1.39.46 2.9.2 3.91-.81s1.27-2.52.81-3.91c1.31-.67 2.19-1.91 2.19-3.34z"
    />
    <path fill="#fff" d="M10.54 16.2 6.8 12.46l1.41-1.41 2.33 2.33 5.24-5.24 1.41 1.41z" />
  </svg>
);

// enquadra a foto pelo rosto: objectPosition com o centro do rosto
function posicaoPeloRosto(img: z.infer<typeof imagemSchema>) {
  if (img.posicao) return img.posicao;
  const r = img.rostos;
  if (!r?.uniao) return "50% 30%";
  const [x, y, w, h] = r.uniao;
  const cx = ((x + w / 2) / r.largura) * 100;
  const cy = ((y + h / 2) / r.altura) * 100;
  return `${cx.toFixed(1)}% ${cy.toFixed(1)}%`;
}

export const AvisoLinha: React.FC<{ texto: string; cor: string; tamanho?: number }> = ({ texto, cor, tamanho = 17 }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 10, color: cor, fontFamily: "Inter", fontWeight: 400 }}>
    <div
      style={{
        width: tamanho * 2.05,
        height: tamanho * 2.05,
        borderRadius: 999,
        border: `2px solid ${cor}`,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontWeight: 800,
        fontSize: tamanho * 0.88,
        letterSpacing: -1,
        flexShrink: 0,
      }}
    >
      +18
    </div>
    <div style={{ fontSize: tamanho, lineHeight: 1.18 }}>{texto}</div>
  </div>
);

export const Tweet: React.FC<TweetProps> = (props) => {
  const { width, height } = useVideoConfig();
  const claro = (props.tema ?? "claro") === "claro";
  const corFundo = claro ? "#FFFFFF" : "#000000";
  const corTexto = claro ? "#141414" : "#F2F2F2";
  const corSec = claro ? "#5E5E5E" : "#9A9A9A";
  const variante = props.variante ?? "perfil";
  const { ref, altura } = useMedida<HTMLDivElement>();

  // zona segura vertical (9:16: topo/base ficam livres para a interface do app)
  const vertical = height > 1500;
  const zonaTopo = vertical ? 380 : 70;
  const zonaBase = vertical ? height - 380 : height - 70;
  const disponivel = zonaBase - zonaTopo;
  const escala = altura ? Math.min(1, disponivel / altura) : 1;
  const topo = altura ? zonaTopo + (disponivel - altura * escala) / 2 : zonaTopo;
  const margem = 84;
  const larguraBloco = width - margem * 2;

  const nome = (tamanho: number, comUsuario: boolean) => (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ fontWeight: 700, fontSize: tamanho, color: corTexto, lineHeight: 1.15 }}>{props.autor.nome}</span>
        {props.autor.verificado !== false ? <Selo tamanho={tamanho * 0.85} /> : null}
      </div>
      {comUsuario && props.autor.usuario ? (
        <div style={{ fontWeight: 400, fontSize: tamanho * 0.78, color: corSec, lineHeight: 1.2 }}>{props.autor.usuario}</div>
      ) : null}
    </div>
  );
  const avatar = (tamanho: number) =>
    props.autor.avatar ? (
      <Img src={staticFile(props.autor.avatar)} style={{ width: tamanho, height: tamanho, borderRadius: 999, objectFit: "cover", flexShrink: 0 }} />
    ) : (
      <div style={{ width: tamanho, height: tamanho, borderRadius: 999, backgroundColor: props.kit.corDestaque, flexShrink: 0 }} />
    );
  const corpo = (tamanho: number) =>
    props.corpo ? (
      <div style={{ fontWeight: 400, fontSize: tamanho, lineHeight: 1.38, color: corTexto, letterSpacing: -0.4 }}>
        <Rico texto={props.corpo} corMarcador={props.corMarcador ?? "#FF1A00"} corTextoMarcador={claro ? "#141414" : "#FFFFFF"} />
      </div>
    ) : null;

  return (
    <AbsoluteFill style={{ backgroundColor: corFundo, fontFamily: "Inter" }}>
      <div
        ref={ref}
        style={{
          position: "absolute",
          top: topo,
          left: margem,
          width: larguraBloco,
          scale: escala,
          transformOrigin: "top center",
          opacity: altura === null ? 0 : 1,
          display: "flex",
          flexDirection: "column",
        }}
      >
        {variante === "perfil" ? (
          <>
            <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
              {avatar(80)}
              {nome(38, true)}
            </div>
            <div style={{ marginTop: 40, display: "flex", flexDirection: "column", gap: 6 }}>
              {props.manchete ? (
                <div style={{ fontWeight: 800, fontSize: 37, lineHeight: 1.25, color: corTexto, textTransform: "uppercase", letterSpacing: 0.2 }}>
                  {props.manchete}
                </div>
              ) : null}
              {corpo(35)}
            </div>
          </>
        ) : (
          <>
            <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
              {avatar(166)}
              <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 0 }}>
                {nome(34, false)}
                {props.manchete ? (
                  <div style={{ fontWeight: 800, fontSize: 38, lineHeight: 1.5, color: corTexto, textTransform: "uppercase", letterSpacing: -0.3 }}>
                    {/* cada linha sublinhada, como no padrão */}
                    <span style={{ textDecoration: "underline", textDecorationThickness: 3, textUnderlineOffset: 12 }}>{props.manchete}</span>
                  </div>
                ) : null}
              </div>
            </div>
            <div style={{ marginTop: 18 }}>{corpo(44)}</div>
          </>
        )}

        {props.midia ? (
          <div
            style={{
              marginTop: 30,
              height: props.midia.altura ?? 480,
              display: "flex",
              gap: 4,
              borderRadius: 14,
              overflow: "hidden",
              border: claro ? "1.5px solid #9C9C9C" : "1.5px solid #333",
            }}
          >
            {props.midia.imagens.map((img, i) => (
              <Img key={i} src={staticFile(img.src)} style={{ flex: 1, minWidth: 0, height: "100%", objectFit: "cover", objectPosition: posicaoPeloRosto(img) }} />
            ))}
          </div>
        ) : null}

        {props.cta ? (
          <div
            style={{
              marginTop: 38,
              height: 78,
              borderRadius: 8,
              backgroundColor: props.cta.fundo ?? "#E31212",
              color: props.cta.cor ?? "#FFFFFF",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 900,
              fontSize: 39,
              letterSpacing: 0.3,
              textTransform: "uppercase",
              whiteSpace: "nowrap",
            }}
          >
            {props.cta.texto}
          </div>
        ) : null}

        <div style={{ marginTop: 44, marginLeft: -6, marginRight: -6 }}>
          <AvisoLinha texto={props.aviso ?? AVISO_PADRAO} cor={claro ? "#1A1A1A" : "#EDEDED"} />
        </div>
      </div>

      {props.mostrarZona ? <ZonaDebug zona={{ x: 0, y: zonaTopo, w: width, h: disponivel }} /> : null}
    </AbsoluteFill>
  );
};

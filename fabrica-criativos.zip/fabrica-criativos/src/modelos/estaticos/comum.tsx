// Peças comuns dos modelos estáticos (Nota oficial, Tweet...).
import { useLayoutEffect, useRef, useState } from "react";
import { useDelayRender } from "remotion";
import { z } from "zod";
import { fontesProntas } from "../../kit";

export const FORMATOS = {
  "9:16": { width: 1080, height: 1920 },
  "4:5": { width: 1080, height: 1350 },
  "1:1": { width: 1080, height: 1080 },
} as const;
export const formatoSchema = z.enum(["9:16", "4:5", "1:1"]);
export type Formato = z.infer<typeof formatoSchema>;

export const avisoSchema = z
  .object({
    linha1: z.string().default("Jogue com responsabilidade."),
    linha2: z.string().default("Ministério da Fazenda adverte: Aposta não é investimento."),
    etiqueta: z.string().default("#PUBLICIDADE"),
  })
  .optional();

// "texto com **destaque**" -> spans
export const Marcado: React.FC<{ texto: string; corDestaque: string; peso?: number }> = ({ texto, corDestaque, peso }) => (
  <>
    {texto
      .split(/(\*\*[^*]+\*\*)/g)
      .filter(Boolean)
      .map((p, i) =>
        p.startsWith("**") ? (
          <span key={i} style={{ color: corDestaque, fontWeight: peso }}>
            {p.slice(2, -2)}
          </span>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
  </>
);

export const AvisoCartao: React.FC<{ aviso?: z.input<typeof avisoSchema>; compacto?: boolean }> = ({ aviso = {}, compacto }) => (
  <div
    style={{
      position: "relative",
      display: "flex",
      alignItems: "center",
      gap: compacto ? 18 : 24,
      padding: compacto ? "16px 24px" : "20px 28px",
      backgroundColor: "rgba(255,255,255,0.95)",
      borderRadius: 18,
      fontFamily: "Inter",
      color: "#111",
      boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
      width: "100%",
    }}
  >
    <div
      style={{
        position: "absolute",
        right: 36,
        top: -18,
        backgroundColor: "#1f1f1f",
        color: "white",
        fontSize: 18,
        fontWeight: 700,
        letterSpacing: 3,
        padding: "5px 16px",
        borderRadius: 999,
      }}
    >
      {aviso.etiqueta ?? "#PUBLICIDADE"}
    </div>
    <div
      style={{
        width: compacto ? 58 : 68,
        height: compacto ? 58 : 68,
        borderRadius: 999,
        backgroundColor: "#1f1f1f",
        color: "white",
        fontWeight: 700,
        fontSize: compacto ? 24 : 28,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}
    >
      +18
    </div>
    <div style={{ fontSize: compacto ? 22 : 25, fontWeight: 600, lineHeight: 1.3, letterSpacing: -0.3 }}>
      <div>{aviso.linha1 ?? "Jogue com responsabilidade."}</div>
      <div>{aviso.linha2 ?? "Ministério da Fazenda adverte: Aposta não é investimento."}</div>
    </div>
  </div>
);

// Mede a altura natural de um bloco (depois de fontes e imagens carregadas)
export function useMedida<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [altura, setAltura] = useState<number | null>(null);
  const { delayRender, continueRender } = useDelayRender();
  const [handle] = useState(() => delayRender("medindo bloco"));
  useLayoutEffect(() => {
    const imgs = Array.from(ref.current?.querySelectorAll("img") ?? []);
    const prontas = imgs.map((img) =>
      img.complete && img.naturalHeight > 0
        ? Promise.resolve()
        : new Promise<void>((ok) => {
            img.addEventListener("load", () => ok(), { once: true });
            img.addEventListener("error", () => ok(), { once: true });
          }),
    );
    Promise.all([fontesProntas, ...prontas]).then(() =>
      requestAnimationFrame(() => {
        setAltura(ref.current?.scrollHeight ?? 0);
        continueRender(handle);
      }),
    );
  }, [continueRender, handle]);
  return { ref, altura };
}

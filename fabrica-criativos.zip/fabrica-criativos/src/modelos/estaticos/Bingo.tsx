import { useLayoutEffect, useRef, useState } from "react";
import { z } from "zod";
import { AbsoluteFill, Img, staticFile, useDelayRender, useVideoConfig, type CalculateMetadataFunction } from "remotion";
import { fontesProntas, kitSchema } from "../../kit";
import { ZonaDebug, intersecta, rostosSchema, type Caixa } from "../../zona-protegida";

// ---------------------------------------------------------------------------
// Modelo estático "Bingo" v1 — padrão real dos bingos OTG (docs/bingo.md)
// Formatos: WhatsApp 1080x1080 · RCS 1550x1036 · E-mail (header) 1800x900
// Camadas: fundo (estádio) · bilhete · escudos em pares · Tylty recortado ·
// bloco de título (caixa de cor + número gigante) · botão · aviso legal.
// REGRA DO ROSTO: escudos, textos e botão nunca entram na zona do rosto.
// Feito 100% com fotos, escudos e fontes reais — nada gerado por IA.
// ---------------------------------------------------------------------------

export const FORMATOS_BINGO = {
  whatsapp: { width: 1080, height: 1080 },
  rcs: { width: 1550, height: 1036 },
  email: { width: 1800, height: 900 },
} as const;

export const TEMAS_BINGO = {
  azul: { caixa: "#1F3DFF", brilho: "#3B6BFF", numero: "#1DFF5A", fundo: "#0A1A6B" },
  verde: { caixa: "#12A23B", brilho: "#22E06A", numero: "#FFFFFF", fundo: "#06361A" },
  escuro: { caixa: "#1B1D21", brilho: "#1DFF5A", numero: "#1DFF5A", fundo: "#0B2A16" },
  amarelo: { caixa: "#1F3DFF", brilho: "#FFD400", numero: "#FFD400", fundo: "#0A1A6B" },
  dourado: { caixa: "#C9971F", brilho: "#FFD36A", numero: "#FFE24A", fundo: "#2A1E05" },
} as const;

export const bingoSchema = z.object({
  formato: z.enum(["whatsapp", "rcs", "email"]),
  tema: z.enum(["azul", "verde", "escuro", "amarelo", "dourado"]).default("azul"),
  copy: z.object({
    destaque: z.string(), // número/gancho gigante: "ØDD 250"
    linha: z.string().optional(), // dentro da caixa, abaixo do destaque
    apoio: z.string().optional(), // abaixo da caixa, itálico
    botao: z.string().optional(), // "VER BILHETE"
  }),
  confrontos: z.array(z.array(z.string()).length(2)), // [["br/palmeiras","br/sao-paulo"], ...]
  foto: z.object({ src: z.string(), rostos: rostosSchema, lado: z.enum(["direita", "esquerda"]).default("direita") }),
  bilhete: z.string().optional(), // print do bilhete (opcional)
  fundo: z.string().optional(), // imagem própria; sem ela, a Fábrica monta o estádio
  casa: z.object({ selo: z.string().optional(), nome: z.string(), portaria: z.string() }),
  mostrarZona: z.boolean().optional(),
  kit: kitSchema.optional(),
});
export type BingoProps = z.input<typeof bingoSchema>;

export const calcularMetadataBingo: CalculateMetadataFunction<BingoProps> = async ({ props }) => {
  await fontesProntas;
  return { ...FORMATOS_BINGO[props.formato], durationInFrames: 1, defaultOutName: `bingo-${props.formato}` };
};

// "ODD" sempre censurado (compliance OTG): ODD -> ØDD
const censurar = (t: string) => t.replace(/\b[Oo][Dd][Dd]/g, (m) => (m === m.toUpperCase() ? "ØDD" : "Ødd"));
const escudoSrc = (id: string) => staticFile(`escudos/${id}${/\.(svg|png)$/.test(id) ? "" : id.startsWith("europa/") ? ".png" : ".svg"}`);

// Encaixa o conteúdo numa caixa: mede o tamanho natural e reduz só se precisar
const Encaixe: React.FC<{ w: number; h: number; alinhar?: "left" | "center"; children: React.ReactNode }> = ({ w, h, alinhar = "left", children }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [esc, setEsc] = useState<number | null>(null);
  const { delayRender, continueRender } = useDelayRender();
  const [handle] = useState(() => delayRender("encaixe"));
  useLayoutEffect(() => {
    fontesProntas.then(() =>
      requestAnimationFrame(() => {
        const el = ref.current!;
        setEsc(Math.min(1, w / el.scrollWidth, h / el.scrollHeight));
        continueRender(handle);
      }),
    );
  }, [w, h, continueRender, handle]);
  return (
    <div style={{ width: w, height: h, display: "flex", justifyContent: alinhar === "center" ? "center" : "flex-start", alignItems: "flex-start" }}>
      <div ref={ref} style={{ width: "max-content", scale: esc ?? 1, transformOrigin: alinhar === "center" ? "top center" : "top left", opacity: esc === null ? 0 : 1 }}>
        {children}
      </div>
    </div>
  );
};

// Estádio montado em código quando não há fundo próprio: gramado em perspectiva,
// refletores, arquibancada escura, cor do tema e vinheta.
const Estadio: React.FC<{ cor: string; w: number; h: number }> = ({ cor, w, h }) => (
  <AbsoluteFill style={{ backgroundColor: "#04070B" }}>
    <AbsoluteFill style={{ background: `radial-gradient(ellipse 80% 55% at 50% 0%, ${cor}AA 0%, ${cor}33 45%, transparent 75%)` }} />
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ position: "absolute", inset: 0 }}>
      <defs>
        <linearGradient id="grama" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0E5A2A" stopOpacity="0.0" />
          <stop offset="0.25" stopColor="#11612C" stopOpacity="0.75" />
          <stop offset="1" stopColor="#0A3D1C" stopOpacity="0.95" />
        </linearGradient>
        <radialGradient id="refletor">
          <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.95" />
          <stop offset="0.25" stopColor="#FFF6DA" stopOpacity="0.45" />
          <stop offset="1" stopColor="#FFF6DA" stopOpacity="0" />
        </radialGradient>
        <pattern id="faixas" width={w / 9} height={h} patternUnits="userSpaceOnUse">
          <rect width={w / 18} height={h} fill="#FFFFFF" opacity="0.035" />
        </pattern>
        <filter id="grao">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="7" />
          <feColorMatrix values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 0.06 0" />
        </filter>
      </defs>
      {/* arquibancada: faixas de pontos (torcida) */}
      {Array.from({ length: 7 }).map((_, i) => (
        <rect key={i} x={0} y={h * (0.18 + i * 0.045)} width={w} height={h * 0.03} fill="#FFFFFF" opacity={0.02 + i * 0.006} />
      ))}
      {/* gramado em perspectiva */}
      <polygon points={`${w * 0.12},${h * 0.52} ${w * 0.88},${h * 0.52} ${w * 1.25},${h} ${-w * 0.25},${h}`} fill="url(#grama)" />
      <polygon points={`${w * 0.12},${h * 0.52} ${w * 0.88},${h * 0.52} ${w * 1.25},${h} ${-w * 0.25},${h}`} fill="url(#faixas)" />
      <g stroke="#FFFFFF" strokeOpacity="0.22" strokeWidth={Math.max(2, w / 600)} fill="none">
        <polygon points={`${w * 0.14},${h * 0.535} ${w * 0.86},${h * 0.535} ${w * 1.18},${h * 1.02} ${-w * 0.18},${h * 1.02}`} />
        <line x1={w * 0.5} y1={h * 0.535} x2={w * 0.5} y2={h * 1.02} />
        <ellipse cx={w * 0.5} cy={h * 0.74} rx={w * 0.13} ry={h * 0.06} />
      </g>
      {/* refletores */}
      {[0.08, 0.3, 0.7, 0.92].map((x, i) => (
        <circle key={i} cx={w * x} cy={h * 0.07} r={w * 0.11} fill="url(#refletor)" opacity={0.55} />
      ))}
      <rect width={w} height={h} filter="url(#grao)" />
    </svg>
    <AbsoluteFill style={{ backdropFilter: "blur(3px)" }} />
    <AbsoluteFill style={{ background: "radial-gradient(ellipse 75% 70% at 50% 45%, transparent 40%, rgba(0,0,0,0.75) 100%)" }} />
  </AbsoluteFill>
);

const Escudo: React.FC<{ id: string; tam: number; rot: number }> = ({ id, tam, rot }) => (
  <Img
    src={escudoSrc(id)}
    style={{
      width: tam,
      height: tam,
      objectFit: "contain",
      rotate: `${rot}deg`,
      filter: "drop-shadow(0 10px 14px rgba(0,0,0,0.55)) drop-shadow(0 0 2px rgba(0,0,0,0.6))",
    }}
  />
);

// pares de escudos sobrepostos (o 2º um pouco à direita e abaixo), em coluna/grade
const Escudos: React.FC<{ confrontos: string[][]; caixa: Caixa; colunas: number }> = ({ confrontos, caixa, colunas }) => {
  const linhas = Math.ceil(confrontos.length / colunas);
  const celW = caixa.w / colunas;
  const celH = caixa.h / linhas;
  const tam = Math.min(celW / 1.62, celH / 1.12);
  return (
    <>
      {confrontos.map((par, i) => {
        const c = i % colunas;
        const l = Math.floor(i / colunas);
        const desloc = (l % 2) * celW * 0.12; // zigue-zague, como nas peças
        const x = caixa.x + c * celW + (celW - tam * 1.62) / 2 + desloc;
        const y = caixa.y + l * celH + (celH - tam * 1.12) / 2;
        return (
          <div key={i} style={{ position: "absolute", left: x, top: y, width: tam * 1.62, height: tam * 1.12 }}>
            <div style={{ position: "absolute", left: 0, top: 0 }}>
              <Escudo id={par[0]} tam={tam} rot={-6} />
            </div>
            <div style={{ position: "absolute", left: tam * 0.62, top: tam * 0.08 }}>
              <Escudo id={par[1]} tam={tam} rot={5} />
            </div>
          </div>
        );
      })}
    </>
  );
};

const Aviso: React.FC<{ casa: BingoProps["casa"]; w: number; escala: number }> = ({ casa, w, escala: e }) => (
  <div style={{ position: "relative", width: w }}>
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 22 * e,
        backgroundColor: "rgba(22,23,26,0.94)",
        borderRadius: 20 * e,
        padding: `${16 * e}px ${22 * e}px`,
        boxShadow: "0 10px 30px rgba(0,0,0,0.45)",
      }}
    >
      <div
        style={{
          width: 76 * e,
          height: 76 * e,
          borderRadius: 999,
          backgroundColor: "#F2F2F2",
          color: "#111",
          fontFamily: "Inter",
          fontWeight: 800,
          fontSize: 31 * e,
          letterSpacing: -1.5 * e,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
        }}
      >
        +18
      </div>
      <div style={{ flex: 1, fontFamily: "Inter", color: "white", fontSize: 25 * e, lineHeight: 1.22, letterSpacing: -0.3 * e }}>
        <b style={{ fontWeight: 700 }}>Jogue com responsabilidade. Ministério da Fazenda adverte: Aposta não é investimento.</b>{" "}
        <span style={{ fontWeight: 400, opacity: 0.92 }}>Portaria SPA/MF n° {casa.portaria}</span>
      </div>
      {casa.selo ? (
        <Img src={staticFile(casa.selo)} style={{ height: 70 * e, width: "auto", maxWidth: 150 * e, objectFit: "contain", flexShrink: 0 }} />
      ) : null}
    </div>
    <div
      style={{
        position: "absolute",
        left: 110 * e,
        bottom: -18 * e,
        backgroundColor: "#F2F2F2",
        color: "#222",
        fontFamily: "Inter",
        fontWeight: 600,
        fontSize: 17 * e,
        letterSpacing: 3.5 * e,
        padding: `${5 * e}px ${20 * e}px`,
        borderRadius: 999,
      }}
    >
      #PUBLICIDADE
    </div>
  </div>
);

// geometria de cada formato (posições pensadas a partir das peças de referência)
function layout(formato: BingoProps["formato"], W: number, H: number, temBilhete: boolean, nPares: number) {
  if (formato === "whatsapp")
    return {
      titulo: { x: 26, y: 24, w: 690, h: 290 },
      bilhete: { x: 64, y: 280, w: 440, h: 520 },
      escudos: temBilhete ? { x: 510, y: 360, w: 330, h: 440 } : { x: 40, y: 330, w: 560, h: Math.min(470, 160 * nPares + 40) },
      colunas: temBilhete ? 1 : nPares > 2 ? 2 : 1,
      foto: { alturaRel: 0.95, base: 0.88 },
      botao: { x: 300, y: 810, w: 480 },
      aviso: { x: 44, y: 924, w: 992, e: 1 },
    };
  if (formato === "rcs")
    return {
      titulo: { x: 40, y: 34, w: 900, h: 330 },
      bilhete: { x: 70, y: 370, w: 470, h: 520 },
      escudos: temBilhete ? { x: 560, y: 380, w: 380, h: 470 } : { x: 60, y: 380, w: 760, h: Math.min(450, 170 * Math.ceil(nPares / 2) + 60) },
      colunas: temBilhete ? 1 : 2,
      foto: { alturaRel: 0.98, base: 1.0 },
      botao: { x: 220, y: 846, w: 470 },
      aviso: { x: 760, y: 862, w: 760, e: 0.82 },
    };
  return {
    titulo: { x: 36, y: 30, w: 820, h: 330 },
    bilhete: { x: 70, y: 380, w: 480, h: 480 },
    escudos: temBilhete ? { x: 840, y: 90, w: 420, h: 600 } : { x: 860, y: 70, w: 440, h: Math.min(640, 200 * nPares + 40) },
    colunas: 1,
    foto: { alturaRel: 1.02, base: 1.06 },
    botao: { x: 150, y: 560, w: 520 },
    aviso: { x: 780, y: 742, w: 980, e: 0.92 },
  };
}

export const Bingo: React.FC<BingoProps> = (p) => {
  const { width: W, height: H } = useVideoConfig();
  const tema = TEMAS_BINGO[p.tema ?? "azul"];
  const L = layout(p.formato, W, H, !!p.bilhete, p.confrontos.length);
  const lado = p.foto.lado ?? "direita";

  // ---- foto do Tylty: altura relativa ao quadro, apoiada embaixo, no lado escolhido ----
  const r = p.foto.rostos;
  const fotoH = H * L.foto.alturaRel;
  const fotoW = r ? (r.largura / r.altura) * fotoH : fotoH * 0.7;
  const fotoX = lado === "direita" ? W - fotoW + fotoW * 0.04 : -fotoW * 0.04;
  const fotoY = H * L.foto.base - fotoH;
  const s = r ? fotoH / r.altura : 1;
  const zona: Caixa | null = r?.uniao ? { x: fotoX + r.uniao[0] * s, y: fotoY + r.uniao[1] * s, w: r.uniao[2] * s, h: r.uniao[3] * s } : null;

  // ---- REGRA DO ROSTO: escudos fora da zona (empurra para longe do rosto, encolhendo se precisar) ----
  let esc = { ...L.escudos };
  if (zona) {
    for (let k = 0; k < 40 && intersecta(esc, zona, 24); k++) {
      if (lado === "direita") esc.x -= 12;
      else esc.x += 12;
      if (k > 20) esc = { ...esc, w: esc.w * 0.96, h: esc.h * 0.96 };
    }
  }
  if (lado === "esquerda") {
    // espelha a composição: textos e bilhete vão para a direita
    const espelhar = (c: { x: number; w: number }) => ({ ...c, x: W - c.x - c.w });
    Object.assign(L, { titulo: espelhar(L.titulo), bilhete: espelhar(L.bilhete), botao: espelhar(L.botao), aviso: espelhar(L.aviso) });
  }

  const corFundo = tema.fundo;
  return (
    <AbsoluteFill style={{ backgroundColor: "#05070A", overflow: "hidden" }}>
      {/* 1 · fundo */}
      {p.fundo ? (
        <>
          <Img src={staticFile(p.fundo)} style={{ position: "absolute", inset: 0, width: W, height: H, objectFit: "cover", filter: "blur(2px) brightness(0.62) saturate(1.1)" }} />
          <AbsoluteFill style={{ background: `linear-gradient(${lado === "direita" ? 90 : 270}deg, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0.25) 55%, rgba(0,0,0,0.1) 100%)` }} />
        </>
      ) : (
        <Estadio cor={corFundo} w={W} h={H} />
      )}
      {/* luz de recorte atrás do expert, na cor do tema */}
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse 34% 52% at ${lado === "direita" ? 78 : 22}% 48%, ${tema.brilho}55 0%, transparent 70%)`,
        }}
      />

      {/* 2 · bilhete */}
      {p.bilhete ? (
        <Img
          src={staticFile(p.bilhete)}
          style={{
            position: "absolute",
            left: L.bilhete.x,
            top: L.bilhete.y,
            width: L.bilhete.w,
            maxHeight: L.bilhete.h,
            objectFit: "cover",
            objectPosition: "top",
            borderRadius: 18,
            boxShadow: "0 22px 50px rgba(0,0,0,0.6)",
          }}
        />
      ) : null}

      {/* 3 · Tylty recortado (com sombra e contorno de luz) */}
      <Img
        src={staticFile(p.foto.src)}
        style={{
          position: "absolute",
          left: fotoX,
          top: fotoY,
          height: fotoH,
          width: fotoW,
          filter: `drop-shadow(0 0 2px ${tema.brilho}AA) drop-shadow(0 0 28px ${tema.brilho}55) drop-shadow(-20px 10px 40px rgba(0,0,0,0.6)) contrast(1.06) saturate(1.08)`,
        }}
      />

      {/* 4 · escudos (pares sobrepostos) */}
      <Escudos confrontos={p.confrontos} caixa={esc} colunas={L.colunas} />

      {/* 5 · título: caixa de cor com o destaque gigante + linha; apoio abaixo */}
      <div style={{ position: "absolute", left: L.titulo.x, top: L.titulo.y, width: L.titulo.w }}>
        <div
          style={{
            backgroundColor: tema.caixa,
            borderRadius: 12,
            padding: "14px 30px 18px",
            boxShadow: `0 0 0 2px ${tema.brilho}88, 0 0 46px ${tema.brilho}88, 0 20px 40px rgba(0,0,0,0.45)`,
          }}
        >
          <Encaixe w={L.titulo.w - 60} h={L.titulo.h * 0.62} alinhar="center">
            <div
              style={{
                fontFamily: "Barlow Condensed",
                fontWeight: 900,
                fontStyle: "italic",
                fontSize: 230,
                lineHeight: 0.92,
                color: tema.numero,
                textTransform: "uppercase",
                letterSpacing: -2,
                textShadow: "0 6px 0 rgba(0,0,0,0.35), 0 0 30px rgba(0,0,0,0.25)",
                paddingRight: 12,
              }}
            >
              {censurar(p.copy.destaque)}
            </div>
          </Encaixe>
          {p.copy.linha ? (
            <Encaixe w={L.titulo.w - 60} h={L.titulo.h * 0.24} alinhar="center">
              <div style={{ fontFamily: "Barlow Condensed", fontWeight: 800, fontSize: 82, lineHeight: 1, color: "white", textTransform: "uppercase", letterSpacing: -0.5 }}>
                {censurar(p.copy.linha)}
              </div>
            </Encaixe>
          ) : null}
        </div>
        {p.copy.apoio ? (
          <div style={{ marginTop: 10 }}>
            <Encaixe w={L.titulo.w} h={74} alinhar="center">
              <div
                style={{
                  fontFamily: "Barlow Condensed",
                  fontWeight: 800,
                  fontStyle: "italic",
                  fontSize: 60,
                  color: "white",
                  textTransform: "uppercase",
                  textShadow: "0 4px 14px rgba(0,0,0,0.8)",
                  paddingRight: 8,
                }}
              >
                {censurar(p.copy.apoio)}
              </div>
            </Encaixe>
          </div>
        ) : null}
      </div>

      {/* 6 · botão */}
      {p.copy.botao ? (
        <div style={{ position: "absolute", left: L.botao.x, top: L.botao.y, width: L.botao.w, display: "flex", justifyContent: "center" }}>
          <div
            style={{
              fontFamily: "Barlow Condensed",
              fontWeight: 900,
              fontStyle: "italic",
              fontSize: 58,
              color: "white",
              textTransform: "uppercase",
              backgroundColor: "#13A33E",
              padding: "6px 34px 8px",
              borderRadius: 6,
              boxShadow: "0 0 26px rgba(30,230,110,0.45), 0 12px 24px rgba(0,0,0,0.45)",
              whiteSpace: "nowrap",
            }}
          >
            {p.copy.botao}
          </div>
        </div>
      ) : null}

      {/* 7 · aviso legal */}
      <div style={{ position: "absolute", left: L.aviso.x, top: L.aviso.y }}>
        <Aviso casa={p.casa} w={L.aviso.w} escala={L.aviso.e} />
      </div>

      {p.mostrarZona ? <ZonaDebug zona={zona} /> : null}
    </AbsoluteFill>
  );
};

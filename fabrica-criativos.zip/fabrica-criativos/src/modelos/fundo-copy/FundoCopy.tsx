import { z } from "zod";
import {
  AbsoluteFill,
  Easing,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  type CalculateMetadataFunction,
} from "remotion";
import { Video } from "@remotion/media";
import { FONTE, fontesProntas, kitSchema, type Kit } from "../../kit";
import { paletaDestaque } from "../fala-legendada/cores";

// ---------------------------------------------------------------------------
// Modelo "Fundo aleatório + copy" v1
// Um vídeo de fundo (escurecido e desfocado) e a copy em telas grandes,
// sincronizadas com o áudio. Palavras entre **asteriscos** ganham caixa na cor
// de destaque. Uma linha pode ser um contador ("300" sobe de 0 até 300).
// ---------------------------------------------------------------------------

export const MODELO_ID = "fundo-copy";
export const MODELO_VERSAO = "v1";
const FPS = 30;

const linhaSchema = z.object({
  texto: z.string(), // **palavra** = destaque
  tamanho: z.enum(["gg", "g", "m", "p"]).default("g"),
  atrasoMs: z.number().default(0), // em relação ao início da tela
  contador: z.object({ ate: z.number(), sufixo: z.string().default("") }).optional(),
});

const telaSchema = z.object({
  inicioMs: z.number(),
  fimMs: z.number(),
  tipo: z.enum(["texto", "cta", "aviso"]).default("texto"),
  linhas: z.array(linhaSchema),
});

export const fundoCopySchema = z.object({
  fundo: z.object({
    video: z.string(), // caminho dentro de public/
    escurecer: z.number().min(0).max(1).default(0.5),
    desfoque: z.number().default(6),
    volume: z.number().min(0).max(1).default(1), // áudio do fundo (0 = mudo)
  }),
  duracaoSeg: z.number(),
  telas: z.array(telaSchema),
  corLegenda: z.string().optional(),
  kit: kitSchema,
});

export type FundoCopyProps = z.input<typeof fundoCopySchema>;
type Tela = z.input<typeof telaSchema>;
type Linha = z.input<typeof linhaSchema>;

export const calcularMetadataFundo: CalculateMetadataFunction<FundoCopyProps> = async ({ props }) => {
  await fontesProntas;
  return {
    durationInFrames: Math.ceil(props.duracaoSeg * FPS),
    defaultOutName: `${MODELO_ID}-${MODELO_VERSAO}`,
  };
};

const TAMANHOS = { gg: 132, g: 88, m: 64, p: 40 } as const;
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

// Quebra "texto com **destaque**" em pedaços
const pedacos = (texto: string) =>
  texto.split(/(\*\*[^*]+\*\*)/g).filter(Boolean).map((p) =>
    p.startsWith("**") ? { destaque: true, t: p.slice(2, -2) } : { destaque: false, t: p },
  );

const formatarNumero = (n: number) => Math.round(n).toLocaleString("pt-BR");

const LinhaCopy: React.FC<{ linha: Linha; corBase: string; corTextoDestaque: string; tipo: Tela["tipo"] }> = ({
  linha,
  corBase,
  corTextoDestaque,
  tipo,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t0 = ((linha.atrasoMs ?? 0) / 1000) * fps;
  const tamanho = TAMANHOS[linha.tamanho ?? "g"];
  const entrada = {
    opacity: interpolate(frame, [t0, t0 + 4], [0, 1], clamp),
    translate: interpolate(frame, [t0, t0 + 8], ["0px 40px", "0px 0px"], {
      ...clamp,
      easing: Easing.bezier(0.16, 1, 0.3, 1),
    }),
    scale: interpolate(frame, [t0, t0 + 8], [0.92, 1], {
      ...clamp,
      easing: Easing.spring({ damping: 14 }),
      output: "perceptual-scale",
    }),
  };

  // linha-contador: o número sobe até o valor final
  if (linha.contador) {
    const valor = interpolate(frame, [t0, t0 + 0.7 * fps], [0, linha.contador.ate], {
      ...clamp,
      easing: Easing.bezier(0.2, 0.8, 0.2, 1),
    });
    return (
      <div
        style={{
          ...entrada,
          fontFamily: FONTE,
          fontWeight: 900,
          fontSize: tamanho,
          lineHeight: 1,
          color: corBase,
          textShadow: `0 0 40px ${corBase}88, 0 6px 0 rgba(0,0,0,0.6)`,
          letterSpacing: -2,
        }}
      >
        {formatarNumero(valor)}
        <span style={{ fontSize: tamanho * 0.55, marginLeft: 12 }}>{linha.contador.sufixo}</span>
      </div>
    );
  }

  const ehCta = tipo === "cta";
  return (
    <div
      style={{
        ...entrada,
        fontFamily: FONTE,
        fontWeight: tipo === "aviso" ? 700 : 900,
        fontSize: tamanho,
        lineHeight: 1.12,
        textTransform: tipo === "aviso" ? "none" : "uppercase",
        textAlign: "center",
        color: "white",
        textShadow: "0 4px 18px rgba(0,0,0,0.65)",
        maxWidth: 920,
        ...(ehCta
          ? {
              backgroundColor: corBase,
              color: corTextoDestaque,
              textShadow: "none",
              padding: "26px 54px",
              borderRadius: 999,
              boxShadow: `0 0 0 ${interpolate(frame % 30, [0, 29], [0, 28])}px ${corBase}33, 0 18px 40px rgba(0,0,0,0.45)`,
            }
          : {}),
      }}
    >
      {pedacos(linha.texto).map((p, i) =>
        p.destaque && !ehCta ? (
          <span
            key={i}
            style={{
              backgroundColor: corBase,
              color: corTextoDestaque,
              textShadow: "none",
              padding: "0 14px",
              margin: "0 2px",
              borderRadius: 12,
              boxDecorationBreak: "clone",
              WebkitBoxDecorationBreak: "clone",
            }}
          >
            {p.t}
          </span>
        ) : (
          <span key={i}>{p.t}</span>
        ),
      )}
    </div>
  );
};

const TelaCopy: React.FC<{ tela: Tela; kit: Kit; corBase: string; duracaoFrames: number }> = ({
  tela,
  corBase,
  duracaoFrames,
}) => {
  const frame = useCurrentFrame();
  const saida = interpolate(frame, [duracaoFrames - 5, duracaoFrames], [1, 0], clamp);
  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        gap: tela.tipo === "aviso" ? 18 : 26,
        padding: "0 80px",
        opacity: saida,
        translate: interpolate(frame, [duracaoFrames - 5, duracaoFrames], ["0px 0px", "0px -30px"], clamp),
      }}
    >
      {tela.linhas.map((l, i) => (
        <LinhaCopy key={i} linha={l} corBase={corBase} corTextoDestaque="#111111" tipo={tela.tipo ?? "texto"} />
      ))}
    </AbsoluteFill>
  );
};

const Fundo: React.FC<{ fundo: FundoCopyProps["fundo"]; duracaoFrames: number }> = ({ fundo, duracaoFrames }) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      <AbsoluteFill
        style={{
          filter: `blur(${fundo.desfoque ?? 6}px) saturate(1.1)`,
          scale: interpolate(frame, [0, duracaoFrames], [1.08, 1.16]), // leve zoom contínuo
        }}
      >
        <Video src={staticFile(fundo.video)} volume={fundo.volume ?? 1} />
      </AbsoluteFill>
      <AbsoluteFill style={{ backgroundColor: `rgba(0,0,0,${fundo.escurecer ?? 0.5})` }} />
      <AbsoluteFill
        style={{
          background: "radial-gradient(ellipse 90% 60% at 50% 50%, rgba(0,0,0,0) 40%, rgba(0,0,0,0.55) 100%)",
        }}
      />
    </AbsoluteFill>
  );
};

const AvisoLegal: React.FC<{ kit: Kit }> = ({ kit }) =>
  kit.avisoLegal ? (
    <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 70 }}>
      <div
        style={{
          fontFamily: FONTE,
          fontWeight: 600,
          fontSize: 32,
          color: "white",
          backgroundColor: "rgba(0,0,0,0.6)",
          padding: "10px 26px",
          borderRadius: 999,
        }}
      >
        {kit.avisoLegal}
      </div>
    </AbsoluteFill>
  ) : null;

export const FundoCopy: React.FC<FundoCopyProps> = (props) => {
  const { fps, durationInFrames } = useVideoConfig();
  const corBase = paletaDestaque(props.corLegenda || props.kit.corDestaque).base;
  return (
    <AbsoluteFill>
      <Fundo fundo={props.fundo} duracaoFrames={durationInFrames} />
      {props.telas.map((t, i) => {
        const de = Math.round((t.inicioMs / 1000) * fps);
        const dur = Math.max(1, Math.round(((t.fimMs - t.inicioMs) / 1000) * fps));
        return (
          <Sequence key={i} from={de} durationInFrames={dur} name={`Tela ${i + 1}`}>
            <TelaCopy tela={t} kit={props.kit} corBase={corBase} duracaoFrames={dur} />
          </Sequence>
        );
      })}
      <AvisoLegal kit={props.kit} />
    </AbsoluteFill>
  );
};

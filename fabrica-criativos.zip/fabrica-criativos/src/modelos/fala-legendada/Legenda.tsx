import { useMemo } from "react";
import {
  AbsoluteFill,
  Easing,
  Sequence,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { createTikTokStyleCaptions } from "@remotion/captions";
import type { Caption, TikTokPage } from "@remotion/captions";
import type { Kit } from "../../kit";
import { ESTILOS, type EstiloLegenda, type IdEstilo } from "./estilos";

const normalizar = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9%$]/g, "");

const Pagina: React.FC<{
  page: TikTokPage;
  indice: number;
  kit: Kit;
  destaques: Set<string>;
  estilo: EstiloLegenda;
}> = ({ page, indice, kit, destaques, estilo }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const agoraMs = page.startMs + (frame / fps) * 1000;
  const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

  // animação de entrada da página
  const entrada: React.CSSProperties =
    estilo.animacao === "pop"
      ? {
          scale: interpolate(frame, [0, 5], [0.86, 1], {
            ...clamp,
            easing: Easing.bezier(0.16, 1, 0.3, 1),
          }),
        }
      : estilo.animacao === "fade"
        ? { opacity: interpolate(frame, [0, 5], [0, 1], clamp) }
        : estilo.animacao === "sobe"
          ? {
              opacity: interpolate(frame, [0, 4], [0, 1], clamp),
              translate: interpolate(frame, [0, 6], ["0px 36px", "0px 0px"], {
                ...clamp,
                easing: Easing.bezier(0.16, 1, 0.3, 1),
              }),
            }
          : {
              // impacto: entra grande e assenta, com leve rotação alternada
              scale: interpolate(frame, [0, 4], [1.45, 1], {
                ...clamp,
                easing: Easing.spring({ damping: 11 }),
                output: "perceptual-scale",
              }),
              rotate: `${(indice % 2 === 0 ? -1 : 1) * (estilo.rotacao ?? 0)}deg`,
            };

  const sobreMarca = estilo.fundo === "marca";
  const corBase = sobreMarca ? kit.corTextoSobrePrimaria : "white";

  const fundo: React.CSSProperties =
    estilo.fundo === "escuro"
      ? { backgroundColor: "rgba(0,0,0,0.72)", padding: "18px 34px", borderRadius: 22 }
      : estilo.fundo === "marca"
        ? {
            backgroundColor: kit.corPrimaria,
            padding: "20px 36px",
            borderRadius: 16,
            boxShadow: "0 14px 36px rgba(0,0,0,0.35)",
          }
        : {};

  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-start",
        alignItems: "center",
        paddingTop: estilo.topo,
        paddingLeft: 90,
        paddingRight: 90,
      }}
    >
      <div
        style={{
          fontFamily: estilo.fonte,
          fontWeight: estilo.peso,
          fontSize: estilo.tamanho,
          letterSpacing: estilo.espacamento,
          lineHeight: 1.14,
          textAlign: "center",
          textTransform: estilo.caixaAlta ? "uppercase" : "none",
          whiteSpace: "pre-wrap",
          color: corBase,
          WebkitTextStroke: estilo.contorno ? `${estilo.contorno}px black` : undefined,
          paintOrder: "stroke fill",
          textShadow: estilo.sombra,
          ...fundo,
          ...entrada,
        }}
      >
        {page.tokens.map((token, i) => {
          const ativa = token.fromMs <= agoraMs && token.toMs > agoraMs;
          const dita = token.toMs <= agoraMs;
          const destaque = destaques.has(normalizar(token.text));
          const lead = token.text.match(/^\s*/)?.[0] ?? "";
          const palavra = token.text.slice(lead.length);

          let estiloPalavra: React.CSSProperties = { display: "inline-block" };
          if (estilo.modoAtivo === "cor") {
            estiloPalavra = {
              ...estiloPalavra,
              color: ativa || destaque ? kit.corDestaque : corBase,
              scale: ativa ? 1.08 : 1,
            };
          } else if (estilo.modoAtivo === "caixa") {
            estiloPalavra = {
              ...estiloPalavra,
              color: ativa ? "#111111" : destaque ? kit.corDestaque : corBase,
              backgroundColor: ativa ? kit.corDestaque : "transparent",
              textShadow: ativa ? "none" : undefined,
              padding: "0 14px",
              margin: "0 -14px",
              borderRadius: 14,
              rotate: ativa ? "-2deg" : "0deg",
            };
          } else if (estilo.modoAtivo === "preenche") {
            estiloPalavra = {
              ...estiloPalavra,
              color: ativa || dita ? kit.corDestaque : corBase,
              opacity: ativa || dita ? 1 : 0.6,
            };
          } else if (destaque) {
            estiloPalavra = { ...estiloPalavra, color: kit.corDestaque };
          }
          if (destaque && estilo.destaqueItalico) {
            estiloPalavra = {
              ...estiloPalavra,
              fontFamily: estilo.destaqueItalico.fonte,
              fontStyle: "italic",
              fontWeight: 700,
            };
          }

          // espaço fora da palavra: a linha pode quebrar aqui e a caixa
          // de destaque não engole o espaço
          return (
            <Fragment key={`${token.fromMs}-${i}`}>
              {lead ? " " : null}
              <span style={estiloPalavra}>{palavra}</span>
            </Fragment>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

export const Legenda: React.FC<{
  legendas: Caption[];
  kit: Kit;
  destaques: string[];
  fimMs: number;
  estilo: IdEstilo;
}> = ({ legendas, kit, destaques, fimMs, estilo: idEstilo }) => {
  const { fps } = useVideoConfig();
  const estilo: EstiloLegenda = ESTILOS[idEstilo];
  const setDestaques = useMemo(
    () => new Set(destaques.map(normalizar)),
    [destaques],
  );
  const { pages } = useMemo(
    () =>
      createTikTokStyleCaptions({
        // fim de frase sempre fecha a página: a legenda nunca mistura duas frases
        captions: legendas.map((c) => ({
          ...c,
          pageBreakAfter: c.pageBreakAfter || /[.?!…:;]["”']?$/.test(c.text.trim()),
        })),
        combineTokensWithinMilliseconds: estilo.msPorPagina,
      }),
    [legendas, estilo.msPorPagina],
  );

  return (
    <AbsoluteFill>
      {pages.map((page, i) => {
        const proxima = pages[i + 1] ?? null;
        const inicio = Math.round((page.startMs / 1000) * fps);
        const fim = Math.round(
          (Math.min(
            proxima ? proxima.startMs : fimMs,
            page.startMs + page.durationMs + 400,
            fimMs,
          ) /
            1000) *
            fps,
        );
        if (fim - inicio <= 0) return null;
        return (
          <Sequence
            key={i}
            from={inicio}
            durationInFrames={fim - inicio}
            name={`Legenda ${i + 1}`}
          >
            <Pagina
              page={page}
              indice={i}
              kit={kit}
              destaques={setDestaques}
              estilo={estilo}
            />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};

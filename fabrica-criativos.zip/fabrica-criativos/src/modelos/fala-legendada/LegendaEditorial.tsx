import { useMemo } from "react";
import {
  AbsoluteFill,
  Easing,
  Sequence,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import type { Caption } from "@remotion/captions";
import type { Kit } from "../../kit";
import type { EstiloLegenda } from "./estilos";

// Estilo "Editorial": bloco tipográfico com duas famílias.
// Palavras de ligação em sans pequena; a palavra-chave da frase grande, em
// serifada itálica com degradê e brilho. Cada palavra entra letra a letra
// com desfoque no momento em que é falada; o bloco sai com desfoque.

const SERIFA = "Instrument Serif";
const ESCALA_CHAVE = 2.8; // tamanho da palavra-chave em relação à sans
const MAX_PALAVRAS = 5;
const SAIDA_FRAMES = 7;

type Palavra = { texto: string; inicioMs: number; fimMs: number };
type Bloco = {
  antes: Palavra[];
  chave: Palavra | null;
  depois: Palavra[];
  inicioMs: number;
  fimMs: number;
};

const normalizar = (s: string) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9%$]/g, "");

const fimDeFrase = (t: string) => /[.?!…:;,]["”']?$/.test(t.trim());
const limpar = (t: string) => t.trim().replace(/[.,;:!?…"”']+$/g, "");

// Divide as legendas em blocos curtos (frase ou ~1,5s) e escolhe a palavra-chave
function montarBlocos(
  legendas: Caption[],
  destaques: Set<string>,
  msPorBloco: number,
): Bloco[] {
  // Cada bloco se forma em torno de uma palavra-chave: até 4 palavras antes,
  // a chave e no máximo 2 depois. Fim de frase sempre fecha o bloco.
  const ehChave = (t: string) => destaques.has(normalizar(t));
  const grupos: Palavra[][] = [];
  let atual: Palavra[] = [];
  let posChave = -1;
  const fechar = () => {
    if (atual.length) grupos.push(atual);
    atual = [];
    posChave = -1;
  };
  for (const c of legendas) {
    const p = { texto: limpar(c.text), inicioMs: c.startMs, fimMs: c.endMs };
    if (!p.texto) continue;
    // uma segunda palavra-chave abre um bloco novo
    if (ehChave(p.texto) && posChave >= 0) fechar();
    atual.push(p);
    if (ehChave(p.texto)) posChave = atual.length - 1;
    const depoisDaChave = posChave >= 0 ? atual.length - 1 - posChave : 0;
    const duracao = p.fimMs - atual[0].inicioMs;
    if (
      fimDeFrase(c.text) ||
      depoisDaChave >= 2 ||
      atual.length >= MAX_PALAVRAS ||
      (posChave < 0 && duracao >= msPorBloco * 1.6)
    ) {
      fechar();
    }
  }
  fechar();

  return grupos.map((g) => {
    // palavra-chave: a marcada na edição; senão, a palavra mais longa do bloco
    let i = g.findIndex((p) => destaques.has(normalizar(p.texto)));
    if (i < 0) {
      let maior = -1;
      g.forEach((p, j) => {
        const n = normalizar(p.texto).length;
        if (n >= 4 && n > maior) {
          maior = n;
          i = j;
        }
      });
    }
    return {
      antes: i < 0 ? g : g.slice(0, i),
      chave: i < 0 ? null : g[i],
      depois: i < 0 ? [] : g.slice(i + 1),
      inicioMs: g[0].inicioMs,
      fimMs: g[g.length - 1].fimMs,
    };
  });
}

const hexParaRgb = (hex: string) => {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return `${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}`;
};

// Uma palavra que surge letra a letra com desfoque a partir de `inicioMs`
const PalavraRevelada: React.FC<{
  palavra: Palavra;
  blocoInicioMs: number;
  estilo: React.CSSProperties;
  chave?: boolean;
}> = ({ palavra, blocoInicioMs, estilo, chave }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const inicio = ((palavra.inicioMs - blocoInicioMs) / 1000) * fps;
  const letras = Array.from(palavra.texto);
  const passo = chave ? 1.4 : 0.9; // frames entre uma letra e a próxima
  return (
    <span style={{ display: "inline-block", whiteSpace: "pre", ...estilo }}>
      {letras.map((l, i) => {
        const t0 = inicio + i * passo;
        const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: interpolate(frame, [t0, t0 + 5], [0, 1], clamp),
              filter: `blur(${interpolate(frame, [t0, t0 + 6], [9, 0], clamp)}px)`,
              translate: interpolate(frame, [t0, t0 + 6], ["0px 16px", "0px 0px"], {
                ...clamp,
                easing: Easing.bezier(0.16, 1, 0.3, 1),
              }),
            }}
          >
            {l}
          </span>
        );
      })}
    </span>
  );
};

const BlocoEditorial: React.FC<{
  bloco: Bloco;
  kit: Kit;
  estilo: EstiloLegenda;
  duracaoFrames: number;
}> = ({ bloco, kit, estilo, duracaoFrames }) => {
  const frame = useCurrentFrame();
  const tamSans = estilo.tamanho;
  const tamChave = Math.round(tamSans * ESCALA_CHAVE);
  const rgb = hexParaRgb(kit.corDestaque);

  const sans: React.CSSProperties = {
    fontFamily: estilo.fonte,
    fontWeight: estilo.peso,
    fontSize: tamSans,
    lineHeight: 1,
    color: "white",
    textShadow: estilo.sombra,
    textTransform: "lowercase",
  };
  const chave: React.CSSProperties = {
    fontFamily: SERIFA,
    fontStyle: "italic",
    fontWeight: 400,
    fontSize: tamChave,
    lineHeight: 0.86,
    letterSpacing: -2,
    paddingRight: "0.08em", // itálico não corta a última letra
    backgroundImage: `linear-gradient(180deg, #FFF1C9 0%, ${kit.corDestaque} 48%, rgb(${rgb}) 70%, #B34A00 100%)`,
    WebkitBackgroundClip: "text",
    backgroundClip: "text",
    color: "transparent",
    filter: `drop-shadow(0 0 18px rgba(${rgb}, 0.65)) drop-shadow(0 6px 14px rgba(0,0,0,0.45))`,
    textTransform: "lowercase",
  };

  const linha = (palavras: Palavra[]) => (
    <div style={{ display: "flex", gap: "0.28em", ...sans }}>
      {palavras.map((p, i) => (
        <PalavraRevelada key={i} palavra={p} blocoInicioMs={bloco.inicioMs} estilo={{}} />
      ))}
    </div>
  );
  const palavraChave = bloco.chave ? (
    <PalavraRevelada palavra={bloco.chave} blocoInicioMs={bloco.inicioMs} estilo={chave} chave />
  ) : null;

  // composições: o arranjo muda conforme a estrutura da frase
  let conteudo: React.ReactNode;
  const temAntes = bloco.antes.length > 0;
  const temDepois = bloco.depois.length > 0;
  if (!bloco.chave) {
    conteudo = <div style={{ ...sans, fontSize: tamSans * 1.5 }}>{linha(bloco.antes)}</div>;
  } else if (temAntes && temDepois) {
    // pequena em cima à esquerda, chave no meio, pequena embaixo à direita
    conteudo = (
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
        <div style={{ alignSelf: "flex-start", marginLeft: "4%", marginBottom: -10 }}>{linha(bloco.antes)}</div>
        {palavraChave}
        <div style={{ alignSelf: "flex-end", marginRight: "2%", marginTop: -4 }}>{linha(bloco.depois)}</div>
      </div>
    );
  } else if (temDepois) {
    // chave grande e a pequena ao lado, alinhadas pela base
    conteudo = (
      <div style={{ display: "flex", alignItems: "flex-end", gap: 14 }}>
        {palavraChave}
        <div style={{ marginBottom: tamChave * 0.12 }}>{linha(bloco.depois)}</div>
      </div>
    );
  } else if (temAntes) {
    // pequena encaixada em cima, à esquerda da chave
    conteudo = (
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
        <div style={{ alignSelf: "flex-start", marginLeft: "2%", marginBottom: -14 }}>{linha(bloco.antes)}</div>
        {palavraChave}
      </div>
    );
  } else {
    conteudo = palavraChave;
  }

  const saida0 = duracaoFrames - SAIDA_FRAMES;
  const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
  return (
    <AbsoluteFill style={{ alignItems: "center", paddingTop: estilo.topo, paddingInline: 70 }}>
      <div
        style={{
          display: "inline-flex",
          opacity: interpolate(frame, [saida0, duracaoFrames], [1, 0], clamp),
          filter: `blur(${interpolate(frame, [saida0, duracaoFrames], [0, 14], clamp)}px)`,
          scale: interpolate(frame, [saida0, duracaoFrames], [1, 1.06], clamp),
        }}
      >
        {conteudo}
      </div>
    </AbsoluteFill>
  );
};

export const LegendaEditorial: React.FC<{
  legendas: Caption[];
  kit: Kit;
  destaques: string[];
  fimMs: number;
  estilo: EstiloLegenda;
}> = ({ legendas, kit, destaques, fimMs, estilo }) => {
  const { fps } = useVideoConfig();
  const blocos = useMemo(
    () => montarBlocos(legendas, new Set(destaques.map(normalizar)), estilo.msPorPagina),
    [legendas, destaques, estilo.msPorPagina],
  );
  return (
    <AbsoluteFill>
      {blocos.map((b, i) => {
        const proximo = blocos[i + 1] ?? null;
        const inicio = Math.round((b.inicioMs / 1000) * fps);
        const fim = Math.round(
          (Math.min(proximo ? proximo.inicioMs : fimMs, b.fimMs + 600, fimMs) / 1000) * fps,
        );
        const dur = fim - inicio;
        if (dur <= 0) return null;
        return (
          <Sequence key={i} from={inicio} durationInFrames={dur} name={`Editorial ${i + 1}`}>
            <BlocoEditorial bloco={b} kit={kit} estilo={estilo} duracaoFrames={dur} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};

import { z } from "zod";
import {
  AbsoluteFill,
  Easing,
  Img,
  Interactive,
  Sequence,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  type CalculateMetadataFunction,
} from "remotion";
import { Video } from "@remotion/media";
import { FONTE, fontesProntas, kitSchema, type Kit } from "../../kit";
import { Legenda } from "./Legenda";

// ---------------------------------------------------------------------------
// Modelo "Fala legendada" v1
// Pessoa falando para a câmera + legenda dinâmica + gancho + tarja legal +
// cartela final de CTA. Recebe o vídeo já limpo (pausas cortadas, áudio
// normalizado, 1080x1920) pelo pipeline em scripts/editar.mjs.
// ---------------------------------------------------------------------------

export const MODELO_ID = "fala-legendada";
export const MODELO_VERSAO = "v1";
const FPS = 30;
const CTA_SEG = 2.5;
const GANCHO_SEG = 3.2;
const ZOOM_SEG = 1.6;

const captionSchema = z.object({
  text: z.string(),
  startMs: z.number(),
  endMs: z.number(),
  timestampMs: z.number().nullable(),
  confidence: z.number().nullable(),
});

export const falaLegendadaSchema = z.object({
  video: z.string(), // caminho dentro de public/
  duracaoVideoSeg: z.number(),
  legendas: z.array(captionSchema),
  gancho: z.string(),
  ctaTitulo: z.string(),
  ctaSubtitulo: z.string(),
  destaques: z.array(z.string()), // palavras que ficam sempre na cor de destaque
  zoomsMs: z.array(z.number()), // momentos de "punch-in" escolhidos na edição
  kit: kitSchema,
});

export type FalaLegendadaProps = z.infer<typeof falaLegendadaSchema>;

export const calcularMetadata: CalculateMetadataFunction<
  FalaLegendadaProps
> = async ({ props }) => {
  await fontesProntas;
  return {
    durationInFrames: Math.ceil(props.duracaoVideoSeg * FPS) + CTA_SEG * FPS,
    defaultOutName: `${MODELO_ID}-${MODELO_VERSAO}`,
  };
};

const Gancho: React.FC<{ texto: string; kit: Kit }> = ({ texto, kit }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill
      style={{ alignItems: "center", paddingTop: 250, paddingInline: 80 }}
    >
      <Interactive.Div
        name="Gancho"
        style={{
          fontFamily: FONTE,
          fontWeight: 900,
          fontSize: 74,
          lineHeight: 1.1,
          textAlign: "center",
          textTransform: "uppercase",
          color: kit.corTextoSobrePrimaria,
          backgroundColor: kit.corPrimaria,
          padding: "26px 40px",
          borderRadius: 24,
          maxWidth: 920,
          boxShadow: "0 18px 40px rgba(0,0,0,0.35)",
          scale: interpolate(frame, [0, 0.35 * fps], [0.6, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: Easing.spring({ damping: 12 }),
            output: "perceptual-scale",
          }),
          opacity: interpolate(
            frame,
            [0, 0.15 * fps, (GANCHO_SEG - 0.25) * fps, GANCHO_SEG * fps],
            [0, 1, 1, 0],
            { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
          ),
        }}
      >
        {texto}
      </Interactive.Div>
    </AbsoluteFill>
  );
};

const Logo: React.FC<{ kit: Kit }> = ({ kit }) =>
  kit.logo ? (
    <AbsoluteFill style={{ padding: "90px 80px" }}>
      <Img
        src={staticFile(kit.logo)}
        style={{ height: 96, width: "auto", alignSelf: "flex-start" }}
      />
    </AbsoluteFill>
  ) : null;

const AvisoLegal: React.FC<{ kit: Kit }> = ({ kit }) =>
  kit.avisoLegal ? (
    <AbsoluteFill
      style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 70 }}
    >
      <div
        style={{
          fontFamily: FONTE,
          fontWeight: 600,
          fontSize: 32,
          color: "white",
          backgroundColor: "rgba(0,0,0,0.6)",
          padding: "10px 26px",
          borderRadius: 999,
        }}
      >
        {kit.avisoLegal}
      </div>
    </AbsoluteFill>
  ) : null;

const CartelaCta: React.FC<{
  titulo: string;
  subtitulo: string;
  kit: Kit;
}> = ({ titulo, subtitulo, kit }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const entrada = (atraso: number) =>
    interpolate(frame, [atraso * fps, (atraso + 0.4) * fps], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
      easing: Easing.bezier(0.16, 1, 0.3, 1),
    });
  return (
    <AbsoluteFill
      style={{
        backgroundColor: kit.corPrimaria,
        justifyContent: "center",
        alignItems: "center",
        gap: 48,
        paddingInline: 90,
        fontFamily: FONTE,
        textAlign: "center",
      }}
    >
      {kit.logo ? (
        <Img
          src={staticFile(kit.logo)}
          style={{ height: 150, width: "auto", opacity: entrada(0) }}
        />
      ) : null}
      <Interactive.Div
        name="CTA título"
        style={{
          fontWeight: 900,
          fontSize: 104,
          lineHeight: 1.05,
          textTransform: "uppercase",
          color: kit.corTextoSobrePrimaria,
          opacity: entrada(0.1),
          translate: interpolate(frame, [0.1 * fps, 0.5 * fps], ["0px 60px", "0px 0px"], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: Easing.bezier(0.16, 1, 0.3, 1),
          }),
        }}
      >
        {titulo}
      </Interactive.Div>
      <Interactive.Div
        name="CTA subtítulo"
        style={{
          fontWeight: 800,
          fontSize: 50,
          color: kit.corPrimaria,
          backgroundColor: kit.corDestaque,
          padding: "18px 40px",
          borderRadius: 999,
          opacity: entrada(0.35),
          scale: interpolate(frame, [0.35 * fps, 0.75 * fps], [0.8, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: Easing.spring({ damping: 12 }),
            output: "perceptual-scale",
          }),
        }}
      >
        {subtitulo}
      </Interactive.Div>
    </AbsoluteFill>
  );
};

export const FalaLegendada: React.FC<FalaLegendadaProps> = (props) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const videoFrames = Math.ceil(props.duracaoVideoSeg * fps);
  const agoraMs = (frame / fps) * 1000;
  const emZoom = props.zoomsMs.some(
    (z) => agoraMs >= z && agoraMs < z + ZOOM_SEG * 1000,
  );

  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      <Sequence durationInFrames={videoFrames} name="Vídeo + legenda">
        <AbsoluteFill
          style={{
            // corte seco de zoom nos momentos escolhidos + leve aproximação contínua
            scale:
              (emZoom ? 1.12 : 1) *
              interpolate(frame, [0, videoFrames], [1, 1.04], {
                extrapolateRight: "clamp",
              }),
          }}
        >
          <Video src={staticFile(props.video)} />
        </AbsoluteFill>
        <Legenda
          legendas={props.legendas}
          kit={props.kit}
          destaques={props.destaques}
          fimMs={props.duracaoVideoSeg * 1000}
        />
        <Sequence durationInFrames={Math.round(GANCHO_SEG * fps)} name="Gancho">
          <Gancho texto={props.gancho} kit={props.kit} />
        </Sequence>
        <Logo kit={props.kit} />
      </Sequence>
      <Sequence from={videoFrames} name="Cartela CTA">
        <CartelaCta
          titulo={props.ctaTitulo}
          subtitulo={props.ctaSubtitulo}
          kit={props.kit}
        />
      </Sequence>
      <AvisoLegal kit={props.kit} />
    </AbsoluteFill>
  );
};

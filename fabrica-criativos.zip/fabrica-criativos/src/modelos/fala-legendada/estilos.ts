// Catálogo de estilos de legenda do modelo "Fala legendada".
// Cada estilo é uma receita: tipografia, como a palavra falada aparece,
// fundo, animação e quantas palavras entram por vez.
// Pesquisa de referência: docs/estilos-de-legenda.md

export type ModoAtivo =
  | "cor" // palavra falada muda para a cor de destaque
  | "caixa" // caixa colorida atrás da palavra falada
  | "preenche" // karaokê: o que já foi dito fica colorido, o resto fica apagado
  | "nenhum"; // sem destaque da palavra falada

export type Fundo = "nenhum" | "escuro" | "marca";
export type Animacao = "pop" | "fade" | "sobe" | "impacto";

export type EstiloLegenda = {
  nome: string;
  descricao: string;
  usarPara: string;
  referencia: string; // família equivalente nos apps de legenda
  fonte: string;
  peso: number;
  tamanho: number; // px em 1080x1920
  caixaAlta: boolean;
  espacamento: number; // letter-spacing em px
  contorno: number; // espessura do contorno preto em px (0 = sem)
  sombra: string;
  modoAtivo: ModoAtivo;
  fundo: Fundo;
  animacao: Animacao;
  msPorPagina: number; // quanto de fala cabe em uma página (0 = uma palavra por vez)
  topo: number; // posição vertical (padding-top) em px
  destaqueItalico?: { fonte: string }; // palavras de destaque em outra fonte, itálico
  rotacao?: number; // graus, alternando entre páginas
};

export const ESTILOS = {
  impacto: {
    nome: "Impacto",
    descricao: "Caixa alta pesada, branco com contorno preto, palavra falada na cor de destaque.",
    usarPara: "Anúncios e conteúdo de performance; leitura rápida.",
    referencia: "Rocket, Grit (Captions); Bold Highlight",
    fonte: "Montserrat",
    peso: 900,
    tamanho: 92,
    caixaAlta: true,
    espacamento: 0,
    contorno: 14,
    sombra: "0 8px 24px rgba(0,0,0,0.55)",
    modoAtivo: "cor",
    fundo: "nenhum",
    animacao: "pop",
    msPorPagina: 1000,
    topo: 1180,
  },
  caixa: {
    nome: "Caixa na palavra",
    descricao: "Caixa alta, sem contorno, sombra forte; caixa colorida corre atrás da palavra falada.",
    usarPara: "Conteúdo de negócio e educativo com ritmo alto.",
    referencia: "estilo 'Hormozi' (Captions, Submagic, CapCut)",
    fonte: "Montserrat",
    peso: 900,
    tamanho: 88,
    caixaAlta: true,
    espacamento: -1,
    contorno: 0,
    sombra: "0 6px 0 rgba(0,0,0,0.85), 0 10px 30px rgba(0,0,0,0.6)",
    modoAtivo: "caixa",
    fundo: "nenhum",
    animacao: "sobe",
    msPorPagina: 1100,
    topo: 1160,
  },
  palavra: {
    nome: "Uma palavra",
    descricao: "Uma palavra por vez, enorme, fonte condensada, entra com impacto e leve rotação.",
    usarPara: "Entretenimento e vídeos de energia alta; ganchos.",
    referencia: "Film, Prism (Captions); estilo 'MrBeast'",
    fonte: "Anton",
    peso: 400,
    tamanho: 170,
    caixaAlta: true,
    espacamento: 1,
    contorno: 16,
    sombra: "0 12px 0 rgba(0,0,0,0.9)",
    modoAtivo: "nenhum",
    fundo: "nenhum",
    animacao: "impacto",
    msPorPagina: 0,
    topo: 1080,
    rotacao: 3,
  },
  karaoke: {
    nome: "Karaokê",
    descricao: "Frase inteira na tela; as palavras acendem na cor de destaque conforme são faladas.",
    usarPara: "Frases de efeito, motivacional, quando o texto completo ajuda a ler.",
    referencia: "Karaoke (Captions, CapCut)",
    fonte: "Montserrat",
    peso: 900,
    tamanho: 78,
    caixaAlta: true,
    espacamento: 0,
    contorno: 12,
    sombra: "0 6px 18px rgba(0,0,0,0.5)",
    modoAtivo: "preenche",
    fundo: "nenhum",
    animacao: "fade",
    msPorPagina: 2200,
    topo: 1140,
  },
  limpo: {
    nome: "Limpo",
    descricao: "Caixa baixa, fonte de leitura, branco com sombra suave, animação discreta.",
    usarPara: "Talking head, educativo, depoimento.",
    referencia: "Clarity, Core (Captions)",
    fonte: "Inter",
    peso: 700,
    tamanho: 70,
    caixaAlta: false,
    espacamento: -1,
    contorno: 0,
    sombra: "0 3px 12px rgba(0,0,0,0.85), 0 0 2px rgba(0,0,0,0.9)",
    modoAtivo: "cor",
    fundo: "nenhum",
    animacao: "fade",
    msPorPagina: 1500,
    topo: 1220,
  },
  faixa: {
    nome: "Faixa escura",
    descricao: "Texto sobre caixa escura translúcida arredondada; legível em qualquer fundo.",
    usarPara: "Vídeos com fundo claro ou poluído; institucional.",
    referencia: "Subtitle Block",
    fonte: "Inter",
    peso: 700,
    tamanho: 64,
    caixaAlta: false,
    espacamento: -0.5,
    contorno: 0,
    sombra: "none",
    modoAtivo: "cor",
    fundo: "escuro",
    animacao: "sobe",
    msPorPagina: 1600,
    topo: 1260,
  },
  marca: {
    nome: "Bloco da marca",
    descricao: "Texto sobre bloco na cor primária da marca, no terço inferior.",
    usarPara: "Profissional, institucional, peças com marca forte.",
    referencia: "Byline, Blueprint (Captions); Colored Background Block",
    fonte: "Montserrat",
    peso: 800,
    tamanho: 66,
    caixaAlta: true,
    espacamento: 0,
    contorno: 0,
    sombra: "none",
    modoAtivo: "cor",
    fundo: "marca",
    animacao: "sobe",
    msPorPagina: 1400,
    topo: 1260,
  },
  elegante: {
    nome: "Elegante",
    descricao: "Serifada refinada em caixa baixa; palavras de destaque em itálico na cor da marca.",
    usarPara: "Lifestyle, premium, benefícios do clube.",
    referencia: "Sonnet, Analog (Captions)",
    fonte: "Playfair Display",
    peso: 600,
    tamanho: 76,
    caixaAlta: false,
    espacamento: 0,
    contorno: 0,
    sombra: "0 4px 18px rgba(0,0,0,0.7)",
    modoAtivo: "nenhum",
    fundo: "nenhum",
    animacao: "fade",
    msPorPagina: 1700,
    topo: 1200,
    destaqueItalico: { fonte: "Playfair Display" },
  },
} satisfies Record<string, EstiloLegenda>;

export type IdEstilo = keyof typeof ESTILOS;
export const IDS_ESTILOS = Object.keys(ESTILOS) as [IdEstilo, ...IdEstilo[]];

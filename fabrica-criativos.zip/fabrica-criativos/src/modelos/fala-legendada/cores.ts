// Cores da palavra em destaque, escolhidas pelo editor no portal.
// Cada cor pronta tem um degradê ajustado à mão (claro -> base -> escuro),
// porque escurecer uma cor de forma automática deixa tons sujos (ex.: amarelo
// vira marrom). Uma cor personalizada (#hex) usa um degradê calculado.

export type Paleta = {
  nome: string;
  claro: string; // topo do degradê
  base: string; // cor principal (também usada no brilho)
  medio: string;
  escuro: string; // base do degradê
};

export const CORES_DESTAQUE = {
  dourado: { nome: "Dourado", claro: "#FFF1C9", base: "#FFB020", medio: "#E8590C", escuro: "#9A3412" },
  verde: { nome: "Verde", claro: "#ECFFE3", base: "#5EE87F", medio: "#16A34A", escuro: "#14532D" },
  azul: { nome: "Azul", claro: "#E3F4FF", base: "#4CC3FF", medio: "#2563EB", escuro: "#1E3A8A" },
  vermelho: { nome: "Vermelho", claro: "#FFE6E2", base: "#FF6A55", medio: "#DC2626", escuro: "#7F1D1D" },
  rosa: { nome: "Rosa", claro: "#FFE8F5", base: "#FF7AC3", medio: "#DB2777", escuro: "#831843" },
  roxo: { nome: "Roxo", claro: "#F4EAFF", base: "#C38BFF", medio: "#9333EA", escuro: "#4C1D95" },
  prata: { nome: "Prata", claro: "#FFFFFF", base: "#E7E9EE", medio: "#A3A9B5", escuro: "#4B5563" },
} satisfies Record<string, Paleta>;

export type IdCor = keyof typeof CORES_DESTAQUE;
export const IDS_CORES = Object.keys(CORES_DESTAQUE) as IdCor[];

const paraRgb = (hex: string): [number, number, number] => {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};
const paraHex = (rgb: number[]) =>
  "#" + rgb.map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, "0")).join("");
const misturar = (a: string, b: string, t: number) => {
  const x = paraRgb(a);
  const y = paraRgb(b);
  return paraHex(x.map((v, i) => v + (y[i] - v) * t));
};

// Aceita o nome de uma cor pronta ("verde") ou um hex ("#00C2A8").
export const paletaDestaque = (cor: string): Paleta => {
  const pronta = (CORES_DESTAQUE as Record<string, Paleta>)[cor.toLowerCase()];
  if (pronta) return pronta;
  const base = /^#?[0-9a-f]{6}$/i.test(cor) ? (cor.startsWith("#") ? cor : `#${cor}`) : CORES_DESTAQUE.dourado.base;
  return {
    nome: base.toUpperCase(),
    claro: misturar(base, "#FFFFFF", 0.78),
    base,
    medio: misturar(base, "#000000", 0.28),
    escuro: misturar(base, "#000000", 0.62),
  };
};

export const rgbDe = (hex: string) => paraRgb(hex).join(", ");

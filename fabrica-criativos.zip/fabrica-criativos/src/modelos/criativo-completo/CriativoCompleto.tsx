import { z } from "zod";
import {
  AbsoluteFill,
  Easing,
  Freeze,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  type CalculateMetadataFunction,
} from "remotion";
import { Audio, Video } from "@remotion/media";
import { fontesProntas, kitSchema } from "../../kit";
import { LegendaEditorial } from "../fala-legendada/LegendaEditorial";
import { ESTILOS } from "../fala-legendada/estilos";
import { ZonaDebugNoTempo, rostosSchema, type Caixa, type Rostos } from "../../zona-protegida";

// ---------------------------------------------------------------------------
// Modelo "Criativo completo" v1 — edição de alta performance
// Em cima do vídeo limpo (pausas cortadas, áudio normalizado):
//  · câmera: punch-ins nos ganchos da fala + aproximação contínua, sempre
//    centrados no rosto; flash curto nas viradas de assunto
//  · tratamento de cor (contraste/saturação) + vinheta
//  · legenda Editorial (aprovada) com a palavra-chave em destaque
//  · motion: gancho cinético na abertura, cards dos assuntos citados na fala,
//    selo +18 quando ele fala de responsabilidade, CTA pulsando no fim
//  · desenho de som: whoosh, pop, impacto + trilha de fundo baixa
//  · cartela final congelando o último quadro, barra de progresso, aviso legal
// REGRA DO ROSTO: a zona protegida acompanha o zoom da câmera quadro a quadro;
// legenda e todos os elementos ficam fora dela.
// ---------------------------------------------------------------------------

const FPS = 30;
const captionSchema = z.object({
  text: z.string(),
  startMs: z.number(),
  endMs: z.number(),
  timestampMs: z.number().nullable(),
  confidence: z.number().nullable(),
});

export const criativoCompletoSchema = z.object({
  video: z.string(),
  duracaoVideoSeg: z.number(),
  legendas: z.array(captionSchema),
  destaques: z.array(z.string()),
  corLegenda: z.string().optional(),
  ritmoFala: z.enum(["auto", "normal", "rapida"]).optional(),
  // câmera: a partir de `ms`, o zoom vai para `zoom` (punch rápido); flash = clarão na virada
  camera: z.array(z.object({ ms: z.number(), zoom: z.number(), flash: z.boolean().optional() })),
  gancho: z.object({ linha1: z.string(), linha2: z.string(), ateMs: z.number() }).optional(),
  cards: z
    .object({ itens: z.array(z.object({ texto: z.string(), icone: z.string(), ms: z.number() })), ateMs: z.number() })
    .optional(),
  selo18: z.object({ deMs: z.number(), ateMs: z.number(), texto: z.string() }).optional(),
  cta: z.object({ deMs: z.number(), texto: z.string(), apoio: z.string().optional(), cartelaSeg: z.number().default(2.5) }),
  aviso: z.string(),
  trilha: z.object({ src: z.string(), volume: z.number() }).optional(),
  kit: kitSchema,
  rostos: rostosSchema,
  mostrarZona: z.boolean().optional(),
});
export type CriativoCompletoProps = z.input<typeof criativoCompletoSchema>;

export const calcularMetadataCC: CalculateMetadataFunction<CriativoCompletoProps> = async ({ props }) => {
  await fontesProntas;
  return {
    durationInFrames: Math.ceil(props.duracaoVideoSeg * FPS) + Math.round((props.cta.cartelaSeg ?? 2.5) * FPS),
    defaultOutName: "criativo-completo-v1",
  };
};

// ---------- câmera ----------
const PUNCH_MS = 170;
function zoomEm(ms: number, camera: CriativoCompletoProps["camera"], totalMs: number) {
  let z = 1;
  let anterior = 1;
  for (const k of camera) {
    if (ms < k.ms) break;
    anterior = z;
    z = k.zoom;
    const t = (ms - k.ms) / PUNCH_MS;
    if (t < 1) z = anterior + (k.zoom - anterior) * Easing.bezier(0.2, 0.9, 0.2, 1)(t);
  }
  const deriva = 1 + 0.035 * Math.min(1, ms / totalMs); // aproximação contínua, quase imperceptível
  return z * deriva;
}
// centro do zoom = centro mediano do rosto (o rosto cresce no lugar, nunca sai do quadro)
function origemRosto(rostos: Rostos) {
  if (!rostos?.amostras.length) return { x: 540, y: 760 };
  const xs = rostos.amostras.map((a) => a.rosto[0] + a.rosto[2] / 2).sort((a, b) => a - b);
  const ys = rostos.amostras.map((a) => a.rosto[1] + a.rosto[3] / 2).sort((a, b) => a - b);
  return { x: xs[xs.length >> 1], y: ys[ys.length >> 1] };
}
// zona protegida com o zoom da câmera aplicado amostra por amostra
function rostosComCamera(rostos: Rostos, o: { x: number; y: number }, zoomNoTempo: (ms: number) => number): Rostos {
  if (!rostos) return rostos;
  const ampliar = (a: number[], s: number) => {
    const x0 = Math.max(0, o.x + (a[0] - o.x) * s);
    const y0 = Math.max(0, o.y + (a[1] - o.y) * s);
    const x1 = Math.min(rostos.largura, o.x + (a[0] + a[2] - o.x) * s);
    const y1 = Math.min(rostos.altura, o.y + (a[1] + a[3] - o.y) * s);
    return [x0, y0, x1 - x0, y1 - y0];
  };
  const maxPerto = (ms: number) => Math.max(zoomNoTempo(ms - 220), zoomNoTempo(ms), zoomNoTempo(ms + 220));
  let maxGeral = 1;
  const amostras = rostos.amostras.map((a) => {
    const s = maxPerto(a.tMs);
    maxGeral = Math.max(maxGeral, s);
    return { ...a, zona: ampliar(a.zona, s) };
  });
  return { ...rostos, amostras, uniao: rostos.uniao ? ampliar(rostos.uniao, maxGeral) : null };
}

// ---------- utilidades de motion ----------
const molaEm = (frame: number, fps: number, inicio: number, damping = 13) =>
  spring({ frame: frame - inicio, fps, config: { damping, stiffness: 180, mass: 0.7 } });
const saida = (frame: number, fim: number, dur = 6) =>
  interpolate(frame, [fim - dur, fim], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });

const fonteMotion: React.CSSProperties = { fontFamily: "Inter", fontWeight: 900, fontStyle: "italic", textTransform: "uppercase", letterSpacing: -0.5 };

// Gancho cinético: palavras entram uma a uma; a 2ª linha vem num bloco de cor
const Gancho: React.FC<{ linha1: string; linha2: string; fimF: number; cor: string; y: number }> = ({ linha1, linha2, fimF, cor, y }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p1 = linha1.split(" ");
  const p2 = linha2.split(" ");
  const sai = saida(frame, fimF, 5);
  return (
    <AbsoluteFill style={{ top: y, height: "auto", alignItems: "center", gap: 10, opacity: sai, translate: `0 ${(1 - sai) * 30}px` }}>
      <div style={{ ...fonteMotion, fontSize: 68, color: "white", display: "flex", gap: 18, textShadow: "0 6px 24px rgba(0,0,0,0.55)" }}>
        {p1.map((w, i) => {
          const m = molaEm(frame, fps, i * 3);
          return (
            <span key={i} style={{ display: "inline-block", opacity: Math.min(1, m * 1.4), scale: 0.6 + 0.4 * m, translate: `0 ${(1 - m) * 40}px` }}>
              {w}
            </span>
          );
        })}
      </div>
      {(() => {
        const ini = p1.length * 3 + 2;
        const caixa = molaEm(frame, fps, ini, 11);
        return (
          <div
            style={{
              ...fonteMotion,
              fontSize: 84,
              color: "#111",
              backgroundColor: cor,
              padding: "6px 30px 2px",
              borderRadius: 10,
              rotate: "-2deg",
              scale: 0.5 + 0.5 * caixa,
              opacity: Math.min(1, caixa * 1.5),
              boxShadow: `0 14px 40px rgba(0,0,0,0.45)`,
              display: "flex",
              gap: 20,
            }}
          >
            {p2.map((w, i) => {
              const m = molaEm(frame, fps, ini + 2 + i * 3);
              return (
                <span key={i} style={{ display: "inline-block", opacity: Math.min(1, m * 1.4), translate: `0 ${(1 - m) * 26}px` }}>
                  {w}
                </span>
              );
            })}
          </div>
        );
      })()}
    </AbsoluteFill>
  );
};

// Cards dos assuntos citados: entram da esquerda no momento em que a palavra é dita
const Cards: React.FC<{ itens: { texto: string; icone: string; inicioF: number }[]; fimF: number; cor: string; y: number }> = ({ itens, fimF, cor, y }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const sai = saida(frame, fimF, 6);
  return (
    <AbsoluteFill style={{ top: y, height: "auto", alignItems: "center", gap: 14, opacity: sai }}>
      {itens.map((it, i) => {
        const m = molaEm(frame, fps, it.inicioF, 14);
        const ativo = frame >= it.inicioF && (i === itens.length - 1 || frame < itens[i + 1].inicioF);
        return (
          <div
            key={i}
            style={{
              ...fonteMotion,
              fontSize: 50,
              display: "flex",
              alignItems: "center",
              gap: 18,
              padding: "12px 34px 10px 20px",
              borderRadius: 14,
              backgroundColor: ativo ? cor : "rgba(255,255,255,0.96)",
              color: "#111",
              opacity: frame < it.inicioF ? 0 : Math.min(1, m * 1.6),
              translate: `${(1 - m) * -420 + (i - 1) * 28}px 0`,
              rotate: `${(1 - m) * -8}deg`,
              boxShadow: "0 12px 30px rgba(0,0,0,0.35)",
            }}
          >
            <span style={{ fontStyle: "normal", fontSize: 44 }}>{it.icone}</span>
            {it.texto}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

const Selo18: React.FC<{ texto: string; fimF: number; cor: string; y: number }> = ({ texto, fimF, cor, y }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const m = molaEm(frame, fps, 0, 10);
  const sai = saida(frame, fimF, 6);
  return (
    <AbsoluteFill style={{ top: y, height: "auto", alignItems: "center", opacity: sai }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 20,
          backgroundColor: "rgba(12,12,12,0.86)",
          border: `3px solid ${cor}`,
          borderRadius: 999,
          padding: "12px 34px 12px 14px",
          scale: 0.4 + 0.6 * m,
          opacity: Math.min(1, m * 1.5),
        }}
      >
        <div
          style={{
            width: 86,
            height: 86,
            borderRadius: 999,
            backgroundColor: cor,
            color: "#111",
            fontFamily: "Inter",
            fontWeight: 900,
            fontSize: 36,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            rotate: `${(1 - m) * -180}deg`,
          }}
        >
          +18
        </div>
        <div style={{ ...fonteMotion, fontSize: 40, color: "white", lineHeight: 1.05 }}>{texto}</div>
      </div>
    </AbsoluteFill>
  );
};

const Cta: React.FC<{ texto: string; apoio?: string; cor: string; y: number }> = ({ texto, apoio, cor, y }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const m = molaEm(frame, fps, 0, 11);
  const pulso = 1 + 0.035 * Math.max(0, Math.sin(((frame - 10) / fps) * Math.PI * 2.2));
  const brilho = interpolate((frame % 40) / 40, [0, 1], [-30, 130]);
  return (
    <AbsoluteFill style={{ top: y, height: "auto", alignItems: "center", gap: 16 }}>
      {apoio ? (
        <div style={{ ...fonteMotion, fontSize: 40, color: "white", opacity: Math.min(1, m * 1.5), textShadow: "0 4px 18px rgba(0,0,0,0.7)" }}>{apoio}</div>
      ) : null}
      <div
        style={{
          ...fonteMotion,
          fontSize: 66,
          color: "#111",
          backgroundColor: cor,
          padding: "20px 56px 16px",
          borderRadius: 16,
          scale: (0.5 + 0.5 * m) * pulso,
          opacity: Math.min(1, m * 1.5),
          boxShadow: `0 0 0 6px rgba(255,255,255,0.18), 0 18px 46px rgba(0,0,0,0.5)`,
          backgroundImage: `linear-gradient(105deg, transparent ${brilho - 12}%, rgba(255,255,255,0.55) ${brilho}%, transparent ${brilho + 12}%)`,
          whiteSpace: "nowrap",
        }}
      >
        {texto}
      </div>
    </AbsoluteFill>
  );
};

const Aviso: React.FC<{ texto: string }> = ({ texto }) => (
  <AbsoluteFill style={{ justifyContent: "flex-end", paddingInline: 56, paddingBottom: 54 }}>
    <div style={{ display: "flex", alignItems: "center", gap: 12, color: "white", fontFamily: "Inter", textShadow: "0 1px 6px rgba(0,0,0,0.8)" }}>
      <div
        style={{
          width: 40,
          height: 40,
          borderRadius: 999,
          border: "2px solid white",
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontWeight: 800,
          fontSize: 15,
        }}
      >
        +18
      </div>
      <div style={{ fontSize: 18.5, lineHeight: 1.22, fontWeight: 500 }}>{texto}</div>
    </div>
  </AbsoluteFill>
);

const Flash: React.FC = () => {
  const frame = useCurrentFrame();
  return <AbsoluteFill style={{ backgroundColor: "white", opacity: interpolate(frame, [0, 1, 5], [0.55, 0.35, 0], { extrapolateRight: "clamp" }) }} />;
};

export const CriativoCompleto: React.FC<CriativoCompletoProps> = (props) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const videoF = Math.ceil(props.duracaoVideoSeg * fps);
  const totalMs = props.duracaoVideoSeg * 1000;
  const f = (ms: number) => Math.round((ms / 1000) * fps);
  const cor = props.corLegenda?.startsWith("#") ? props.corLegenda : props.kit.corDestaque;

  // câmera e zona protegida
  const origem = origemRosto(props.rostos);
  const zoomNoTempo = (ms: number) => zoomEm(Math.min(ms, totalMs), props.camera, totalMs);
  const rostos = rostosComCamera(props.rostos, origem, zoomNoTempo);
  const msAgora = (Math.min(frame, videoF - 1) / fps) * 1000;
  const zoom = zoomNoTempo(msAgora);

  // faixa inferior dos elementos de motion (abaixo do rosto, acima do aviso);
  // a legenda recebe esses elementos como obstáculos e se reposiciona
  const yMotion = 1470;
  const caixaMotion = (h: number): Caixa => ({ x: 60, y: yMotion, w: 960, h });
  const obstaculos = [
    ...(props.gancho ? [{ deMs: 0, ateMs: props.gancho.ateMs, caixa: caixaMotion(250) }] : []),
    ...(props.cards ? [{ deMs: props.cards.itens[0].ms, ateMs: props.cards.ateMs, caixa: { x: 60, y: 1390, w: 960, h: 330 } }] : []),
    ...(props.selo18 ? [{ deMs: props.selo18.deMs, ateMs: props.selo18.ateMs, caixa: caixaMotion(120) }] : []),
    { deMs: props.cta.deMs, ateMs: 1e9, caixa: { x: 60, y: 1500, w: 960, h: 210 } },
  ];

  const tratamento = "contrast(1.08) saturate(1.16) brightness(1.02)";
  const camadaVideo = (congelado: boolean) => (
    <AbsoluteFill style={{ transformOrigin: `${origem.x}px ${origem.y}px`, scale: congelado ? 1 : zoom, filter: tratamento }}>
      <Video src={staticFile(props.video)} muted={congelado} />
    </AbsoluteFill>
  );

  const progresso = Math.min(1, frame / (durationInFrames - 1));
  const sfx = (src: string, ms: number, volume = 0.5) => (
    <Sequence key={`${src}-${ms}`} from={Math.max(0, f(ms))} durationInFrames={f(800)} layout="none">
      <Audio src={staticFile(`sfx/${src}.wav`)} volume={volume} />
    </Sequence>
  );

  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      {/* vídeo com câmera */}
      <Sequence durationInFrames={videoF} name="Vídeo + câmera">
        {camadaVideo(false)}
      </Sequence>
      {/* cartela final: congela o último quadro e segue aproximando devagar */}
      <Sequence from={videoF} name="Cartela final (quadro congelado)">
        <AbsoluteFill
          style={{
            transformOrigin: `${origem.x}px ${origem.y}px`,
            scale: zoomNoTempo(totalMs) * interpolate(frame - videoF, [0, 90], [1, 1.05], { extrapolateRight: "clamp" }),
          }}
        >
          <Freeze frame={videoF - 1}>{camadaVideo(true)}</Freeze>
        </AbsoluteFill>
        <AbsoluteFill style={{ backgroundColor: "black", opacity: interpolate(frame - videoF, [0, 12], [0, 0.28], { extrapolateRight: "clamp" }) }} />
      </Sequence>

      {/* vinheta + escurecimento da base para legibilidade */}
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse 85% 70% at 50% 38%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.42) 100%), linear-gradient(180deg, rgba(0,0,0,0) 52%, rgba(0,0,0,0.5) 82%, rgba(0,0,0,0.78) 100%)",
        }}
      />

      {/* flashes nas viradas */}
      {props.camera
        .filter((k) => k.flash)
        .map((k) => (
          <Sequence key={k.ms} from={f(k.ms)} durationInFrames={6} name="Flash">
            <Flash />
          </Sequence>
        ))}

      {/* legenda Editorial */}
      <Sequence durationInFrames={videoF} name="Legenda Editorial">
        <LegendaEditorial
          legendas={props.legendas}
          kit={props.kit}
          destaques={props.destaques}
          fimMs={Math.min(totalMs, props.cta.deMs + 2000)}
          estilo={ESTILOS.editorial}
          ritmoFala={props.ritmoFala}
          corLegenda={props.corLegenda}
          rostos={rostos}
          obstaculos={obstaculos}
        />
      </Sequence>

      {/* motion */}
      {props.gancho ? (
        <Sequence durationInFrames={f(props.gancho.ateMs)} name="Gancho">
          <Gancho linha1={props.gancho.linha1} linha2={props.gancho.linha2} fimF={f(props.gancho.ateMs)} cor={cor} y={yMotion} />
        </Sequence>
      ) : null}
      {props.cards ? (
        <Sequence from={f(props.cards.itens[0].ms) - 2} durationInFrames={f(props.cards.ateMs - props.cards.itens[0].ms) + 2} name="Cards">
          <Cards
            itens={props.cards.itens.map((it) => ({ ...it, inicioF: f(it.ms - props.cards!.itens[0].ms) + 2 }))}
            fimF={f(props.cards.ateMs - props.cards.itens[0].ms) + 2}
            cor={cor}
            y={1400}
          />
        </Sequence>
      ) : null}
      {props.selo18 ? (
        <Sequence from={f(props.selo18.deMs)} durationInFrames={f(props.selo18.ateMs - props.selo18.deMs)} name="Selo +18">
          <Selo18 texto={props.selo18.texto} fimF={f(props.selo18.ateMs - props.selo18.deMs)} cor={cor} y={1560} />
        </Sequence>
      ) : null}
      <Sequence from={f(props.cta.deMs)} name="CTA">
        <Cta texto={props.cta.texto} apoio={props.cta.apoio} cor={cor} y={1500} />
      </Sequence>

      <Aviso texto={props.aviso} />
      {/* barra de progresso (base do quadro, longe do rosto) */}
      <div style={{ position: "absolute", left: 0, bottom: 0, height: 10, width: `${progresso * 100}%`, backgroundColor: cor }} />

      {props.mostrarZona && rostos ? <ZonaDebugNoTempo rostos={rostos} /> : null}

      {/* som */}
      {props.trilha ? <Audio src={staticFile(props.trilha.src)} volume={props.trilha.volume} /> : null}
      {props.gancho ? sfx("whoosh", 0, 0.45) : null}
      {props.camera.filter((k) => k.ms > 0 && k.zoom > 1.05).map((k) => sfx("whoosh", k.ms - 250, 0.28))}
      {props.cards?.itens.map((it) => sfx("pop", it.ms, 0.5))}
      {props.selo18 ? sfx("pop", props.selo18.deMs, 0.55) : null}
      {sfx("impacto", props.cta.deMs, 0.6)}
      {sfx("tick", props.duracaoVideoSeg * 1000, 0.6)}
    </AbsoluteFill>
  );
};

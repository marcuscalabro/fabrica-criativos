import { z } from "zod";
import {
  AbsoluteFill,
  Freeze,
  OffthreadVideo,
  Sequence,
  interpolate,
  random,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  type CalculateMetadataFunction,
} from "remotion";
import { Audio, Video } from "@remotion/media";
import { fontesProntas } from "../../kit";
import { LegendaEditorial } from "../fala-legendada/LegendaEditorial";
import { ESTILOS } from "../fala-legendada/estilos";
import { ZonaDebugNoTempo, alocar, zonaNoIntervalo } from "../../zona-protegida";
import {
  Aviso,
  Cards,
  Cta,
  Selo18,
  criativoCompletoSchema,
  fonteMotion,
  molaEm,
  origemRosto,
  rostosComCamera,
  saida,
  zoomEm,
} from "./CriativoCompleto";

// ---------------------------------------------------------------------------
// Modelo "Criativo completo" — nível AVANÇADO
// O expert é recortado do fundo (scripts/recortar-pessoa.py), o que cria 3
// camadas: FUNDO · ATRÁS DO EXPERT · EXPERT · FRENTE.
//  · atrás do expert: títulos gigantes (capa de revista), letreiros correndo,
//    explosão de partículas, onda de cor, luz vazando — dá pra encher de motion
//    sem nunca passar na frente do rosto e sem poluir a área de leitura
//  · foco: nos momentos de motion o fundo escurece, perde cor e desfoca, e o
//    expert ganha um contorno de luz na cor da marca
//  · câmera: punch-ins com borrão de movimento, tremor no impacto
//  · frente: REGRA DE FOCO — um elemento por vez no centro (legenda OU motion)
// ---------------------------------------------------------------------------

const efeitoAtras = z.discriminatedUnion("tipo", [
  z.object({ tipo: z.literal("capa"), deMs: z.number(), ateMs: z.number(), pequeno: z.string(), grande: z.string() }),
  z.object({ tipo: z.literal("letreiro"), deMs: z.number(), ateMs: z.number(), texto: z.string() }),
  z.object({ tipo: z.literal("particulas"), ms: z.number(), emoji: z.string(), quantidade: z.number().default(16) }),
  z.object({ tipo: z.literal("onda"), ms: z.number() }),
  z.object({ tipo: z.literal("luz"), deMs: z.number(), ateMs: z.number() }),
]);

export const criativoAvancadoSchema = criativoCompletoSchema.extend({
  pessoa: z.string(), // vídeo do expert recortado (webm com transparência)
  atras: z.array(efeitoAtras),
  foco: z.array(z.object({ deMs: z.number(), ateMs: z.number() })), // fundo escurece + contorno de luz
  tremores: z.array(z.number()), // impacto: tremor de câmera
});
export type CriativoAvancadoProps = z.input<typeof criativoAvancadoSchema>;

export const calcularMetadataAvancado: CalculateMetadataFunction<CriativoAvancadoProps> = async ({ props }) => {
  await fontesProntas;
  return {
    durationInFrames: Math.ceil(props.duracaoVideoSeg * 30) + Math.round((props.cta.cartelaSeg ?? 2.5) * 30),
    defaultOutName: "criativo-completo-avancado",
  };
};

// ---------- efeitos atrás do expert ----------
const Capa: React.FC<{ pequeno: string; grande: string; fimF: number; cor: string }> = ({ pequeno, grande, fimF, cor }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const m1 = molaEm(frame, fps, 0, 14);
  const m2 = molaEm(frame, fps, 4, 9);
  const sai = saida(frame, fimF, 6);
  const deriva = interpolate(frame, [0, fimF], [0, -24]);
  return (
    <AbsoluteFill style={{ alignItems: "center", paddingTop: 70, opacity: sai, translate: `0 ${deriva}px` }}>
      <div style={{ ...fonteMotion, fontSize: 104, color: "white", opacity: m1, translate: `${(1 - m1) * -300}px 0`, lineHeight: 1 }}>{pequeno}</div>
      <div
        style={{
          ...fonteMotion,
          fontSize: 300,
          lineHeight: 0.92,
          color: cor,
          letterSpacing: -6,
          scale: 1.5 - 0.5 * m2,
          opacity: Math.min(1, m2 * 1.6),
          textShadow: `0 0 60px ${cor}88`,
          filter: `blur(${(1 - Math.min(1, m2)) * 14}px)`,
        }}
      >
        {grande}
      </div>
    </AbsoluteFill>
  );
};

const Letreiro: React.FC<{ texto: string; fimF: number; cor: string }> = ({ texto, fimF, cor }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const ent = molaEm(frame, fps, 0, 16);
  const sai = saida(frame, fimF, 6);
  const faixa = (y: number, rot: number, dir: number, fundo: string, corTxt: string, atraso: number) => {
    const m = molaEm(frame, fps, atraso, 16);
    const desloc = (frame * 14 * dir) % 1400;
    const linha = Array(8).fill(`${texto} ✦ `).join("");
    return (
      <div
        style={{
          position: "absolute",
          left: -300,
          right: -300,
          top: y,
          rotate: `${rot}deg`,
          backgroundColor: fundo,
          padding: "10px 0 4px",
          overflow: "hidden",
          whiteSpace: "nowrap",
          scale: `${m} 1`,
          boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
        }}
      >
        <div style={{ ...fonteMotion, fontSize: 92, color: corTxt, translate: `${-700 + desloc}px 0` }}>{linha}</div>
      </div>
    );
  };
  return (
    <AbsoluteFill style={{ opacity: sai * Math.min(1, ent * 2) }}>
      {faixa(150, -6, 1, cor, "#111", 0)}
      {faixa(330, 5, -1, "#111", "white", 3)}
    </AbsoluteFill>
  );
};

const Particulas: React.FC<{ emoji: string; quantidade: number; origem: { x: number; y: number }; semente: string }> = ({ emoji, quantidade, origem, semente }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  return (
    <AbsoluteFill>
      {Array.from({ length: quantidade }).map((_, i) => {
        const ang = -Math.PI / 2 + (random(`${semente}a${i}`) - 0.5) * Math.PI * 1.5;
        const vel = 900 + random(`${semente}v${i}`) * 900;
        const x = origem.x + Math.cos(ang) * vel * t;
        const y = origem.y + Math.sin(ang) * vel * t + 1600 * t * t;
        const tam = 60 + random(`${semente}s${i}`) * 70;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x - tam / 2,
              top: y - tam / 2,
              fontSize: tam,
              rotate: `${(random(`${semente}r${i}`) - 0.5) * 720 * t}deg`,
              opacity: interpolate(t, [0, 0.05, 1.1, 1.4], [0, 1, 1, 0], { extrapolateRight: "clamp" }),
            }}
          >
            {emoji}
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

const Onda: React.FC<{ cor: string; origem: { x: number; y: number } }> = ({ cor, origem }) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ backgroundColor: cor, opacity: interpolate(frame, [0, 2, 16], [0, 0.55, 0], { extrapolateRight: "clamp" }), mixBlendMode: "overlay" }} />
      {[0, 5].map((d) => {
        const r = interpolate(frame - d, [0, 22], [80, 1500], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        return (
          <div
            key={d}
            style={{
              position: "absolute",
              left: origem.x - r,
              top: origem.y - r,
              width: r * 2,
              height: r * 2,
              borderRadius: "50%",
              border: `${14 - d}px solid ${cor}`,
              opacity: interpolate(frame - d, [0, 4, 22], [0, 0.9, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

const Luz: React.FC<{ fimF: number }> = ({ fimF }) => {
  const frame = useCurrentFrame();
  const x = interpolate(frame, [0, fimF], [-20, 120]);
  return (
    <AbsoluteFill
      style={{
        mixBlendMode: "screen",
        opacity: interpolate(frame, [0, 8, fimF - 8, fimF], [0, 0.85, 0.85, 0], { extrapolateRight: "clamp" }),
        background: `radial-gradient(ellipse 60% 35% at ${x}% 18%, rgba(255,170,60,0.75), rgba(255,90,40,0.25) 45%, transparent 70%), radial-gradient(ellipse 40% 30% at ${100 - x}% 8%, rgba(255,220,140,0.5), transparent 70%)`,
      }}
    />
  );
};

export const CriativoAvancado: React.FC<CriativoAvancadoProps> = (props) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const videoF = Math.ceil(props.duracaoVideoSeg * fps);
  const totalMs = props.duracaoVideoSeg * 1000;
  const f = (ms: number) => Math.round((ms / 1000) * fps);
  const cor = props.corLegenda?.startsWith("#") ? props.corLegenda : props.kit.corDestaque;
  const ms = (Math.min(frame, videoF - 1) / fps) * 1000;
  const msReal = (frame / fps) * 1000;

  // câmera + zona do rosto
  const origem = origemRosto(props.rostos);
  const zoomNoTempo = (t: number) => zoomEm(Math.min(t, totalMs), props.camera, totalMs);
  const rostos = rostosComCamera(props.rostos, origem, zoomNoTempo);
  const zoomFinal = frame >= videoF ? zoomNoTempo(totalMs) * interpolate(frame - videoF, [0, 90], [1, 1.05], { extrapolateRight: "clamp" }) : zoomNoTempo(ms);

  // borrão de movimento nos punch-ins (3 quadros)
  const borrao = props.camera.some((k) => k.ms > 0 && frame >= f(k.ms) && frame < f(k.ms) + 3) ? 5 : 0;
  // tremor no impacto
  const tremor = props.tremores.reduce((acc, t) => {
    const d = frame - f(t);
    if (d < 0 || d > 10) return acc;
    const k = (1 - d / 10) * 22;
    return { x: acc.x + (random(`tx${t}${d}`) - 0.5) * k, y: acc.y + (random(`ty${t}${d}`) - 0.5) * k };
  }, { x: 0, y: 0 });

  // foco: fundo escurece/desfoca, expert ganha contorno de luz (entra e sai em 6 quadros)
  const nivelFoco = Math.max(
    0,
    ...props.foco.map((j) =>
      interpolate(msReal, [j.deMs - 120, j.deMs + 80, j.ateMs - 100, j.ateMs + 100], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
    ),
  );

  // REGRA DE FOCO na frente: um elemento por vez, no centro
  const PREF_Y = 1120;
  const lugar = (altura: number, deMs: number, ateMs: number) =>
    alocar(altura, PREF_Y, [zonaNoIntervalo(rostos, deMs, ateMs)], { min: 110, max: 1720, folga: 40 });
  const frente = [
    ...(props.cards ? [{ deMs: props.cards.itens[0].ms - 80, ateMs: props.cards.ateMs, altura: 290 }] : []),
    ...(props.selo18 ? [{ deMs: props.selo18.deMs - 80, ateMs: props.selo18.ateMs, altura: 120 }] : []),
    { deMs: props.cta.deMs - 80, ateMs: 1e9, altura: 190 },
  ];
  const posCards = props.cards ? lugar(290, frente[0].deMs, frente[0].ateMs) : null;
  const posSelo = props.selo18 ? lugar(120, props.selo18.deMs, props.selo18.ateMs) : null;
  const posCta = lugar(190, props.cta.deMs, totalMs);
  // títulos e letreiros atrás do expert também "falam": a legenda dá a vez a eles
  const pausas = [
    ...frente.map(({ deMs, ateMs }) => ({ deMs, ateMs: ateMs + 60 })),
    ...props.atras.filter((e) => e.tipo === "capa" || e.tipo === "letreiro").map((e) => ({ deMs: (e as { deMs: number }).deMs - 80, ateMs: (e as { ateMs: number }).ateMs + 60 })),
  ];
  const legendas = props.legendas.filter((l) => !pausas.some((p) => l.startMs >= p.deMs && l.startMs < p.ateMs));

  const tratamento = (foco: number) =>
    `contrast(${1.08 + 0.06 * foco}) saturate(${1.16 - 0.85 * foco}) brightness(${1.02 - 0.5 * foco}) blur(${foco * 7 + borrao}px)`;
  const camera: React.CSSProperties = {
    transformOrigin: `${origem.x}px ${origem.y}px`,
    scale: zoomFinal,
    translate: `${tremor.x}px ${tremor.y}px`,
  };
  const congelar = (el: React.ReactNode) => (frame >= videoF ? <Freeze frame={videoF - 1}>{el}</Freeze> : el);
  const centroCabeca = { x: origem.x, y: origem.y - 120 };

  const sfx = (src: string, t: number, volume = 0.5) => (
    <Sequence key={`${src}-${t}`} from={Math.max(0, f(t))} durationInFrames={f(1400)} layout="none">
      <Audio src={staticFile(`sfx/${src}.wav`)} volume={volume} />
    </Sequence>
  );

  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      {/* 1 · FUNDO (o vídeo inteiro, tratado) */}
      <AbsoluteFill style={camera}>
        <AbsoluteFill style={{ filter: tratamento(nivelFoco) }}>{congelar(<Video src={staticFile(props.video)} muted={frame >= videoF} />)}</AbsoluteFill>
      </AbsoluteFill>

      {/* 2 · ATRÁS DO EXPERT */}
      {props.atras.map((e, i) => {
        if (e.tipo === "capa")
          return (
            <Sequence key={i} from={f(e.deMs)} durationInFrames={f(e.ateMs - e.deMs)} name="Atrás · capa">
              <Capa pequeno={e.pequeno} grande={e.grande} fimF={f(e.ateMs - e.deMs)} cor={cor} />
            </Sequence>
          );
        if (e.tipo === "letreiro")
          return (
            <Sequence key={i} from={f(e.deMs)} durationInFrames={f(e.ateMs - e.deMs)} name="Atrás · letreiro">
              <Letreiro texto={e.texto} fimF={f(e.ateMs - e.deMs)} cor={cor} />
            </Sequence>
          );
        if (e.tipo === "particulas")
          return (
            <Sequence key={i} from={f(e.ms)} durationInFrames={f(1500)} name="Atrás · partículas">
              <Particulas emoji={e.emoji} quantidade={e.quantidade ?? 16} origem={{ x: centroCabeca.x, y: centroCabeca.y + 200 }} semente={`p${i}`} />
            </Sequence>
          );
        if (e.tipo === "onda")
          return (
            <Sequence key={i} from={f(e.ms)} durationInFrames={24} name="Atrás · onda">
              <Onda cor={cor} origem={centroCabeca} />
            </Sequence>
          );
        return (
          <Sequence key={i} from={f(e.deMs)} durationInFrames={f(e.ateMs - e.deMs)} name="Atrás · luz">
            <Luz fimF={f(e.ateMs - e.deMs)} />
          </Sequence>
        );
      })}

      {/* 3 · EXPERT recortado (mesma câmera); contorno de luz no foco */}
      <AbsoluteFill style={camera}>
        <AbsoluteFill
          style={{
            filter: `contrast(1.08) saturate(1.16) brightness(1.02) blur(${borrao}px) drop-shadow(0 0 ${2 + 16 * nivelFoco}px ${cor}${Math.round(nivelFoco * 230).toString(16).padStart(2, "0")})`,
          }}
        >
          {congelar(<OffthreadVideo src={staticFile(props.pessoa)} transparent muted />)}
        </AbsoluteFill>
      </AbsoluteFill>

      {/* vinheta + base escura para leitura */}
      <AbsoluteFill
        style={{
          background:
            "radial-gradient(ellipse 85% 70% at 50% 38%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.42) 100%), linear-gradient(180deg, rgba(0,0,0,0) 55%, rgba(0,0,0,0.45) 82%, rgba(0,0,0,0.75) 100%)",
        }}
      />
      {/* clarão nos cortes de assunto */}
      {props.camera
        .filter((k) => k.flash)
        .map((k) => (
          <Sequence key={k.ms} from={f(k.ms)} durationInFrames={6} name="Flash">
            <AbsoluteFill style={{ backgroundColor: "white", opacity: interpolate(frame - f(k.ms), [0, 1, 5], [0.5, 0.3, 0], { extrapolateRight: "clamp" }) }} />
          </Sequence>
        ))}

      {/* 4 · FRENTE — um elemento por vez, no centro */}
      <Sequence durationInFrames={videoF} name="Legenda Editorial">
        <LegendaEditorial
          legendas={legendas}
          kit={props.kit}
          destaques={props.destaques}
          fimMs={totalMs}
          estilo={ESTILOS.editorial}
          ritmoFala={props.ritmoFala}
          corLegenda={props.corLegenda}
          rostos={rostos}
          pausas={pausas}
        />
      </Sequence>
      {props.cards && posCards ? (
        <Sequence from={f(props.cards.itens[0].ms) - 2} durationInFrames={f(props.cards.ateMs - props.cards.itens[0].ms) + 2} name="Cards">
          <Cards
            itens={props.cards.itens.map((it) => ({ ...it, inicioF: f(it.ms - props.cards!.itens[0].ms) + 2 }))}
            fimF={f(props.cards.ateMs - props.cards.itens[0].ms) + 2}
            cor={cor}
            y={posCards.y}
          />
        </Sequence>
      ) : null}
      {props.selo18 && posSelo ? (
        <Sequence from={f(props.selo18.deMs)} durationInFrames={f(props.selo18.ateMs - props.selo18.deMs)} name="Selo +18">
          <Selo18 texto={props.selo18.texto} fimF={f(props.selo18.ateMs - props.selo18.deMs)} cor={cor} y={posSelo.y} />
        </Sequence>
      ) : null}
      <Sequence from={f(props.cta.deMs)} name="CTA">
        <Cta texto={props.cta.texto} apoio={props.cta.apoio} cor={cor} y={posCta.y} />
      </Sequence>

      <Aviso texto={props.aviso} />
      {props.mostrarZona && rostos ? <ZonaDebugNoTempo rostos={rostos} /> : null}

      {/* som */}
      {props.trilha ? <Audio src={staticFile(props.trilha.src)} volume={props.trilha.volume} /> : null}
      {props.camera.filter((k) => k.ms > 0 && k.zoom > 1.05).map((k) => sfx("whoosh", k.ms - 250, 0.3))}
      {props.atras.map((e, i) =>
        e.tipo === "capa" ? sfx("impacto", e.deMs + 130, 0.5) :
        e.tipo === "letreiro" ? sfx("whoosh", e.deMs - 200, 0.5) :
        e.tipo === "particulas" ? sfx("pop", e.ms, 0.45) :
        e.tipo === "onda" ? sfx("impacto", e.ms, 0.35) : <span key={i} />,
      )}
      {props.cards?.itens.map((it) => sfx("pop", it.ms, 0.5))}
      {props.selo18 ? sfx("pop", props.selo18.deMs, 0.55) : null}
      {sfx("riser", props.cta.deMs - 1300, 0.35)}
      {props.tremores.map((t) => sfx("impacto", t, 0.6))}
      {sfx("tick", totalMs, 0.6)}
    </AbsoluteFill>
  );
};

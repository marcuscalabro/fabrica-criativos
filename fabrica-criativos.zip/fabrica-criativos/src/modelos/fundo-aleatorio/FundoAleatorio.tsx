import { z } from "zod";
import {
  AbsoluteFill,
  Easing,
  Img,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
  type CalculateMetadataFunction,
} from "remotion";
import { Video } from "@remotion/media";
import { fontesProntas, kitSchema } from "../../kit";

// ---------------------------------------------------------------------------
// Modelo "Fundo aleatório" v2
// Vídeo qualquer de tipster como fundo (nítido, só escurecido ou tingido) e uma
// headline FIXA por cima: headline, faixa, print de prova, linha de apoio e
// botão de CTA. Só a entrada é animada (headline digitando, blocos surgindo);
// depois tudo fica parado e o fundo dá o movimento. Aviso legal fixo.
// Referências: criativos OTG "S1/S2/S4 Fundo aleatório" (out/2026).
// ---------------------------------------------------------------------------

export const MODELO_ID = "fundo-aleatorio";
export const MODELO_VERSAO = "v2";
const FPS = 30;

const blocoSchema = z.object({
  tipo: z.enum(["headline", "faixa", "print", "apoio", "botao", "espaco"]),
  texto: z.string().default(""), // **palavra** = cor de destaque
  imagem: z.string().optional(), // print: caminho dentro de public/
  largura: z.number().optional(), // print: largura em px (padrão 820)
  tamanho: z.number().optional(), // sobrescreve o tamanho da fonte do tema
});

const stickerSchema = z.object({
  emoji: z.string(),
  x: z.number(), // px (centro)
  y: z.number(),
  tamanho: z.number().default(150),
  rotacao: z.number().default(0),
});

export const TEMAS_FA = ["faixa-amarela", "neon", "limao"] as const;

export const fundoAleatorioSchema = z.object({
  fundo: z.object({
    video: z.string(),
    volume: z.number().min(0).max(1).default(1),
    inicioSeg: z.number().default(0), // corta o começo do vídeo de fundo
  }),
  duracaoSeg: z.number(),
  tema: z.enum(TEMAS_FA).default("faixa-amarela"),
  corDestaque: z.string().optional(), // sobrescreve a cor do tema
  topo: z.number().default(170), // onde começa o bloco de headline (px)
  blocos: z.array(blocoSchema),
  stickers: z.array(stickerSchema).default([]),
  aviso: z
    .object({
      linha1: z.string().default("Jogue com responsabilidade."),
      linha2: z.string().default("Ministério da Fazenda adverte: Aposta não é investimento."),
      etiqueta: z.string().default("#PUBLICIDADE"),
      y: z.number().default(1340),
    })
    .default({}),
  kit: kitSchema,
});

export type FundoAleatorioProps = z.input<typeof fundoAleatorioSchema>;
type Bloco = z.input<typeof blocoSchema>;

export const calcularMetadataFA: CalculateMetadataFunction<FundoAleatorioProps> = async ({ props }) => {
  await fontesProntas;
  return {
    durationInFrames: Math.ceil(props.duracaoSeg * FPS),
    defaultOutName: `${MODELO_ID}-${MODELO_VERSAO}-${props.tema ?? "faixa-amarela"}`,
  };
};

// ------------------------------- temas -------------------------------------
type Tema = {
  fonte: string;
  peso: number;
  destaque: string;
  textoFaixa: string;
  tamanhos: Record<Exclude<Bloco["tipo"], "print" | "espaco">, number>;
  brilho: boolean; // glow neon no texto em destaque
  sombra: string;
  camadaFundo: string; // CSS background por cima do vídeo
  espacamento: number;
};

const TEMAS: Record<(typeof TEMAS_FA)[number], Tema> = {
  // S4: headline branca + amarela, faixa amarela com texto escuro, topo escuro
  "faixa-amarela": {
    fonte: "Bebas Neue",
    peso: 400,
    destaque: "#FFE81A",
    textoFaixa: "#111111",
    tamanhos: { headline: 92, faixa: 76, apoio: 54, botao: 58 },
    brilho: false,
    sombra: "0 4px 18px rgba(0,0,0,0.75)",
    camadaFundo:
      "linear-gradient(180deg, rgba(0,0,0,0.92) 0%, rgba(0,0,0,0.78) 22%, rgba(0,0,0,0.35) 42%, rgba(0,0,0,0) 58%)",
    espacamento: 0.5,
  },
  // S1: tudo verde neon com brilho, fundo tingido de verde escuro
  neon: {
    fonte: "Bebas Neue",
    peso: 400,
    destaque: "#3CFF2E",
    textoFaixa: "#06210A",
    tamanhos: { headline: 88, faixa: 70, apoio: 64, botao: 56 },
    brilho: true,
    sombra: "0 3px 12px rgba(0,0,0,0.7)",
    camadaFundo:
      "linear-gradient(180deg, rgba(2,20,6,0.82) 0%, rgba(2,20,6,0.62) 50%, rgba(2,20,6,0.78) 100%), radial-gradient(ellipse 80% 60% at 50% 45%, rgba(0,0,0,0) 30%, rgba(0,0,0,0.6) 100%)",
    espacamento: 0.5,
  },
  // S2: Poppins extra bold, limão + branco, fundo quase sem tratamento
  limao: {
    fonte: "Poppins",
    peso: 800,
    destaque: "#D8F31E",
    textoFaixa: "#111111",
    tamanhos: { headline: 56, faixa: 50, apoio: 40, botao: 44 },
    brilho: false,
    sombra: "0 3px 14px rgba(0,0,0,0.8), 0 0 2px rgba(0,0,0,0.9)",
    camadaFundo:
      "linear-gradient(180deg, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.2) 40%, rgba(0,0,0,0) 60%)",
    espacamento: 0,
  },
};

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

// "texto com **destaque**" -> caracteres com marcação, para o efeito de digitação
const caracteres = (texto: string) => {
  const out: { c: string; d: boolean }[] = [];
  texto.split(/(\*\*[^*]+\*\*)/g).filter(Boolean).forEach((p) => {
    const d = p.startsWith("**");
    Array.from(d ? p.slice(2, -2) : p).forEach((c) => out.push({ c, d }));
  });
  return out;
};

// Quanto tempo (frames) cada bloco leva para entrar — define o encadeamento
const duracaoEntrada = (b: Bloco) =>
  b.tipo === "headline" ? Math.ceil(caracteres(b.texto ?? "").length / 2.2) + 2 : b.tipo === "espaco" ? 0 : 7;

const TextoMarcado: React.FC<{
  texto: string;
  visiveis: number;
  cor: string;
  corDestaque: string;
  brilho: boolean;
}> = ({ texto, visiveis, cor, corDestaque, brilho }) => (
  <>
    {caracteres(texto).map((ch, i) => (
      <span
        key={i}
        style={{
          color: ch.d ? corDestaque : cor,
          opacity: i < visiveis ? 1 : 0,
          textShadow: brilho ? `0 0 18px ${corDestaque}cc, 0 0 42px ${corDestaque}66` : undefined,
        }}
      >
        {ch.c}
      </span>
    ))}
  </>
);

const BlocoView: React.FC<{ bloco: Bloco; inicio: number; tema: Tema; cor: string }> = ({
  bloco,
  inicio,
  tema,
  cor,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame - inicio;
  const pop = {
    opacity: interpolate(t, [0, 4], [0, 1], clamp),
    scale: interpolate(t, [0, 7], [0.85, 1], {
      ...clamp,
      easing: Easing.spring({ damping: 12 }),
      output: "perceptual-scale",
    }),
  };
  const base: React.CSSProperties = {
    fontFamily: tema.fonte,
    fontWeight: tema.peso,
    textTransform: "uppercase",
    textAlign: "center",
    lineHeight: 1.04,
    letterSpacing: tema.espacamento,
    textShadow: tema.sombra,
    maxWidth: 960,
  };

  if (bloco.tipo === "espaco") return <div style={{ height: bloco.tamanho ?? 24 }} />;

  if (bloco.tipo === "headline") {
    const visiveis = Math.max(0, Math.floor(t * 2.2));
    return (
      <div style={{ ...base, fontSize: bloco.tamanho ?? tema.tamanhos.headline, color: "white" }}>
        <TextoMarcado texto={bloco.texto ?? ""} visiveis={visiveis} cor="white" corDestaque={cor} brilho={tema.brilho} />
      </div>
    );
  }

  if (bloco.tipo === "faixa") {
    return (
      <div
        style={{
          ...base,
          ...pop,
          fontSize: bloco.tamanho ?? tema.tamanhos.faixa,
          color: tema.textoFaixa,
          textShadow: "none",
          backgroundColor: cor,
          padding: "4px 22px 0",
          boxShadow: tema.brilho ? `0 0 28px ${cor}aa` : "0 8px 24px rgba(0,0,0,0.35)",
        }}
      >
        {(bloco.texto ?? "").replaceAll("**", "")}
      </div>
    );
  }

  if (bloco.tipo === "apoio") {
    return (
      <div style={{ ...base, ...pop, fontSize: bloco.tamanho ?? tema.tamanhos.apoio, color: "white" }}>
        <TextoMarcado texto={bloco.texto ?? ""} visiveis={9999} cor="white" corDestaque={cor} brilho={tema.brilho} />
      </div>
    );
  }

  if (bloco.tipo === "botao") {
    const pulso = 1 + 0.035 * Math.sin(((frame - inicio) / fps) * Math.PI * 2 * 0.9);
    return (
      <div
        style={{
          ...base,
          opacity: pop.opacity,
          scale: t < 7 ? pop.scale : pulso,
          fontSize: bloco.tamanho ?? tema.tamanhos.botao,
          color: cor,
          textShadow: tema.brilho ? `0 0 16px ${cor}cc` : tema.sombra,
          border: `4px solid ${cor}`,
          borderRadius: 18,
          padding: "6px 34px 2px",
          backgroundColor: "rgba(0,0,0,0.35)",
          boxShadow: tema.brilho ? `0 0 22px ${cor}88, inset 0 0 14px ${cor}55` : "0 8px 24px rgba(0,0,0,0.4)",
        }}
      >
        {(bloco.texto ?? "").replaceAll("**", "")}
      </div>
    );
  }

  // print de prova (chat, mensagens do grupo, depoimento)
  return bloco.imagem ? (
    <Img
      src={staticFile(bloco.imagem)}
      style={{
        ...pop,
        width: bloco.largura ?? 820,
        height: "auto",
        borderRadius: 14,
        boxShadow: "0 18px 40px rgba(0,0,0,0.5)",
      }}
    />
  ) : null;
};

const Sticker: React.FC<{ s: z.input<typeof stickerSchema>; atraso: number }> = ({ s, atraso }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame - atraso;
  return (
    <div
      style={{
        position: "absolute",
        left: s.x,
        top: s.y,
        translate: "-50% -50%",
        fontSize: s.tamanho ?? 150,
        lineHeight: 1,
        rotate: `${(s.rotacao ?? 0) + 4 * Math.sin((frame / fps) * Math.PI * 1.2)}deg`,
        scale: interpolate(t, [0, 8], [0, 1], { ...clamp, easing: Easing.spring({ damping: 9 }) }),
        filter: "drop-shadow(0 8px 14px rgba(0,0,0,0.45))",
      }}
    >
      {s.emoji}
    </div>
  );
};

const AvisoCartao: React.FC<{ aviso: NonNullable<FundoAleatorioProps["aviso"]> }> = ({ aviso }) => (
  <div
    style={{
      position: "absolute",
      left: 84,
      right: 84,
      top: aviso.y ?? 1340,
      display: "flex",
      alignItems: "center",
      gap: 26,
      padding: "22px 30px",
      backgroundColor: "rgba(255,255,255,0.94)",
      borderRadius: 18,
      fontFamily: "Inter",
      color: "#111",
      boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
    }}
  >
    <div
      style={{
        position: "absolute",
        right: 40,
        top: -20,
        backgroundColor: "#1f1f1f",
        color: "white",
        fontSize: 20,
        fontWeight: 700,
        letterSpacing: 3,
        padding: "6px 18px",
        borderRadius: 999,
      }}
    >
      {aviso.etiqueta ?? "#PUBLICIDADE"}
    </div>
    <div
      style={{
        width: 74,
        height: 74,
        borderRadius: 999,
        backgroundColor: "#1f1f1f",
        color: "white",
        fontWeight: 700,
        fontSize: 30,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
      }}
    >
      +18
    </div>
    <div style={{ fontSize: 30, fontWeight: 500, lineHeight: 1.3 }}>
      <div>{aviso.linha1 ?? "Jogue com responsabilidade."}</div>
      <div>{aviso.linha2 ?? "Ministério da Fazenda adverte: Aposta não é investimento."}</div>
    </div>
  </div>
);

export const FundoAleatorio: React.FC<FundoAleatorioProps> = (props) => {
  const { fps } = useVideoConfig();
  const tema = TEMAS[props.tema ?? "faixa-amarela"];
  const cor = props.corDestaque || tema.destaque;

  // encadeia a entrada: cada bloco começa quando o anterior termina
  let cursor = 4;
  const inicios = props.blocos.map((b) => {
    const i = cursor;
    cursor += duracaoEntrada(b) + (b.tipo === "headline" ? 2 : 3);
    return i;
  });

  return (
    <AbsoluteFill style={{ backgroundColor: "black" }}>
      <AbsoluteFill>
        <Video
          src={staticFile(props.fundo.video)}
          volume={props.fundo.volume ?? 1}
          trimBefore={Math.round((props.fundo.inicioSeg ?? 0) * fps)}
          objectFit="cover"
        />
      </AbsoluteFill>
      <AbsoluteFill style={{ background: tema.camadaFundo }} />

      <AbsoluteFill
        style={{
          alignItems: "center",
          justifyContent: "flex-start",
          paddingTop: props.topo ?? 170,
          paddingInline: 60,
          gap: 22,
        }}
      >
        {props.blocos.map((b, i) => (
          <BlocoView key={i} bloco={b} inicio={inicios[i]} tema={tema} cor={cor} />
        ))}
      </AbsoluteFill>

      {(props.stickers ?? []).map((s, i) => (
        <Sticker key={i} s={s} atraso={cursor + i * 3} />
      ))}

      <AvisoCartao aviso={props.aviso ?? {}} />
    </AbsoluteFill>
  );
};

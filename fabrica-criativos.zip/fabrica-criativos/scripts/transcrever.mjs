// Transcrição local da fala, palavra a palavra, com Whisper-small rodando na
// própria máquina (transformers.js + ONNX). O áudio não sai do servidor.
//
// Modelo: pasta modelos-ia/Xenova/whisper-small (instale com
// `node scripts/instalar-transcricao.mjs`). Se a pasta não existir e a máquina
// tiver acesso ao Hugging Face, o modelo é baixado de lá automaticamente.
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const RAIZ = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
export const PASTA_MODELOS = process.env.FABRICA_MODELOS || path.join(RAIZ, "modelos-ia");
export const MODELO_ASR = process.env.FABRICA_MODELO_ASR || "Xenova/whisper-small";

let asrCache = null;
async function carregarAsr() {
  if (asrCache) return asrCache;
  const { pipeline, env } = await import("@huggingface/transformers");
  const local = fs.existsSync(path.join(PASTA_MODELOS, MODELO_ASR, "config.json"));
  env.localModelPath = PASTA_MODELOS;
  env.allowLocalModels = true;
  env.allowRemoteModels = !local;
  asrCache = await pipeline("automatic-speech-recognition", MODELO_ASR, { dtype: "q8" });
  return asrCache;
}

// Lê o áudio do vídeo como PCM mono 16 kHz (float32), o formato que o Whisper espera
function lerAudio(videoPath, pastaTmp) {
  const raw = path.join(pastaTmp, "audio16k.f32");
  execFileSync("ffmpeg", ["-y", "-loglevel", "error", "-i", videoPath, "-ar", "16000", "-ac", "1", "-f", "f32le", raw]);
  const buf = fs.readFileSync(raw);
  return new Float32Array(buf.buffer, buf.byteOffset, buf.length / 4);
}

// Aplica o glossário do kit: { "Gratis": "grátis", "pra tu": "pra tu" ... }
// Troca por palavra inteira, sem diferenciar maiúsculas; mantém a pontuação.
export function aplicarGlossario(legendas, glossario = {}) {
  const mapa = new Map(Object.entries(glossario).map(([k, v]) => [k.toLowerCase(), v]));
  if (!mapa.size) return legendas;
  return legendas.map((c) => {
    const m = c.text.match(/^(\s*)(.*?)([.,;:!?…]*)$/s);
    const [, espaco, palavra, pont] = m;
    const troca = mapa.get(palavra.toLowerCase());
    return troca === undefined ? c : { ...c, text: `${espaco}${troca}${pont}` };
  });
}

// DECUPAGEM: transcreve cada bloco de fala SOZINHO (sem contexto dos vizinhos).
// O Whisper tende a "limpar" a fala quando ouve tudo junto (some com o take errado e
// com a repetição). Bloco isolado = ele só pode escrever o que tem naquele pedaço.
export async function transcreverBlocos(videoPath, pastaTmp, blocos, { idioma = "portuguese" } = {}) {
  const audio = lerAudio(videoPath, pastaTmp);
  const asr = await carregarAsr();
  const SR = 16000;
  const MARGEM = 0.2; // silêncio digital nas pontas ajuda o modelo em blocos curtos
  const palavras = [];
  for (const [ib, b] of blocos.entries()) {
    const a0 = Math.max(0, Math.floor(b.ini * SR));
    const a1 = Math.min(audio.length, Math.ceil(b.fim * SR));
    const pad = Math.round(MARGEM * SR);
    const trecho = new Float32Array(a1 - a0 + 2 * pad);
    trecho.set(audio.subarray(a0, a1), pad);
    const saida = await asr(trecho, {
      language: idioma,
      task: "transcribe",
      return_timestamps: "word",
      chunk_length_s: 30,
      stride_length_s: 5,
    });
    for (const c of saida.chunks ?? []) {
      const texto = c.text.trim();
      if (!texto) continue;
      const [x, y] = c.timestamp;
      const ini = Math.max(b.ini, b.ini + x - MARGEM);
      const fim = Math.min(b.fim, b.ini + (y == null || y <= x ? x + 0.15 : y) - MARGEM);
      palavras.push({ text: texto, startMs: Math.round(ini * 1000), endMs: Math.round(Math.max(fim, ini + 0.05) * 1000), bloco: ib });
    }
  }
  return palavras;
}

// Retorna legendas no formato Caption do Remotion (tempos do vídeo de entrada)
export async function transcrever(videoPath, pastaTmp, { idioma = "portuguese" } = {}) {
  const audio = lerAudio(videoPath, pastaTmp);
  const asr = await carregarAsr();
  const saida = await asr(audio, {
    language: idioma, // sem isso o modelo pode traduzir para inglês
    task: "transcribe",
    return_timestamps: "word",
    chunk_length_s: 30,
    stride_length_s: 5,
  });
  const legendas = [];
  for (const [i, c] of (saida.chunks ?? []).entries()) {
    const texto = c.text.trim();
    if (!texto) continue;
    const [a, b] = c.timestamp;
    const ini = Math.round(a * 1000);
    const fim = b == null || b <= a ? ini + 150 : Math.round(b * 1000);
    legendas.push({
      text: (i === 0 ? "" : " ") + texto,
      startMs: ini,
      endMs: fim,
      timestampMs: Math.round((ini + fim) / 2),
      confidence: null,
    });
  }
  return legendas;
}

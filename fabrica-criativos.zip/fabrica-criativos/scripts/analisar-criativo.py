#!/usr/bin/env python3
"""VARIAÇÃO — análise de um criativo já pronto e "conformação" do trecho novo.

  analisar  original.mp4 ini_ms fim_ms analise.json camada-fixa.png
      Estuda o trecho [ini, fim) do criativo original (a parte que FICA):
        · enquadramento: tamanho e posição do rosto do expert
        · cor: média e contraste por canal (espaço Lab)
        · camada fixa: elementos que não mudam nunca (aviso legal, selo,
          logo, marca d'água) -> recortados em PNG com transparência
        · legenda: faixa vertical onde ela aparece, tamanho da letra,
          cor da palavra em destaque e se tem caixa/fundo
  conformar analise.json novo_limpo.mp4 rostos_novo.json saida.mp4
      Ajusta o trecho novo para ficar igual ao original: mesmo tamanho e
      posição do rosto (escala + deslocamento) e mesma cor (transferência Lab).

100% local (OpenCV + numpy).
"""
import json
import subprocess
import sys

import cv2
import numpy as np


def quadros(caminho, ini_ms, fim_ms, n):
    cap = cv2.VideoCapture(caminho)
    out = []
    for t in np.linspace(ini_ms, fim_ms, n + 2)[1:-1]:
        cap.set(cv2.CAP_PROP_POS_MSEC, float(t))
        ok, q = cap.read()
        if ok:
            out.append(q)
    cap.release()
    return out


def rostos(qs):
    cls = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    caixas = []
    for q in qs:
        h, w = q.shape[:2]
        e = w / 540
        peq = cv2.resize(q, (540, int(h / e)))
        cz = cv2.equalizeHist(cv2.cvtColor(peq, cv2.COLOR_BGR2GRAY))
        r = cls.detectMultiScale(cz, 1.1, 6, minSize=(54, 54))
        if len(r):
            x, y, bw, bh = max(r, key=lambda b: b[2] * b[3])
            caixas.append([x * e, y * e, bw * e, bh * e])
    return np.median(np.array(caixas), axis=0).tolist() if caixas else None


def stats_lab(qs):
    lab = np.concatenate([cv2.cvtColor(q, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32) for q in qs])
    return lab.mean(0).tolist(), lab.std(0).tolist()


def camada_fixa(qs, saida_png):
    """Pixels que não mudam ao longo do trecho E têm desenho (borda forte):
    aviso legal, selo, logo. Só nas faixas de topo/base, onde ficam esses
    elementos (o fundo atrás do expert pode ser parado e não deve entrar)."""
    pilha = np.stack([cv2.cvtColor(q, cv2.COLOR_BGR2GRAY).astype(np.float32) for q in qs])
    desvio = pilha.std(0)
    mediana = np.median(np.stack(qs), axis=0).astype(np.uint8)
    h, w = desvio.shape
    bordas = cv2.Canny(cv2.cvtColor(mediana, cv2.COLOR_BGR2GRAY), 60, 160)
    densidade = cv2.blur(bordas.astype(np.float32) / 255, (25, 25))
    faixa = np.zeros((h, w), bool)
    faixa[: int(h * 0.10)] = True
    faixa[int(h * 0.80):] = True
    fixo = (desvio < 7) & (densidade > 0.06) & faixa
    fixo = cv2.morphologyEx(fixo.astype(np.uint8) * 255, cv2.MORPH_CLOSE, np.ones((15, 15), np.uint8))
    # só blocos relevantes (texto/selo), descarta ruído
    n, rot, st, _ = cv2.connectedComponentsWithStats(fixo)
    mascara = np.zeros_like(fixo)
    blocos = []
    for i in range(1, n):
        x, y, bw, bh, area = st[i]
        if area > 1500 and bw > 60:
            mascara[rot == i] = 255
            blocos.append([int(x), int(y), int(bw), int(bh)])
    mascara = cv2.dilate(mascara, np.ones((9, 9), np.uint8))
    mascara = cv2.GaussianBlur(mascara, (0, 0), 2)
    rgba = np.dstack([mediana, mascara])
    cv2.imwrite(saida_png, rgba)
    return blocos


def legenda(qs, rosto):
    """Faixa da legenda: texto que MUDA de quadro a quadro, abaixo do rosto."""
    h, w = qs[0].shape[:2]
    y0 = int(rosto[1] + rosto[3] * 1.2) if rosto else int(h * 0.45)
    y1 = int(h * 0.88)
    presenca = np.zeros(h)
    cores = []
    caixa_votos = 0
    for q in qs:
        hsv = cv2.cvtColor(q, cv2.COLOR_BGR2HSV)
        branco = (hsv[..., 2] > 215) & (hsv[..., 1] < 45)
        sat = (hsv[..., 2] > 170) & (hsv[..., 1] > 130)
        texto = (branco | sat)[y0:y1, int(w * 0.06): int(w * 0.94)]
        # texto = linhas com muitos pixels claros em sequência curta (letras), não blocos lisos
        linhas = texto.mean(1)
        presenca[y0:y1] += (linhas > 0.025) & (linhas < 0.6)
        hues = hsv[y0:y1, :, 0][sat[y0:y1]]
        cores.extend(hues.tolist())
        caixa_votos += ((hsv[y0:y1, :, 2] < 40).mean() > 0.25)
    presenca /= max(1, len(qs))
    linhas = np.where(presenca > 0.25)[0]
    if not len(linhas):
        return None
    topo, base = int(linhas.min()), int(linhas.max())
    # altura de uma linha de texto ~ o maior bloco contínuo
    blocos = np.split(linhas, np.where(np.diff(linhas) > 6)[0] + 1)
    altura_linha = int(max(len(b) for b in blocos))
    destaque = None
    if cores:
        hist = np.bincount(np.array(cores, dtype=int) // 6, minlength=31)
        hist[1:4] = 0  # pele (laranja/marrom) não conta como destaque
        if hist.max() > len(qs) * 400:
            hue = int(hist.argmax() * 6 + 3)
            bgr = cv2.cvtColor(np.uint8([[[hue, 230, 255]]]), cv2.COLOR_HSV2BGR)[0, 0]
            destaque = "#%02X%02X%02X" % (bgr[2], bgr[1], bgr[0])
    return {"topo": topo, "base": base, "alturaLinha": altura_linha, "corDestaque": destaque, "temCaixa": caixa_votos > len(qs) / 2}


def analisar(original, ini, fim, saida_json, saida_png):
    qs = quadros(original, ini, fim, 24)
    rosto = rostos(qs)
    media, desvio = stats_lab(qs)
    blocos = camada_fixa(qs, saida_png)
    leg = legenda(qs, rosto)
    r = {"rosto": rosto, "lab": {"media": media, "desvio": desvio}, "camadaFixa": blocos, "legenda": leg}
    json.dump(r, open(saida_json, "w"), indent=1)
    print(json.dumps(r))


def conformar(analise_json, novo, rostos_novo_json, saida):
    a = json.load(open(analise_json))
    qs = quadros(novo, 0, 1e9, 1) if False else None
    cap = cv2.VideoCapture(novo)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_ms = cap.get(cv2.CAP_PROP_FRAME_COUNT) / fps * 1000
    amostras = quadros(novo, 0, total_ms, 16)
    rn = rostos(amostras)
    ro = a.get("rosto")
    # enquadramento: rosto do trecho novo com o mesmo tamanho e no mesmo lugar do original
    if rn and ro:
        s = max(1.0, ro[2] / rn[2])  # nunca reduz (não abrir bordas pretas)
        cxn, cyn = rn[0] + rn[2] / 2, rn[1] + rn[3] / 2
        cxo, cyo = ro[0] + ro[2] / 2, ro[1] + ro[3] / 2
        M = np.float32([[s, 0, cxo - cxn * s], [0, s, cyo - cyn * s]])
        # limita o deslocamento para a imagem continuar cobrindo o quadro
        M[0, 2] = min(0, max(W - W * s, M[0, 2]))
        M[1, 2] = min(0, max(H - H * s, M[1, 2]))
    else:
        s, M = 1.0, np.float32([[1, 0, 0], [0, 1, 0]])
    mo, do = np.array(a["lab"]["media"]), np.array(a["lab"]["desvio"])
    mn, dn = stats_lab(amostras)
    mn, dn = np.array(mn), np.array(dn)
    ganho = np.clip(do / np.maximum(dn, 1e-3), 0.7, 1.4)

    ff = subprocess.Popen(
        ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{W}x{H}", "-r", str(fps), "-i", "-",
         "-i", novo, "-map", "0:v", "-map", "1:a?", "-c:v", "libx264", "-crf", "16", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-c:a", "copy", "-shortest", saida],
        stdin=subprocess.PIPE,
    )
    while True:
        ok, q = cap.read()
        if not ok:
            break
        if s != 1.0 or M[0, 2] or M[1, 2]:
            q = cv2.warpAffine(q, M, (W, H), flags=cv2.INTER_LANCZOS4, borderMode=cv2.BORDER_REFLECT)
        lab = cv2.cvtColor(q, cv2.COLOR_BGR2LAB).astype(np.float32)
        lab = (lab - mn) * ganho + mo
        q = cv2.cvtColor(np.clip(lab, 0, 255).astype(np.uint8), cv2.COLOR_LAB2BGR)
        ff.stdin.write(q.tobytes())
    ff.stdin.close()
    ff.wait()
    print(json.dumps({"escala": round(float(s), 3), "deslocamento": [round(float(M[0, 2])), round(float(M[1, 2]))], "ganhoCor": ganho.round(3).tolist()}))


if __name__ == "__main__":
    cmd = sys.argv[1]
    if cmd == "analisar":
        analisar(sys.argv[2], float(sys.argv[3]), float(sys.argv[4]), sys.argv[5], sys.argv[6])
    else:
        conformar(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])

// Instala o modelo de transcrição (Whisper-small, ONNX quantizado q8) em
// modelos-ia/, uma vez por máquina.
//
// Origem: o mesmo conjunto de arquivos do Xenova/whisper-small (Hugging Face),
// empacotado no npm como `sts-whisper-small` (só arquivos de modelo; nenhum
// código é executado). Em máquinas com acesso ao Hugging Face, esta etapa é
// opcional: a transcrição baixa o modelo de lá na primeira vez.
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { PASTA_MODELOS, MODELO_ASR } from "./transcrever.mjs";

const PACOTE = "sts-whisper-small@1.0.0";
const destino = path.join(PASTA_MODELOS, MODELO_ASR);

if (fs.existsSync(path.join(destino, "config.json"))) {
  console.log(`Modelo já instalado em ${destino}`);
  process.exit(0);
}

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "fabrica-asr-"));
console.log(`Baixando ${PACOTE} (~250 MB)...`);
execFileSync("npm", ["pack", PACOTE, "--silent", "--pack-destination", tmp], { stdio: "inherit" });
const tgz = fs.readdirSync(tmp).find((f) => f.endsWith(".tgz"));
execFileSync("tar", ["-xzf", path.join(tmp, tgz), "-C", tmp]);

const origem = path.join(tmp, "package", "models", MODELO_ASR);
const arquivos = fs.readdirSync(origem, { recursive: true });
const executaveis = arquivos.filter((f) => /\.(js|mjs|cjs|sh|py|node|so|dylib|exe)$/i.test(String(f)));
if (executaveis.length) {
  console.error(`Pacote inesperado: contém arquivos executáveis (${executaveis.join(", ")}). Abortado.`);
  process.exit(1);
}
fs.mkdirSync(path.dirname(destino), { recursive: true });
fs.cpSync(origem, destino, { recursive: true });
fs.rmSync(tmp, { recursive: true, force: true });
console.log(`Modelo instalado em ${destino}`);

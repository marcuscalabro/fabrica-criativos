#!/usr/bin/env python3
"""BANCO DE IMAGENS DO EXPERT — cada foto entra pronta para qualquer arte.

Uso:
  .venv-visao/bin/python scripts/banco-tylty.py adicionar <foto> <id> --tags "apontando,serio" \
      [--camisa "azul"] [--recorte x,y,w,h] [--expert tylty]
  .venv-visao/bin/python scripts/banco-tylty.py indice [--expert tylty]

Para cada foto a Fábrica guarda, em public/banco/<expert>/<id>/:
  original.jpg   recorte do arquivo enviado (sem tratamento)
  recorte.png    o expert sem fundo (modelo local u2net, sem IA externa)
  rostos.json    zona protegida do rosto
  meta.json      tags de pose, camisa, lado em que a foto foi cortada, caixa
                 da pessoa, enquadramento e qualidade (resolução)
  miniatura.jpg  para a galeria do portal
e atualiza public/banco/<expert>/indice.json.
"""
import argparse
import json
import os
import subprocess
import sys

import cv2
import numpy as np

RAIZ = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
PY = sys.executable


def pasta_expert(expert):
    p = os.path.join(RAIZ, "public", "banco", expert)
    os.makedirs(p, exist_ok=True)
    return p


def adicionar(a):
    destino = os.path.join(pasta_expert(a.expert), a.id)
    os.makedirs(destino, exist_ok=True)
    img = cv2.imread(a.foto)
    if a.recorte:
        x, y, w, h = [int(v) for v in a.recorte.split(",")]
        img = img[y:y + h, x:x + w]
    cv2.imwrite(os.path.join(destino, "original.jpg"), img, [cv2.IMWRITE_JPEG_QUALITY, 95])
    # 1. sem fundo
    subprocess.run([PY, "-I", os.path.join(RAIZ, "scripts", "recortar-pessoa.py"), os.path.join(destino, "original.jpg"), os.path.join(destino, "recorte.png")], check=True)
    # 2. zona do rosto
    subprocess.run([PY, os.path.join(RAIZ, "scripts", "detectar-rosto.py"), os.path.join(destino, "recorte.png"), os.path.join(destino, "rostos.json")], check=True)
    rgba = cv2.imread(os.path.join(destino, "recorte.png"), cv2.IMREAD_UNCHANGED)
    alfa = rgba[..., 3]
    H, W = alfa.shape
    ys, xs = np.where(alfa > 128)
    caixa = [int(xs.min()), int(ys.min()), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)]
    # 3. em que bordas a pessoa foi cortada (ela precisa encostar nessas bordas da arte)
    toca = lambda faixa: float((faixa > 128).mean())
    bordas = {"esquerda": toca(alfa[:, :3]), "direita": toca(alfa[:, -3:]), "baixo": toca(alfa[-3:, :]), "topo": toca(alfa[:3, :])}
    cortada = [k for k, v in bordas.items() if v > 0.08]
    if "esquerda" in cortada and "direita" not in cortada:
        lado = "esquerda"
    elif "direita" in cortada and "esquerda" not in cortada:
        lado = "direita"
    else:
        # cortada só embaixo: vai para o lado oposto ao que ela olha/aponta (mais massa do corpo)
        lado = "direita" if xs.mean() > W / 2 else "esquerda"
    rostos = json.load(open(os.path.join(destino, "rostos.json")))
    rosto = rostos["amostras"][0]["rosto"] if rostos.get("amostras") else None
    proporcao = (rosto[3] / caixa[3]) if rosto else 0
    enquadramento = "close" if proporcao > 0.42 else "busto" if proporcao > 0.28 else "meio corpo"
    lado_menor = min(caixa[2], caixa[3])
    qualidade = "alta" if lado_menor >= 900 else "media" if lado_menor >= 550 else "baixa"
    meta = {
        "id": a.id,
        "expert": a.expert,
        "tags": [t.strip() for t in a.tags.split(",") if t.strip()],
        "camisa": a.camisa,
        "lado": lado,
        "bordasCortadas": cortada,
        "pessoa": caixa,
        "largura": W,
        "altura": H,
        "enquadramento": enquadramento,
        "qualidade": qualidade,
        "origem": os.path.basename(a.foto),
    }
    if not cortada or ("esquerda" in cortada and "direita" in cortada):
        meta["aviso"] = "foto cortada dos dois lados ou solta: confira o enquadramento"
    json.dump(meta, open(os.path.join(destino, "meta.json"), "w"), ensure_ascii=False, indent=1)
    # 4. miniatura (expert sem fundo sobre grafite)
    fundo = np.full((H, W, 3), (38, 32, 28), np.uint8)
    al = alfa[..., None] / 255.0
    comp = (rgba[..., :3] * al + fundo * (1 - al)).astype(np.uint8)
    esc = 360 / H
    cv2.imwrite(os.path.join(destino, "miniatura.jpg"), cv2.resize(comp, (int(W * esc), 360), interpolation=cv2.INTER_AREA), [cv2.IMWRITE_JPEG_QUALITY, 82])
    print(json.dumps(meta, ensure_ascii=False))
    indice(a)


def indice(a):
    p = pasta_expert(a.expert)
    itens = []
    for d in sorted(os.listdir(p)):
        m = os.path.join(p, d, "meta.json")
        if os.path.exists(m):
            itens.append(json.load(open(m)))
    json.dump(itens, open(os.path.join(p, "indice.json"), "w"), ensure_ascii=False, indent=1)
    print(f"banco {a.expert}: {len(itens)} fotos")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    ad = sub.add_parser("adicionar")
    ad.add_argument("foto")
    ad.add_argument("id")
    ad.add_argument("--tags", default="")
    ad.add_argument("--camisa", default="")
    ad.add_argument("--recorte", default="")
    ad.add_argument("--expert", default="tylty")
    ix = sub.add_parser("indice")
    ix.add_argument("--expert", default="tylty")
    a = ap.parse_args()
    adicionar(a) if a.cmd == "adicionar" else indice(a)

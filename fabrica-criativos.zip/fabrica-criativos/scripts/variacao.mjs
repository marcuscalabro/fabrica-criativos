#!/usr/bin/env node
// VARIAÇÃO — troca o HOOK, o CORPO ou o CTA de um criativo já pronto, para
// teste A/B, mantendo a edição do original.
//
// Uso:
//   node scripts/variacao.mjs --original criativo.mp4 --novo trecho-bruto.mp4 \
//     --parte cta|hook|corpo --marca <kit> [--id nome] [--cta-texto "..."] [--cta-apoio "..."]
//
// Dois caminhos, escolhidos sozinhos:
//  · EXATO — o original saiu da Fábrica (etiqueta "fabrica-job" no arquivo):
//    junta o vídeo limpo do original com o trecho novo e renderiza de novo com
//    o MESMO modelo, nível, estilo, cor, kit e decisões de edição. A emenda é
//    invisível porque é a mesma edição.
//  · ANÁLISE — o original veio de fora: a Fábrica estuda o criativo (rosto,
//    cor, legenda, elementos fixos como aviso e selo) e faz o trecho novo
//    imitar isso: mesmo enquadramento e cor, legenda no mesmo lugar/tamanho/cor,
//    e copia por cima a camada fixa do original. Depois emenda.
// Nos dois casos o trecho novo passa pelo mesmo tratamento de entrada da Fábrica:
// corte de pausas, 1080x1920, áudio a -14 LUFS, transcrição local, zona do rosto.

import { execFileSync, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { acharTrechos, planejarEdicao } from "./planejar-edicao.mjs";

const RAIZ = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const k = process.argv[i];
  if (!k.startsWith("--")) continue;
  const v = process.argv[i + 1];
  if (v === undefined || v.startsWith("--")) args[k.slice(2)] = true;
  else (args[k.slice(2)] = v), i++;
}
for (const k of ["original", "novo", "parte", "marca"]) if (!args[k]) (console.error(`Falta --${k}`), process.exit(1));
const parte = args.parte;
if (!["cta", "hook", "corpo"].includes(parte)) (console.error("--parte deve ser cta, hook ou corpo"), process.exit(1));

const original = path.resolve(args.original);
const id = args.id || `var-${parte}-${Date.now()}`;
const pasta = path.join(RAIZ, "public", "jobs", id);
fs.mkdirSync(pasta, { recursive: true });
const log = (m) => console.log(`[${id}] ${m}`);
const py = path.join(RAIZ, ".venv-visao", "bin", "python");
const run = (cmd, a, opts = {}) => {
  const r = spawnSync(cmd, a, { encoding: "utf8", cwd: RAIZ, ...opts });
  if (r.status !== 0) {
    console.error(r.stderr?.slice(-3000) || `${cmd} falhou`);
    process.exit(1);
  }
  return r.stdout ?? "";
};
const ffprobe = (f, q) => execFileSync("ffprobe", ["-v", "error", ...q, f], { encoding: "utf8" }).trim();
const duracaoMs = (f) => Number(ffprobe(f, ["-show_entries", "format=duration", "-of", "csv=p=0"])) * 1000;
const lufs = (f, ini = 0, fim = null) => {
  const r = spawnSync("ffmpeg", ["-hide_banner", "-ss", String(ini / 1000), ...(fim ? ["-to", String(fim / 1000)] : []), "-i", f, "-af", "ebur128", "-f", "null", "-"], { encoding: "utf8" });
  const m = [...r.stderr.matchAll(/I:\s+(-?[\d.]+) LUFS/g)].pop();
  return m ? Number(m[1]) : -14;
};

// ---------- 1. trecho novo: tratamento de entrada da Fábrica ----------
const idNovo = `${id}-novo`;
log("preparando o trecho novo (pausas, 1080x1920, -14 LUFS, transcrição, rosto)…");
run("node", [path.join("scripts", "editar.mjs"), "--video", path.resolve(args.novo), "--marca", args.marca, "--id", idNovo, "--sem-render", "--estilo", "editorial"], { stdio: ["ignore", "inherit", "inherit"] });
const pastaNovo = path.join(RAIZ, "public", "jobs", idNovo);
const novoLimpo = path.join(pastaNovo, "limpo.mp4");
const legNovo = JSON.parse(fs.readFileSync(path.join(pastaNovo, "legendas.json"), "utf8"));
const durNovo = duracaoMs(novoLimpo);

// ---------- 2. de onde veio o original? ----------
const etiqueta = ffprobe(original, ["-show_entries", "format_tags=comment", "-of", "csv=p=0"]);
const jobOriginal = (etiqueta.match(/fabrica-job=([\w.-]+)/) || [])[1];
const propsOriginalArq = jobOriginal && path.join(RAIZ, "public", "jobs", jobOriginal, "props.json");
const exato = propsOriginalArq && fs.existsSync(propsOriginalArq);
log(exato ? `original feito na Fábrica (job ${jobOriginal}) → caminho EXATO` : "original de fora da Fábrica → caminho ANÁLISE");

// emenda: [0, a) + NOVO + [b, fim)
function emendaPorTrechos(trechos, durOrig) {
  if (parte === "cta") return { a: trechos.inicioCta, b: durOrig };
  if (parte === "hook") return { a: 0, b: trechos.fimHook };
  return { a: trechos.fimHook, b: trechos.inicioCta }; // corpo
}
const juntarLegendas = (orig, a, b, novo) => [
  ...orig.filter((c) => c.endMs <= a + 40),
  ...novo.map((c) => ({ ...c, startMs: c.startMs + a, endMs: c.endMs + a, timestampMs: c.timestampMs == null ? null : c.timestampMs + a })),
  ...orig.filter((c) => c.startMs >= b - 40).map((c) => ({ ...c, startMs: c.startMs - b + a + durNovo, endMs: c.endMs - b + a + durNovo, timestampMs: c.timestampMs == null ? null : c.timestampMs - b + a + durNovo })),
];
// concatena vídeos (re-encode, mesmo formato), com micro cross-fade de áudio na emenda
function concatenar(partes, saida) {
  const ent = [];
  const filtros = [];
  partes.forEach((p, i) => {
    ent.push(...(p.ini != null ? ["-ss", String(p.ini / 1000)] : []), ...(p.fim != null ? ["-to", String(p.fim / 1000)] : []), "-i", p.arq);
    filtros.push(`[${i}:v]fps=30,scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,format=yuv420p[v${i}]`);
    filtros.push(`[${i}:a]aresample=48000,aformat=channel_layouts=stereo,afade=t=in:d=0.03,areverse,afade=t=in:d=0.04,areverse[a${i}]`);
  });
  const n = partes.length;
  filtros.push(`${partes.map((_, i) => `[v${i}][a${i}]`).join("")}concat=n=${n}:v=1:a=1[v][a]`);
  run("ffmpeg", ["-v", "error", "-y", ...ent, "-filter_complex", filtros.join(";"), "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-crf", "16", "-preset", "veryfast", "-c:a", "aac", "-b:a", "192k", saida]);
}
const partesDaEmenda = (arqOrig, a, b, durOrig, arqNovo) =>
  [a > 0 ? { arq: arqOrig, ini: 0, fim: a } : null, { arq: arqNovo }, b < durOrig - 80 ? { arq: arqOrig, ini: b } : null].filter(Boolean);

fs.mkdirSync(path.join(RAIZ, "out", "variacoes"), { recursive: true });
const saidaFinal = path.join("out", "variacoes", `${args.marca}_variacao-${parte}_${id}.mp4`);
const relatorio = { parte, caminho: exato ? "exato" : "analise" };

if (exato) {
  // ================= CAMINHO EXATO =================
  const po = JSON.parse(fs.readFileSync(propsOriginalArq, "utf8"));
  const limpoOrig = path.join(RAIZ, "public", po.video);
  const durOrig = duracaoMs(limpoOrig);
  const trechos = acharTrechos(po.legendas, durOrig);
  if (po.cta?.deMs) trechos.inicioCta = po.cta.deMs - 60; // o original sabe onde começou o CTA
  const { a, b } = emendaPorTrechos(trechos, durOrig);
  log(`emenda no vídeo limpo: mantém [0–${(a / 1000).toFixed(2)}s] + NOVO (${(durNovo / 1000).toFixed(2)}s)${b < durOrig - 80 ? ` + [${(b / 1000).toFixed(2)}s–fim]` : ""}`);
  const limpo = path.join(pasta, "limpo.mp4");
  concatenar(partesDaEmenda(limpoOrig, a, b, durOrig, novoLimpo), limpo);
  const legendas = juntarLegendas(po.legendas, a, b, legNovo);
  const arqRostos = path.join(pasta, "rostos.json");
  run(py, [path.join("scripts", "detectar-rosto.py"), limpo, arqRostos]);
  const rostos = JSON.parse(fs.readFileSync(arqRostos, "utf8"));
  const dur = duracaoMs(limpo);

  const modelo = po.pessoa ? "CriativoAvancado" : po.camera ? "CriativoCompleto" : "FalaLegendada";
  const p = { ...po, video: `jobs/${id}/limpo.mp4`, duracaoVideoSeg: Number((dur / 1000).toFixed(3)), legendas, rostos };
  if (modelo !== "FalaLegendada") {
    // replaneja com as mesmas regras; o que veio do original (gancho/capa, botão) é mantido
    const capa = (po.atras || []).find((e) => e.tipo === "capa");
    const gancho = po.gancho ? { linha1: po.gancho.linha1, linha2: po.gancho.linha2 } : capa ? { linha1: capa.pequeno, linha2: capa.grande } : undefined;
    const plano = planejarEdicao({
      legendas,
      duracaoMs: dur,
      nivel: modelo === "CriativoAvancado" ? "avancado" : "medio",
      opcoes: { ...(gancho && parte !== "hook" ? { gancho } : {}), cta: { texto: args["cta-texto"] || po.cta.texto, apoio: args["cta-apoio"] ?? po.cta.apoio } },
    });
    const { relatorio: rel, ...dec } = plano;
    Object.assign(p, dec);
    if (parte === "cta") {
      // no teste de CTA o trecho novo inteiro É o CTA: o botão entra na emenda
      p.cta = { ...p.cta, deMs: a + 120 };
      const fimSelo = a - 700;
      if (p.selo18 && p.selo18.ateMs > fimSelo) p.selo18.ateMs > p.selo18.deMs + 1100 ? (p.selo18.ateMs = fimSelo) : delete p.selo18;
      if (p.foco) p.foco = [...p.foco.filter((f) => f.ateMs < a), { deMs: a + 120, ateMs: 99999 }];
      if (p.tremores) p.tremores = [...p.tremores.filter((t) => t < a - 300), a + 120];
      if (p.atras) p.atras = p.atras.filter((e) => (e.ms ?? e.deMs) < a - 300).concat([{ tipo: "particulas", ms: a + 120, emoji: "⚡", quantidade: 14 }, { tipo: "luz", deMs: a + 120, ateMs: dur + 2500 }]);
      p.camera = [...p.camera.filter((k) => k.ms < a - 300), { ms: a + 90, zoom: 1.06, flash: true }];
    }
    if (modelo === "CriativoAvancado") {
      delete p.gancho;
      log("recortando o expert do fundo no vídeo emendado…");
      run(py, ["-I", path.join("scripts", "recortar-pessoa.py"), limpo, path.join(pasta, "pessoa.webm")], { stdio: ["ignore", "inherit", "inherit"] });
      p.pessoa = `jobs/${id}/pessoa.webm`;
    } else delete p.atras;
    rel.forEach((r) => log(`plano: ${r}`));
  }
  const arqProps = path.join(pasta, "props.json");
  fs.writeFileSync(arqProps, JSON.stringify(p, null, 1));
  log(`renderizando com o mesmo modelo (${modelo})…`);
  const tmp = path.join(pasta, "render.mp4");
  run("npx", ["remotion", "render", modelo, tmp, `--props=${arqProps}`, "--log=error", "--concurrency=2"], { stdio: ["ignore", "inherit", "inherit"] });
  run("ffmpeg", ["-v", "error", "-y", "-i", tmp, "-c", "copy", "-metadata", `comment=fabrica-job=${id}`, path.join(RAIZ, saidaFinal)]);
  Object.assign(relatorio, { jobOriginal, modelo, emendaMs: { a, b }, duracaoFinalSeg: Number(((dur + (po.cta?.cartelaSeg ?? 0) * 1000) / 1000).toFixed(2)) });
} else {
  // ================= CAMINHO ANÁLISE =================
  const durOrig = duracaoMs(original);
  log("transcrevendo o criativo original para achar hook, corpo e CTA…");
  const { transcrever } = await import("./transcrever.mjs");
  const legOrig = await transcrever(original, pasta);
  const trechos = acharTrechos(legOrig, durOrig);
  const { a, b } = emendaPorTrechos(trechos, durOrig);
  log(`trechos do original: hook até ${(trechos.fimHook / 1000).toFixed(2)}s · CTA a partir de ${(trechos.inicioCta / 1000).toFixed(2)}s`);
  log(`emenda: mantém [0–${(a / 1000).toFixed(2)}s] + NOVO${b < durOrig - 80 ? ` + [${(b / 1000).toFixed(2)}s–fim]` : ""}`);

  // estuda o trecho do original que fica (o maior)
  const [ini, fim] = a > durOrig - b ? [300, a - 100] : [b + 100, durOrig - 300];
  const arqAnalise = path.join(pasta, "analise.json");
  const camada = path.join(pasta, "camada-fixa.png");
  const an = JSON.parse(run(py, [path.join("scripts", "analisar-criativo.py"), "analisar", original, String(ini), String(fim), arqAnalise, camada]).trim().split("\n").pop());
  log(`análise: rosto ${an.rosto ? an.rosto.map(Math.round).join(",") : "—"} · legenda ${an.legenda ? `y=${an.legenda.topo}–${an.legenda.base}, linha ${an.legenda.alturaLinha}px, destaque ${an.legenda.corDestaque ?? "nenhum"}${an.legenda.temCaixa ? ", com caixa" : ""}` : "não encontrada"} · ${an.camadaFixa.length} elemento(s) fixo(s)`);

  // conforma o trecho novo: enquadramento e cor do original
  const conforme = path.join(pasta, "novo-conforme.mp4");
  const conf = run(py, [path.join("scripts", "analisar-criativo.py"), "conformar", arqAnalise, novoLimpo, path.join(pastaNovo, "rostos.json"), conforme]).trim();
  log(`trecho novo ajustado: ${conf}`);
  const arqRostos = path.join(pasta, "rostos-novo.json");
  run(py, [path.join("scripts", "detectar-rosto.py"), conforme, arqRostos]);

  // legenda no estilo do original (posição, tamanho, cor), pelo renderizador da Fábrica
  const kit = JSON.parse(fs.readFileSync(path.join(RAIZ, "public", "kits", args.marca, "kit.json"), "utf8"));
  const { glossario, ...kitModelo } = kit;
  const L = an.legenda;
  const estilo = !L ? "limpo" : L.temCaixa ? "caixa" : L.corDestaque ? "impacto" : "limpo";
  const plano = planejarEdicao({ legendas: legNovo, duracaoMs: durNovo, nivel: "medio" });
  const props = {
    video: `jobs/${id}/novo-conforme.mp4`,
    duracaoVideoSeg: Number((durNovo / 1000).toFixed(3)),
    legendas: legNovo,
    gancho: "",
    ctaTitulo: "",
    ctaSubtitulo: "",
    destaques: plano.destaques,
    zoomsMs: [],
    estiloLegenda: estilo,
    ritmoFala: "auto",
    ...(L?.corDestaque ? { corLegenda: L.corDestaque } : {}),
    ...(L ? { topoLegenda: L.topo, tamanhoLegenda: Math.max(48, Math.min(110, Math.round(L.alturaLinha * 1.15))) } : {}),
    kit: { ...kitModelo, logo: null, avisoLegal: "" }, // aviso/selo/logo vêm da camada fixa do original
    rostos: JSON.parse(fs.readFileSync(arqRostos, "utf8")),
  };
  const arqProps = path.join(pasta, "props-trecho.json");
  fs.writeFileSync(arqProps, JSON.stringify(props, null, 1));
  log(`legenda do trecho novo: estilo "${estilo}" ajustado ao original`);
  const trecho = path.join(pasta, "trecho.mp4");
  run("npx", ["remotion", "render", "FalaLegendada", trecho, `--props=${arqProps}`, "--log=error", "--concurrency=2"], { stdio: ["ignore", "inherit", "inherit"] });

  // camada fixa do original por cima + volume igual ao do original
  const ganhoDb = (lufs(original, ini, fim) - lufs(trecho)).toFixed(2);
  const trechoFinal = path.join(pasta, "trecho-final.mp4");
  run("ffmpeg", ["-v", "error", "-y", "-i", trecho, "-i", camada, "-filter_complex", "[0:v][1:v]overlay=0:0[v]", "-map", "[v]", "-map", "0:a", "-af", `volume=${ganhoDb}dB`, "-c:v", "libx264", "-crf", "16", "-preset", "veryfast", "-c:a", "aac", trechoFinal]);
  log(`camada fixa aplicada; volume ajustado em ${ganhoDb} dB`);

  const tmp = path.join(pasta, "emendado.mp4");
  concatenar(partesDaEmenda(original, a, b, durOrig, trechoFinal), tmp);
  run("ffmpeg", ["-v", "error", "-y", "-i", tmp, "-c", "copy", path.join(RAIZ, saidaFinal)]);
  Object.assign(relatorio, { emendaMs: { a, b }, analise: an, estiloLegenda: estilo });
}

fs.writeFileSync(path.join(pasta, "relatorio.json"), JSON.stringify(relatorio, null, 1));
log(`variação pronta: ${saidaFinal}`);

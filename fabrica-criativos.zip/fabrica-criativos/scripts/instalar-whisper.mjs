// Instala o Whisper.cpp e baixa o modelo de transcrição (uma vez por máquina).
// Precisa de acesso a github.com e huggingface.co.
import { installWhisperCpp, downloadWhisperModel } from "@remotion/install-whisper-cpp";
import { WHISPER_DIR, WHISPER_VERSAO, WHISPER_MODELO } from "./transcrever.mjs";

await installWhisperCpp({ to: WHISPER_DIR, version: WHISPER_VERSAO });
await downloadWhisperModel({ model: WHISPER_MODELO, folder: WHISPER_DIR });
console.log(`Whisper ${WHISPER_VERSAO} + modelo ${WHISPER_MODELO} prontos em ${WHISPER_DIR}`);

// DECUPAGEM — vídeo bruto entra, vídeo 100% decupado sai.
//
// Uso:
//   node scripts/decupar.mjs --video bruto.mp4 [--id nome] [--ritmo natural|rapido|solto]
//   node scripts/decupar.mjs --id nome --refazer      (re-renderiza depois de editar plano.json)
//
// Etapas:
//   1. transcrição local palavra a palavra (Whisper, áudio não sai da máquina)
//   2. plano de cortes (scripts/decupar.py planejar): pausas, respiros, hesitações,
//      takes errados, repetições, fala de bastidor
//   3. render com emendas de 8 ms (sem estalo), mesma resolução e fps do bruto
//   4. CONFERÊNCIA: transcreve o vídeo decupado de novo, compara com o roteiro esperado
//      e mede o áudio final. Qualquer sobra vira alerta no relatório.
// Saída: out/decupagem/<id>.mp4 + public/jobs/<id>/{plano,relatorio}.json
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { transcrever } from "./transcrever.mjs";

const RAIZ = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const args = Object.fromEntries(
  process.argv.slice(2).reduce((acc, a, i, arr) => {
    if (a.startsWith("--")) acc.push([a.slice(2), arr[i + 1] && !arr[i + 1].startsWith("--") ? arr[i + 1] : true]);
    return acc;
  }, []),
);
const id = args.id || path.basename(args.video, path.extname(args.video)).replace(/[^\w-]+/g, "_").slice(0, 60);
const pasta = path.join(RAIZ, "public", "jobs", `dec-${id}`);
fs.mkdirSync(pasta, { recursive: true });
const py = path.join(RAIZ, ".venv-visao", "bin", "python");
const script = path.join(RAIZ, "scripts", "decupar.py");
const log = (m) => console.log(`[decupagem] ${m}`);
const rodar = (...a) => {
  const r = spawnSync(py, ["-I", script, ...a], { encoding: "utf8" });
  if (r.status !== 0) throw new Error(r.stderr || r.stdout);
  return r.stdout.trim();
};

let bruto = path.join(pasta, "bruto" + path.extname(args.video || ".mp4"));
if (!args.refazer) {
  fs.copyFileSync(args.video, bruto);
  log("transcrevendo o bruto…");
  const palavras = await transcrever(bruto, pasta);
  fs.writeFileSync(path.join(pasta, "palavras.json"), JSON.stringify(palavras, null, 1));
  log("planejando cortes…");
  log(rodar("planejar", bruto, path.join(pasta, "palavras.json"), pasta, "--ritmo", args.ritmo || "natural"));
} else {
  bruto = JSON.parse(fs.readFileSync(path.join(pasta, "plano.json"), "utf8")).bruto;
}
log("cortando…");
rodar("renderizar", bruto, pasta);
log("conferindo o vídeo decupado (nova transcrição)…");
const conf = await transcrever(path.join(pasta, "decupado.mp4"), pasta);
fs.writeFileSync(path.join(pasta, "conferencia.json"), JSON.stringify(conf, null, 1));
const rel = JSON.parse(rodar("verificar", pasta, path.join(pasta, "conferencia.json")));
const saida = path.join(RAIZ, "out", "decupagem", `${id}_decupado.mp4`);
fs.mkdirSync(path.dirname(saida), { recursive: true });
fs.copyFileSync(path.join(pasta, "decupado.mp4"), saida);
log(`removido ${rel.removido}s em ${rel.cortes} cortes ${JSON.stringify(rel.porMotivo)}`);
log(rel.aprovado ? "CONFERÊNCIA APROVADA" : `CONFERÊNCIA COM ${rel.alertas.length} ALERTA(S): ${JSON.stringify(rel.alertas)}`);
log(`vídeo: ${saida}`);

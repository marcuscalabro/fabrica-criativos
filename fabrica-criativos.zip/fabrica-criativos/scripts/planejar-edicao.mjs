#!/usr/bin/env node
// PLANEJADOR AUTOMÁTICO da Fábrica — modelo "Criativo completo".
//
// Lê a fala (legendas palavra a palavra, já nos tempos do vídeo limpo) e decide
// sozinho, sem IA externa, a edição inteira: onde a câmera aproxima, que cards
// entram, quando vem o selo +18, onde fica o CTA e, no nível avançado, os
// efeitos atrás do expert. Todas as decisões seguem as regras da casa:
//  · REGRA DE FOCO: um elemento por vez na frente; motions não se encostam
//    e sobra legenda entre eles
//  · compliance: nenhuma palavra proibida vira título, card ou letreiro
//  · ritmo: punch-in a cada virada de frase, nunca mais de um a cada 1,2 s
//
// Uso isolado (teste):  node scripts/planejar-edicao.mjs legendas.json avancado
// No pipeline:           scripts/editar.mjs --modelo completo --nivel medio|avancado

import fs from "node:fs";

// ---------- vocabulário ----------
const norm = (s) =>
  s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9+]/g, "");

// assuntos que viram card (com ícone) quando aparecem em sequência na fala
const ASSUNTOS = [
  [["brasileirao", "brasileiro", "serie a"], "Brasileirão", "⚽"],
  [["copa do brasil"], "Copa do Brasil", "🏆"],
  [["champions", "champions league"], "Champions", "⭐"],
  [["libertadores", "liberta"], "Libertadores", "🏆"],
  [["sulamericana", "sul-americana"], "Sul-Americana", "🏆"],
  [["premier", "premier league"], "Premier League", "⚽"],
  [["laliga", "la liga"], "La Liga", "⚽"],
  [["copa do mundo"], "Copa do Mundo", "🌎"],
  [["estatistica", "estatisticas", "numeros"], "Estatísticas", "📊"],
  [["escanteio", "escanteios"], "Escanteios", "🚩"],
  [["cartao", "cartoes"], "Cartões", "🟨"],
  [["gols", "gol"], "Gols", "⚽"],
  ...[
    "flamengo", "palmeiras", "corinthians", "sao paulo", "santos", "gremio", "internacional", "cruzeiro",
    "atletico", "vasco", "botafogo", "fluminense", "bahia", "fortaleza",
  ].map((t) => [[t], t.replace(/\b\w/g, (c) => c.toUpperCase()).replace("Sao", "São").replace("Gremio", "Grêmio"), "⚽"]),
];
// palavras com força de título (capa / letreiro / onda), por peso
const FORCA = {
  visao: 5, rodada: 4, analise: 5, leitura: 4, estatistica: 4, estatisticas: 4, jogo: 3, jogao: 4, classico: 4,
  diversao: 4, grupo: 3, tropa: 4, cria: 3, final: 4, decisao: 4, numeros: 3, segredo: 4, detalhe: 3,
};
// nunca viram texto de motion (compliance OTG + palavras vazias)
const PROIBIDAS = new Set([
  "gratis", "lucro", "ganho", "ganhar", "dinheiro", "grana", "bet", "green", "red", "cravar", "aposta", "apostar",
  "forra", "alavancar", "metodo", "cashout", "banca", "garantido", "certeza", "brecha", "renda",
]);
const VAZIAS = new Set(
  "a o e de do da dos das em no na nos nas um uma para pra pro que se eu tu voce ele ela isso esse essa la aqui com por sobre mais muito so somente ja nao sim e eh".split(" "),
);
// gatilhos
const GATILHO_18 = ["18", "maiores", "responsabilidade", "responsavel", "consciente"];
const GATILHO_CTA = ["link", "clica", "clique", "entra", "entrar", "comenta", "chama", "bio"];
const GATILHO_PARTICULA = { futebol: "⚽", gol: "⚽", bola: "⚽", fogo: "🔥", brabo: "🔥", pesado: "🔥", olho: "👀", visao: "👀" };

// ---------- frases ----------
function frases(legendas) {
  const out = [];
  let atual = [];
  legendas.forEach((p, i) => {
    atual.push(i);
    const t = p.text.trim();
    const prox = legendas[i + 1];
    const pausa = prox ? prox.startMs - p.endMs : 0;
    if (/[.?!]$/.test(t) || pausa > 450 || !prox) {
      out.push(atual);
      atual = [];
    }
  });
  return out.map((idx) => ({ idx, ini: legendas[idx[0]].startMs, fim: legendas[idx[idx.length - 1]].endMs }));
}

const sobrepoe = (a, b, folga = 0) => a.deMs < b.ateMs + folga && b.deMs < a.ateMs + folga;
const titulo = (s) => s.charAt(0).toUpperCase() + s.slice(1);

export function planejarEdicao({ legendas, duracaoMs, nivel = "medio", opcoes = {} }) {
  const rel = [];
  const W = legendas.map((p) => ({ ...p, n: norm(p.text) }));
  const F = frases(W);
  const texto2 = (i) => (W[i + 1] ? `${W[i].n} ${W[i + 1].n}` : W[i].n);
  const texto3 = (i) => (W[i + 2] ? `${texto2(i)} ${W[i + 2].n}` : texto2(i));

  // ---- CTA: último gatilho de ação no terço final (preferência: "link") ----
  let ctaMs = null;
  let temLink = false;
  for (let i = W.length - 1; i >= 0; i--) {
    if (W[i].startMs < duracaoMs * 0.6) break;
    if (W[i].n === "link") {
      // começa no início da frase curta onde o link aparece ("o link está aqui")
      const ant = W[i - 1];
      ctaMs = ant && VAZIAS.has(ant.n) && W[i].startMs - ant.startMs < 400 ? ant.startMs : W[i].startMs;
      temLink = true;
      break;
    }
    if (ctaMs === null && GATILHO_CTA.includes(W[i].n)) ctaMs = W[i].startMs;
  }
  if (ctaMs === null) ctaMs = Math.max(0, duracaoMs - 2200);
  const cta = {
    deMs: ctaMs,
    texto: opcoes.cta?.texto || "Entra no grupo 👇",
    apoio: opcoes.cta?.apoio ?? (temLink ? "O link tá aqui embaixo" : undefined),
    cartelaSeg: 2.5,
  };
  rel.push(`CTA em ${(ctaMs / 1000).toFixed(2)}s (${temLink ? "fala do link" : "gatilho de ação/fim"})`);

  // janelas ocupadas na frente (REGRA DE FOCO) — vão sendo reservadas por prioridade
  const ocupadas = [{ deMs: ctaMs - 80, ateMs: 1e9, tipo: "cta" }];
  const livre = (j, folga = 700) => ocupadas.every((o) => !sobrepoe(j, o, folga));
  const reservar = (j) => ocupadas.push(j);

  // ---- selo +18 ----
  let selo18;
  const i18 = W.findIndex((p) => GATILHO_18.includes(p.n) && p.startMs < ctaMs - 1500);
  if (i18 >= 0) {
    // começa em "maiores"/"18" (o que vier primeiro na mesma frase)
    const fr = F.find((f) => f.idx.includes(i18));
    const ini = Math.min(...fr.idx.filter((k) => GATILHO_18.includes(W[k].n) && k >= i18 - 3).map((k) => W[k].startMs));
    const j = { deMs: ini, ateMs: Math.min(ini + 1900, ctaMs - 900), tipo: "selo" };
    if (j.ateMs - j.deMs > 1100 && livre(j, 300)) {
      selo18 = { deMs: j.deMs, ateMs: j.ateMs, texto: "Jogue com responsabilidade" };
      reservar(j);
      rel.push(`selo +18 em ${(ini / 1000).toFixed(2)}s`);
    }
  }

  // ---- cards: 2+ assuntos citados em até 3 s ----
  let cards;
  {
    const achados = [];
    W.forEach((p, i) => {
      for (const [chaves, nome, icone] of ASSUNTOS) {
        if (chaves.some((c) => c === p.n || c === texto2(i) || c === texto3(i))) {
          if (!achados.some((a) => a.texto === nome)) achados.push({ texto: nome, icone, ms: p.startMs });
          break;
        }
      }
    });
    for (let a = 0; a < achados.length && !cards; a++) {
      const grupo = achados.filter((x) => x.ms >= achados[a].ms && x.ms - achados[a].ms <= 3000).slice(0, 3);
      if (grupo.length >= 2) {
        const ultimo = grupo[grupo.length - 1].ms;
        const j = { deMs: grupo[0].ms - 80, ateMs: Math.max(ultimo + 470, grupo[0].ms + 1800), tipo: "cards" };
        if (livre(j, 500)) {
          cards = { itens: grupo, ateMs: j.ateMs };
          reservar(j);
          rel.push(`cards: ${grupo.map((g) => g.texto).join(", ")}`);
        }
      }
    }
  }

  // ---- palavras de força (para gancho/capa, letreiro e onda) ----
  const fortes = W.map((p, i) => ({ i, p, peso: (FORCA[p.n] ?? 0) + (p.n.length >= 5 && p.n.length <= 8 ? 0.5 : 0) }))
    .filter((x) => x.peso >= 3 && !PROIBIDAS.has(x.p.n))
    .sort((a, b) => b.peso - a.peso || a.p.startMs - b.p.startMs);

  // ---- gancho / capa (0 s até ~2,5 s) ----
  let gancho;
  {
    const ate = Math.min(2500, (F[1]?.ini ?? 2500) + 200);
    let l1;
    let l2;
    if (opcoes.gancho?.linha1 || opcoes.gancho?.linha2) {
      l1 = opcoes.gancho.linha1 || "";
      l2 = opcoes.gancho.linha2 || "";
      rel.push("gancho: texto do editor");
    } else if (fortes.length) {
      // palavra mais forte + até 2 palavras antes dela na mesma frase ("pegar a" + "visão")
      const { i } = fortes[0];
      const fr = F.find((f) => f.idx.includes(i));
      const antes = fr.idx.filter((k) => k < i).slice(-2).map((k) => W[k].text.trim().replace(/[.,?!]/g, ""));
      const verbo = antes.map((w) => w.replace(/ar$/i, "a")); // "pegar a" -> "pega a" (imperativo)
      l1 = verbo.length ? verbo.join(" ") : "Olha a";
      l2 = W[i].text.trim().replace(/[.,?!]/g, "");
      rel.push(`gancho automático a partir de "${antes.join(" ")} ${l2}"`);
    }
    if (l2) {
      gancho = { linha1: titulo(l1), linha2: titulo(l2), ateMs: ate };
      reservar({ deMs: 0, ateMs: ate, tipo: "gancho" });
    }
  }

  // ---- câmera: punch-in em cada frase, alternando perto/aberto ----
  const camera = [{ ms: 0, zoom: 1.0 }];
  const janelasMotion = ocupadas.filter((o) => o.tipo !== "gancho");
  let perto = true;
  let ultimo = 0;
  const marcos = [];
  F.forEach((f) => {
    marcos.push(f.ini);
    if (f.fim - f.ini > 3200) marcos.push(f.ini + (f.fim - f.ini) / 2); // frase longa: virada no meio
  });
  marcos
    .sort((a, b) => a - b)
    .forEach((ms) => {
      if (ms < (gancho ? gancho.ateMs : 1500) || ms > ctaMs - 300 || ms - ultimo < 1200) return;
      const emMotion = janelasMotion.some((o) => ms >= o.deMs - 200 && ms <= o.ateMs);
      if (emMotion) return;
      camera.push({ ms, zoom: perto ? 1.13 + (camera.length % 2) * 0.02 : 1.0, ...(perto ? {} : { flash: false }) });
      perto = !perto;
      ultimo = ms;
    });
  // nas entradas de motion a câmera abre (espaço para o elemento) com clarão
  for (const o of janelasMotion) {
    const ms = Math.max(0, o.deMs + 30);
    camera.push({ ms, zoom: o.tipo === "cta" ? 1.06 : 1.0, flash: o.tipo !== "selo" });
  }
  camera.sort((a, b) => a.ms - b.ms);
  // logo depois de cada motion, punch-in de volta
  for (const o of janelasMotion.filter((x) => x.tipo !== "cta")) {
    if (!camera.some((k) => k.ms > o.ateMs && k.ms < o.ateMs + 900)) camera.push({ ms: o.ateMs + 60, zoom: 1.14 });
  }
  camera.sort((a, b) => a.ms - b.ms);
  rel.push(`câmera: ${camera.length - 1} movimentos`);

  // ---- destaques da legenda: palavras de força + assuntos ----
  const destaques = [...new Set([...fortes.map((x) => x.p.n), ...W.filter((p) => ASSUNTOS.some(([c]) => c.includes(p.n))).map((p) => p.n), "link", "18", "responsabilidade"])];

  const plano = { camera, gancho, cards, selo18, cta, destaques, relatorio: rel };
  if (nivel !== "avancado") return plano;

  // ================= NÍVEL AVANÇADO: camadas atrás do expert =================
  const atras = [];
  if (gancho) {
    atras.push({ tipo: "capa", deMs: 0, ateMs: gancho.ateMs, pequeno: gancho.linha1, grande: gancho.linha2.replace(/\s*\p{Extended_Pictographic}/gu, "") });
    atras.push({ tipo: "luz", deMs: 0, ateMs: gancho.ateMs });
  }
  // letreiro: fim de frase com palavra forte (2–3 palavras), fora das janelas ocupadas
  for (const x of fortes) {
    const fr = F.find((f) => f.idx.includes(x.i));
    const resto = fr.idx.filter((k) => k >= x.i).slice(0, 3);
    const palavras = resto.map((k) => W[k].text.trim().replace(/[.,?!]/g, ""));
    if (palavras.length < 2 || palavras.some((w) => PROIBIDAS.has(norm(w)))) continue;
    const j = { deMs: W[resto[0]].startMs - 300, ateMs: Math.max(W[resto[resto.length - 1]].endMs + 250, W[resto[0]].startMs + 1200), tipo: "letreiro" };
    if (j.deMs < (gancho?.ateMs ?? 0) + 800 || !livre(j, 600)) continue;
    atras.push({ tipo: "letreiro", deMs: j.deMs, ateMs: j.ateMs, texto: palavras.join(" ") });
    reservar(j);
    rel.push(`letreiro: "${palavras.join(" ")}"`);
    break;
  }
  // partículas: palavras-gatilho (máx. 1 a cada 4 s) + explosão no CTA
  let ultP = -1e9;
  W.forEach((p) => {
    const emoji = GATILHO_PARTICULA[p.n];
    if (!emoji || p.startMs - ultP < 4000 || p.startMs > ctaMs - 1500) return;
    if (ocupadas.some((o) => o.tipo === "letreiro" && p.startMs >= o.deMs && p.startMs <= o.ateMs)) return;
    atras.push({ tipo: "particulas", ms: p.startMs, emoji, quantidade: 16 });
    ultP = p.startMs;
  });
  atras.push({ tipo: "particulas", ms: ctaMs, emoji: "⚡", quantidade: 14 });
  atras.push({ tipo: "luz", deMs: ctaMs, ateMs: duracaoMs + 2500 });
  // onda de cor em palavras fortes que sobraram (máx. 1 a cada 5 s), fora dos motions
  let ultO = -1e9;
  for (const x of [...fortes].sort((a, b) => a.p.startMs - b.p.startMs)) {
    const ms = x.p.startMs;
    if (ms - ultO < 5000 || ms > ctaMs - 1500 || ms < (gancho?.ateMs ?? 0) + 500) continue;
    if (ocupadas.some((o) => ms >= o.deMs - 300 && ms <= o.ateMs + 300)) continue;
    if (atras.some((e) => e.tipo === "particulas" && Math.abs(e.ms - ms) < 1500)) continue;
    atras.push({ tipo: "onda", ms });
    ultO = ms;
  }
  const foco = ocupadas.filter((o) => ["cards", "selo", "cta"].includes(o.tipo)).map((o) => ({ deMs: o.deMs + 80, ateMs: o.tipo === "cta" ? 99999 : o.ateMs }));
  const tremores = [...(cards ? [cards.itens[0].ms - 30] : []), ctaMs];
  rel.push(`atrás do expert: ${atras.map((e) => e.tipo).join(", ")}`);
  return { ...plano, atras, foco, tremores };
}

// ---------- uso isolado ----------
if (import.meta.url === `file://${process.argv[1]}`) {
  const [arq, nivel = "medio"] = process.argv.slice(2);
  const legendas = JSON.parse(fs.readFileSync(arq, "utf8"));
  const duracaoMs = legendas[legendas.length - 1].endMs + 200;
  const plano = planejarEdicao({ legendas, duracaoMs, nivel });
  console.log(plano.relatorio.join("\n"));
  const { relatorio, ...resto } = plano;
  console.log(JSON.stringify(resto, null, 1));
}

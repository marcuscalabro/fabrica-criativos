#!/usr/bin/env node
// Pipeline da Fábrica de Criativos — modelo "Fala legendada".
//
// Uso:
//   node scripts/editar.mjs --video bruto.mp4 --marca exemplo \
//     --gancho "..." --cta-titulo "..." --cta-subtitulo "..." \
//     [--destaques "palavra,outra"] [--zooms "1200,5400"] \
//     [--legendas legendas.json] [--id nome-do-job] [--sem-render]
//
// Etapas:
//   1. Mede o volume e detecta pausas (limiar adaptativo, EBU R128).
//   2. Corta as pausas, enquadra em 1080x1920 e normaliza o áudio (-14 LUFS).
//   3. Legendas: transcreve o vídeo limpo com Whisper (se instalado) ou usa um
//      JSON de legendas já pronto, reajustando os tempos aos cortes.
//   4. Gera o props.json do job e renderiza o criativo.

import { execFileSync, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const RAIZ = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const MODELO = "FalaLegendada";

// ---------- argumentos ----------
const args = {};
for (let i = 2; i < process.argv.length; i++) {
  const chave = process.argv[i];
  if (!chave.startsWith("--")) continue;
  const prox = process.argv[i + 1];
  if (prox === undefined || prox.startsWith("--")) args[chave.slice(2)] = true;
  else {
    args[chave.slice(2)] = prox;
    i++;
  }
}
const exigir = (k) => {
  if (!args[k]) {
    console.error(`Falta --${k}`);
    process.exit(1);
  }
  return args[k];
};

const video = path.resolve(exigir("video"));
const marca = exigir("marca");
const id = args.id || `${path.parse(video).name}-${Date.now()}`;
const pastaJob = path.join(RAIZ, "public", "jobs", id);
fs.mkdirSync(pastaJob, { recursive: true });
const log = (m) => console.log(`[${id}] ${m}`);

// ---------- 1. pausas ----------
const ffmpeg = (a) =>
  spawnSync("ffmpeg", ["-hide_banner", "-nostats", ...a], { encoding: "utf8" });

const duracao = Number(
  execFileSync("ffprobe", [
    "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video,
  ]).toString().trim(),
);

const medida = ffmpeg(["-i", video, "-map", "0:a", "-af", "loudnorm=print_format=json", "-f", "null", "-"]);
const json = medida.stderr.slice(medida.stderr.lastIndexOf("{"), medida.stderr.lastIndexOf("}") + 1);
const limiar = Number(JSON.parse(json).input_thresh);
log(`duração ${duracao.toFixed(2)}s, limiar de silêncio ${limiar} dB`);

const PAUSA_MIN = Number(args["pausa-min"] ?? 0.4); // segundos de silêncio que viram corte
const FOLGA = 0.12; // mantém um respiro antes/depois de cada fala
const det = ffmpeg(["-i", video, "-map", "0:a", "-af", `silencedetect=noise=${limiar}dB:d=${PAUSA_MIN}`, "-f", "null", "-"]);
const silencios = [];
let ini = null;
for (const linha of det.stderr.split("\n")) {
  const s = linha.match(/silence_start: ([\d.]+)/);
  const e = linha.match(/silence_end: ([\d.]+)/);
  if (s) ini = Number(s[1]);
  if (e && ini !== null) {
    silencios.push([ini, Number(e[1])]);
    ini = null;
  }
}
if (ini !== null) silencios.push([ini, duracao]);

// trechos de fala = complemento dos silêncios, com folga
let trechos = [];
let cursor = 0;
for (const [a, b] of silencios) {
  if (a > cursor) trechos.push([cursor, a]);
  cursor = b;
}
if (cursor < duracao) trechos.push([cursor, duracao]);
trechos = trechos
  .map(([a, b]) => [Math.max(0, a - FOLGA), Math.min(duracao, b + FOLGA)])
  .filter(([a, b]) => b - a > 0.15);
const unidos = [];
for (const t of trechos) {
  const ult = unidos.at(-1);
  if (ult && t[0] - ult[1] < 0.15) ult[1] = Math.max(ult[1], t[1]);
  else unidos.push([...t]);
}
if (args["sem-cortes"] || unidos.length === 0) unidos.splice(0, unidos.length, [0, duracao]);

// mapa de cortes: tempo original -> tempo no vídeo limpo
let saida = 0;
const mapa = unidos.map(([a, b]) => {
  const m = { origemIni: a, origemFim: b, saidaIni: saida };
  saida += b - a;
  return m;
});
const duracaoLimpa = saida;
log(`${silencios.length} pausas detectadas; ${(duracao - duracaoLimpa).toFixed(2)}s removidos; final ${duracaoLimpa.toFixed(2)}s`);

// ---------- 2. vídeo limpo 1080x1920 ----------
const limpo = path.join(pastaJob, "limpo.mp4");
const partes = mapa
  .map((m, i) =>
    `[0:v]trim=${m.origemIni}:${m.origemFim},setpts=PTS-STARTPTS[v${i}];` +
    `[0:a]atrim=${m.origemIni}:${m.origemFim},asetpts=PTS-STARTPTS[a${i}];`,
  )
  .join("");
const entradas = mapa.map((_, i) => `[v${i}][a${i}]`).join("");
const filtro =
  partes +
  `${entradas}concat=n=${mapa.length}:v=1:a=1[vc][ac];` +
  `[vc]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30,format=yuv420p[vout];` +
  `[ac]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[aout]`;
const arqFiltro = path.join(pastaJob, "filtro.txt");
fs.writeFileSync(arqFiltro, filtro);
const r = ffmpeg([
  "-y", "-i", video, "-filter_complex_script", arqFiltro,
  "-map", "[vout]", "-map", "[aout]",
  "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
  "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", limpo,
]);
if (r.status !== 0) {
  console.error(r.stderr.slice(-2000));
  process.exit(1);
}
log("vídeo limpo gerado");

// ---------- 3. legendas ----------
const remapear = (ms) => {
  const t = ms / 1000;
  const m = mapa.find((x) => t >= x.origemIni && t <= x.origemFim);
  return m ? Math.round((m.saidaIni + (t - m.origemIni)) * 1000) : null;
};

const kit = JSON.parse(fs.readFileSync(path.join(RAIZ, "public", "kits", marca, "kit.json"), "utf8"));
const { glossario = {}, ...kitModelo } = kit; // glossário é do pipeline, não do modelo

// As legendas são sempre feitas sobre o vídeo BRUTO e depois reajustadas aos cortes.
let brutas;
if (args.legendas) {
  // legenda pronta (revisada à mão, .json no formato Caption)
  brutas = JSON.parse(fs.readFileSync(path.resolve(args.legendas), "utf8"));
  log(`legendas lidas de ${args.legendas}`);
} else {
  const { transcrever, aplicarGlossario } = await import("./transcrever.mjs");
  const t0 = Date.now();
  brutas = aplicarGlossario(await transcrever(video, pastaJob), glossario);
  log(`${brutas.length} palavras transcritas em ${((Date.now() - t0) / 1000).toFixed(1)}s (Whisper local)`);
}
// cópia para revisão: corrija o texto em legendas-brutas.json e rode de novo com --legendas
fs.writeFileSync(path.join(pastaJob, "legendas-brutas.json"), JSON.stringify(brutas, null, 1));
fs.writeFileSync(path.join(pastaJob, "transcricao.txt"), brutas.map((c) => c.text).join("").trim() + "\n");
log(`texto: ${brutas.map((c) => c.text).join("").trim()}`);
if (args["so-transcrever"]) {
  log(`parado após a transcrição (--so-transcrever): ${path.relative(RAIZ, path.join(pastaJob, "legendas-brutas.json"))}`);
  process.exit(0);
}

const legendas = brutas
  .map((c) => {
    const s = remapear(c.startMs);
    const e = remapear(c.endMs) ?? (s !== null ? s + (c.endMs - c.startMs) : null);
    return s === null ? null : { ...c, startMs: s, endMs: e, timestampMs: c.timestampMs == null ? null : remapear(c.timestampMs) };
  })
  .filter(Boolean);
log(`${legendas.length} palavras de legenda reajustadas aos cortes`);
fs.writeFileSync(path.join(pastaJob, "legendas.json"), JSON.stringify(legendas, null, 2));

// ---------- 4. props + render ----------
const lista = (v) => (typeof v === "string" && v.trim() ? v.split(",").map((s) => s.trim()) : []);
const props = {
  video: `jobs/${id}/limpo.mp4`,
  duracaoVideoSeg: Number(duracaoLimpa.toFixed(3)),
  legendas,
  gancho: args.gancho || "",
  ctaTitulo: args["cta-titulo"] || "",
  ctaSubtitulo: args["cta-subtitulo"] || "",
  destaques: lista(args.destaques),
  zoomsMs: lista(args.zooms).map(Number),
  kit,
};
const arqProps = path.join(pastaJob, "props.json");
fs.writeFileSync(arqProps, JSON.stringify(props, null, 2));
fs.writeFileSync(path.join(pastaJob, "cortes.json"), JSON.stringify({ duracaoOriginal: duracao, duracaoLimpa, mapa }, null, 2));
log(`props salvas em ${path.relative(RAIZ, arqProps)}`);

if (!args["sem-render"]) {
  fs.mkdirSync(path.join(RAIZ, "out"), { recursive: true });
  const nome = `${marca}_fala-legendada-v1_${id}.mp4`;
  const rr = spawnSync(
    "npx",
    ["remotion", "render", MODELO, path.join("out", nome), `--props=${arqProps}`, "--log=error"],
    { cwd: RAIZ, stdio: "inherit" },
  );
  if (rr.status !== 0) process.exit(rr.status ?? 1);
  log(`criativo pronto: out/${nome}`);
}

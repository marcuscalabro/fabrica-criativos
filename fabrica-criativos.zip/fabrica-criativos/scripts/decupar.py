#!/usr/bin/env python3
"""DECUPAGEM — planeja e aplica os cortes de um vídeo bruto.

Entrada: vídeo bruto + palavras.json (transcrição palavra a palavra, Whisper local).
Saída (na pasta do job):
  plano.json      trechos mantidos e cada corte com o motivo (o editor pode reverter)
  decupado.mp4    vídeo cortado, mesma resolução do bruto, áudio sem estalo
  relatorio.json  resumo para o portal

O que é removido:
  pausa        silêncio entre falas (fica só um respiro natural, configurável)
  respiracao   som sem voz entre palavras (respiro, estalo de boca, barulho)
  hesitacao    voz sem palavra (é…, hã…, ãhn…) e muletas alongadas
  retake       frase começada e abandonada que é repetida depois (fica a última)
  repeticao    palavras repetidas na emenda (o grupo o grupo -> o grupo)
  bastidor     falas fora do roteiro: "de novo", "errei", "pera", "valendo"…
  alucinacao   palavra que a transcrição inventou onde não tem voz

Uso:
  python decupar.py planejar <bruto> <palavras.json> <pasta> [--ritmo natural|rapido|solto]
  python decupar.py renderizar <bruto> <pasta>     (usa pasta/plano.json, inclusive editado)
"""
import json
import os
import re
import subprocess
import sys
import unicodedata

import numpy as np

SR = 16000
HOP = 0.01  # 10 ms por quadro de análise

RITMOS = {
    # pausa mantida entre palavras da mesma frase / entre frases
    "rapido": {"dentro": 0.05, "entre": 0.10},
    "natural": {"dentro": 0.08, "entre": 0.16},
    "solto": {"dentro": 0.12, "entre": 0.26},
}
PAUSA_INTOCADA = 0.16  # silêncio menor que isso dentro da frase fica como está (é a fala)
PRE_FALA = 0.035  # folga antes do ataque da palavra
POS_FALA = 0.07  # folga depois do fim da palavra (decaimento, "s" final)

BASTIDOR = [
    "de novo", "denovo", "errei", "pera", "pera ai", "perai", "corta", "corta ai",
    "valendo", "gravando", "ta gravando", "vou de novo", "vamos de novo", "esquece",
    "nao nao", "foi mal", "recomeca", "recomecar", "do comeco", "mais uma", "de novo de novo",
]
MULETAS = {"e", "eh", "ah", "a", "ã", "ha", "hã", "han", "hum", "hmm", "uh", "um", "ahn", "ehn", "aham", "ééé"}


def norm(t):
    t = unicodedata.normalize("NFD", t.lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9]+", "", t)


# ---------------------------------------------------------------- áudio
def ler_audio(video):
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", video, "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32)


def analisar(x):
    """Por quadro de 10 ms: volume (dB), se tem voz (vozeado) e centroide espectral."""
    n = int(HOP * SR)
    jan = 2 * n
    q = max(1, (len(x) - jan) // n)
    db = np.zeros(q)
    voz = np.zeros(q)
    cent = np.zeros(q)
    w = np.hanning(jan)
    freqs = np.fft.rfftfreq(jan, 1 / SR)
    lag_min, lag_max = SR // 400, SR // 75
    for i in range(q):
        s = x[i * n : i * n + jan]
        e = np.sqrt(np.mean(s ** 2) + 1e-12)
        db[i] = 20 * np.log10(e + 1e-9)
        sp = np.abs(np.fft.rfft(s * w))
        cent[i] = (sp * freqs).sum() / (sp.sum() + 1e-9)
        s0 = s - s.mean()
        ac = np.correlate(s0, s0, "full")[jan - 1 :]
        if ac[0] > 1e-9:
            voz[i] = ac[lag_min:lag_max].max() / ac[0]
    return db, voz, cent


def suaviza_bool(b, juntar, minimo):
    """Fecha buracos menores que `juntar` quadros e apaga ilhas menores que `minimo`."""
    b = b.copy()
    idx = np.flatnonzero(b)
    if len(idx) == 0:
        return b
    for a, c in zip(idx[:-1], idx[1:]):
        if 1 < c - a <= juntar:
            b[a:c] = True
    i = 0
    while i < len(b):
        if b[i]:
            j = i
            while j < len(b) and b[j]:
                j += 1
            if j - i < minimo:
                b[i:j] = False
            i = j
        else:
            i += 1
    return b


# ---------------------------------------------------------------- planejamento
def planejar(bruto, arq_palavras, pasta, ritmo="natural"):
    R = RITMOS[ritmo]
    x = ler_audio(bruto)
    dur = len(x) / SR
    db, voz, cent = analisar(x)
    piso = np.percentile(db, 8)
    topo = np.percentile(db, 97)
    lim_fala = piso + max(14.0, 0.40 * (topo - piso))  # fala de verdade
    lim_som = piso + max(7.0, 0.18 * (topo - piso))  # qualquer som acima do ruído (respiro entra aqui)
    vozeado = (voz > 0.45) & (db > lim_som)
    fricativa = (cent > 3200) & (db > lim_som + 4)  # s, f, x, ch: sem voz mas é palavra
    fala = suaviza_bool((db > lim_fala) | vozeado | ((db > lim_som) & fricativa & (db > lim_fala - 6)), 4, 4)
    T = lambda f: f * HOP
    F = lambda t: int(np.clip(round(t / HOP), 0, len(db) - 1))

    palavras = json.load(open(arq_palavras))
    W = []
    for p in palavras:
        txt = p["text"].strip()
        if not txt:
            continue
        W.append({"texto": txt, "n": norm(txt), "ini": p["startMs"] / 1000, "fim": p["endMs"] / 1000})

    cortes = []  # {de, ate, motivo, texto}

    # 1. alucinação: palavra sem nenhuma fala embaixo
    for w in W:
        a, b = F(w["ini"]), F(max(w["fim"], w["ini"] + 0.05))
        w["fala"] = float(fala[a : b + 1].mean()) if b >= a else 0
        w["remover"] = None
        if w["fala"] < 0.12 and not w["n"].isdigit():
            w["remover"] = "alucinacao"

    # 2. ajusta as bordas de cada palavra pelo áudio (ataque e fim reais da fala)
    for k, w in enumerate(W):
        if w["remover"]:
            continue
        lo = w["ini"] - 0.18 if k == 0 else max(W[k - 1]["fim"] - 0.02, w["ini"] - 0.18)
        a0, a1 = F(lo), F(w["ini"] + 0.25)
        seg = np.flatnonzero(fala[a0 : a1 + 1])
        if len(seg):
            w["ini"] = T(a0 + seg[0])
        hi = w["fim"] + 0.22 if k == len(W) - 1 else min(W[k + 1]["ini"] + 0.02, w["fim"] + 0.22)
        b0, b1 = F(max(w["ini"] + 0.03, w["fim"] - 0.25)), F(hi)
        seg = np.flatnonzero(fala[b0 : b1 + 1])
        if len(seg):
            w["fim"] = max(w["ini"] + 0.05, T(b0 + seg[-1] + 1))

    vivos = lambda: [w for w in W if not w["remover"]]

    # 3. frases (separadas por pausa ou pontuação final)
    def frases():
        fs, atual = [], []
        V = vivos()
        for i, w in enumerate(V):
            atual.append(w)
            prox = V[i + 1] if i + 1 < len(V) else None
            if prox is None or prox["ini"] - w["fim"] > 0.32 or re.search(r"[.!?]$", w["texto"]):
                fs.append(atual)
                atual = []
        return fs

    # 4. bastidor: frase que contém fala de set -> sai a frase inteira e o take anterior se ficou pela metade
    FS = frases()
    for i, f in enumerate(FS):
        txt = " " + " ".join(norm(w["texto"]) for w in f) + " "
        txt_sp = " " + " ".join(re.sub(r"[^a-z0-9 ]", "", unicodedata.normalize("NFD", w["texto"].lower()).encode("ascii", "ignore").decode()) for w in f) + " "
        # só conta como bastidor se a frase for curta e quase toda feita de fala de set
        # ("pera, de novo", "errei, vou de novo"); "bateu de novo!" do roteiro fica.
        achados = [b for b in BASTIDOR if f" {b} " in txt_sp]
        cobertura = sum(len(b.split()) for b in achados) / max(1, len(f))
        if len(f) <= 5 and achados and cobertura >= 0.5:
            for w in f:
                w["remover"] = "bastidor"
            if i > 0 and not re.search(r"[.!?]$", FS[i - 1][-1]["texto"]):
                for w in FS[i - 1]:
                    w["remover"] = w["remover"] or "retake"

    # 5. retake: frase A cujo começo é repetido pela frase seguinte -> A sai (fica a última tentativa)
    def parecido(a, b):
        if not a or not b:
            return False
        if a == b:
            return True
        if len(a) >= 4 and len(b) >= 4 and (a.startswith(b[:4]) or b.startswith(a[:4])):
            return True
        return False

    mudou = True
    while mudou:
        mudou = False
        FS = frases()
        for i in range(len(FS) - 1):
            A = [w["n"] for w in FS[i]]
            for j in range(i + 1, min(i + 3, len(FS))):
                B = [w["n"] for w in FS[j]]
                k = min(len(A), len(B), 3)
                iguais = sum(parecido(A[t], B[t]) for t in range(k))
                if k >= 2 and iguais >= k - (1 if k == 3 else 0) or (k == 1 and len(A) == 1 and parecido(A[0], B[0])):
                    # A é a tentativa abandonada se for mais curta ou igual (repetiu e seguiu em frente)
                    if len(A) <= len(B) + 1:
                        alvo = FS[i:j]
                        for f in alvo:
                            for w in f:
                                w["remover"] = "retake"
                        mudou = True
                        break
            if mudou:
                break

    # 6. repetição na emenda dentro da frase (n-grama repetido em seguida) e muletas alongadas
    mudou = True
    while mudou:
        mudou = False
        V = vivos()
        ns = [w["n"] for w in V]
        for n in (4, 3, 2, 1):
            for a in range(len(V) - 2 * n + 1):
                if ns[a : a + n] == ns[a + n : a + 2 * n] and all(ns[a : a + n]):
                    hes = V[a + n]["ini"] - V[a + n - 1]["fim"]
                    cortada = (V[a + n - 1]["fim"] - V[a + n - 1]["ini"]) < 0.12
                    if n >= 2 or hes > 0.18 or cortada:
                        for w in V[a : a + n]:
                            w["remover"] = "repeticao"
                        mudou = True
                        break
            if mudou:
                break
        if not mudou:
            # palavra cortada no meio seguida da palavra inteira: "gra… grátis"
            for a in range(len(V) - 1):
                p, q = ns[a], ns[a + 1]
                if 2 <= len(p) < len(q) and q.startswith(p) and V[a + 1]["ini"] - V[a]["fim"] > 0.08:
                    V[a]["remover"] = "repeticao"
                    mudou = True
                    break

    for w in vivos():
        d = w["fim"] - w["ini"]
        if w["n"] in MULETAS and (d > 0.32 or w["n"] not in {"e", "a"}):
            w["remover"] = "hesitacao"

    # 7. monta os trechos mantidos a partir das palavras vivas
    V = vivos()
    if not V:
        raise SystemExit("nenhuma fala encontrada")
    trechos = []
    for i, w in enumerate(V):
        ini, fim = w["ini"] - PRE_FALA, w["fim"] + POS_FALA
        if trechos and ini - trechos[-1]["fim"] <= 0:
            trechos[-1]["fim"] = max(trechos[-1]["fim"], fim)
            trechos[-1]["palavras"].append(w["texto"])
            continue
        if trechos:
            prev = V[i - 1]
            vao = w["ini"] - prev["fim"]
            mesma_frase = not re.search(r"[.!?]$", prev["texto"])
            contiguo = prev is W[W.index(w) - 1]  # nada removido entre as duas
            if contiguo and vao <= PAUSA_INTOCADA:
                trechos[-1]["fim"] = max(trechos[-1]["fim"], fim)
                trechos[-1]["palavras"].append(w["texto"])
                continue
            manter = R["dentro"] if mesma_frase else R["entre"]
            # o respiro mantido entra metade em cada lado da emenda
            trechos[-1]["fim"] = min(trechos[-1]["fim"], prev["fim"] + max(POS_FALA, manter / 2))
            ini = max(ini, w["ini"] - max(PRE_FALA, manter / 2))
        trechos.append({"ini": ini, "fim": fim, "palavras": [w["texto"]]})

    # quadro a quadro (o corte do vídeo cai sempre num quadro inteiro)
    fps = obter_fps(bruto)
    for t in trechos:
        t["ini"] = max(0.0, np.floor(t["ini"] * fps) / fps)
        t["fim"] = min(dur, np.ceil(t["fim"] * fps) / fps)
    junt = [trechos[0]]
    for t in trechos[1:]:
        if t["ini"] <= junt[-1]["fim"] + 0.5 / fps:
            junt[-1]["fim"] = max(junt[-1]["fim"], t["fim"])
            junt[-1]["palavras"] += t["palavras"]
        else:
            junt.append(t)
    trechos = junt

    # 8. descreve cada corte (o que tinha no buraco)
    cursor = 0.0
    for t in trechos + [{"ini": dur, "fim": dur}]:
        if t["ini"] - cursor > 0.001:
            de, ate = cursor, t["ini"]
            dentro = [w for w in W if w["ini"] < ate - 0.02 and w["fim"] > de + 0.02 and w["remover"]]
            motivos = sorted({w["remover"] for w in dentro})
            if not motivos:
                a, b = F(de), F(ate)
                som = (db[a:b] > lim_som).mean() if b > a else 0
                vz = vozeado[a:b].mean() if b > a else 0
                motivos = ["hesitacao"] if vz > 0.25 else ["respiracao"] if som > 0.3 else ["pausa"]
            cortes.append({"de": round(de, 3), "ate": round(ate, 3), "duracao": round(ate - de, 3), "motivo": motivos, "texto": " ".join(w["texto"] for w in dentro)})
        cursor = t["fim"]

    plano = {
        "bruto": os.path.abspath(bruto),
        "ritmo": ritmo,
        "fps": fps,
        "duracaoBruto": round(dur, 3),
        "duracaoFinal": round(sum(t["fim"] - t["ini"] for t in trechos), 3),
        "trechos": [{"ini": round(t["ini"], 4), "fim": round(t["fim"], 4), "texto": " ".join(t["palavras"])} for t in trechos],
        "cortes": cortes,
        "roteiroFinal": " ".join(w["texto"] for w in vivos()),
        "transcricaoBruta": " ".join(w["texto"] for w in W),
    }
    json.dump(plano, open(os.path.join(pasta, "plano.json"), "w"), ensure_ascii=False, indent=1)
    return plano


def obter_fps(video):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=r_frame_rate", "-of", "csv=p=0", video], capture_output=True, text=True).stdout.strip()
    a, b = r.split("/")
    return float(a) / float(b)


# ---------------------------------------------------------------- render
def renderizar(bruto, pasta, saida=None):
    plano = json.load(open(os.path.join(pasta, "plano.json")))
    T = plano["trechos"]
    saida = saida or os.path.join(pasta, "decupado.mp4")
    FADE = 0.008  # 8 ms de fade em cada emenda: tira o estalo sem ninguém perceber
    partes, rotulos = [], []
    for i, t in enumerate(T):
        d = t["fim"] - t["ini"]
        partes.append(f"[0:v]trim=start={t['ini']}:end={t['fim']},setpts=PTS-STARTPTS[v{i}]")
        partes.append(
            f"[0:a]atrim=start={t['ini']}:end={t['fim']},asetpts=PTS-STARTPTS,"
            f"afade=t=in:st=0:d={FADE},afade=t=out:st={max(0, d - FADE):.4f}:d={FADE}[a{i}]"
        )
        rotulos.append(f"[v{i}][a{i}]")
    partes.append("".join(rotulos) + f"concat=n={len(T)}:v=1:a=1[v][a]")
    fc = os.path.join(pasta, "corte.ffscript")
    open(fc, "w").write(";\n".join(partes))
    subprocess.run(
        ["ffmpeg", "-v", "error", "-y", "-i", bruto, "-filter_complex_script", fc, "-map", "[v]", "-map", "[a]",
         "-c:v", "libx264", "-preset", "medium", "-crf", "16", "-pix_fmt", "yuv420p", "-r", str(plano["fps"]),
         "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart", saida],
        check=True,
    )
    return saida


# ---------------------------------------------------------------- conferência
def verificar(pasta, arq_palavras_final):
    """Confere o vídeo decupado de forma independente:
    1. transcreve de novo e compara com o roteiro esperado (palavra sumida ou sobrando)
    2. procura repetição que sobrou (o grupo o grupo)
    3. mede o áudio final: pausa longa que sobrou e emenda em cima da fala
    """
    import difflib

    plano = json.load(open(os.path.join(pasta, "plano.json")))
    final = os.path.join(pasta, "decupado.mp4")
    esperado = [norm(t) for t in plano["roteiroFinal"].split() if norm(t)]
    ouvido_w = [p for p in json.load(open(arq_palavras_final)) if norm(p["text"])]
    ouvido = [norm(p["text"]) for p in ouvido_w]
    alertas = []

    sm = difflib.SequenceMatcher(a=esperado, b=ouvido, autojunk=False)
    for op, a0, a1, b0, b1 in sm.get_opcodes():
        if op == "equal":
            continue
        e, o = " ".join(esperado[a0:a1]), " ".join(ouvido[b0:b1])
        # diferença só de grafia (pra/para, tá/está, número) não é erro de corte
        if e and o and difflib.SequenceMatcher(a=e, b=o).ratio() > 0.6:
            continue
        t = ouvido_w[min(b0, len(ouvido_w) - 1)]["startMs"] / 1000 if ouvido_w else 0
        if op == "delete" or (op == "replace" and len(e) > len(o) + 3):
            alertas.append({"tipo": "palavra_sumiu", "em": round(t, 2), "esperado": e, "ouvido": o})
        else:
            alertas.append({"tipo": "sobrou_fala", "em": round(t, 2), "esperado": e, "ouvido": o})

    for n in (3, 2, 1):
        for a in range(len(ouvido) - 2 * n + 1):
            if ouvido[a : a + n] == ouvido[a + n : a + 2 * n] and (n > 1 or len(ouvido[a]) > 3):
                alertas.append({"tipo": "repeticao_restante", "em": round(ouvido_w[a]["startMs"] / 1000, 2), "ouvido": " ".join(ouvido[a : a + 2 * n])})

    x = ler_audio(final)
    db, voz, cent = analisar(x)
    piso, topo = np.percentile(db, 8), np.percentile(db, 97)
    lim_fala = piso + max(14.0, 0.40 * (topo - piso))
    fala = suaviza_bool(db > lim_fala - 4, 3, 3)
    R = RITMOS[plano["ritmo"]]
    i = 0
    while i < len(fala):
        if not fala[i]:
            j = i
            while j < len(fala) and not fala[j]:
                j += 1
            d = (j - i) * HOP
            if i > 0 and j < len(fala) and d > R["entre"] + 0.18:
                alertas.append({"tipo": "pausa_longa", "em": round(i * HOP, 2), "duracao": round(d, 2)})
            i = j
        else:
            i += 1
    # emendas: onde o corte cai, o som de um lado não pode estar no meio da palavra
    t = 0.0
    for tr in plano["trechos"][:-1]:
        t += tr["fim"] - tr["ini"]
        f = int(t / HOP)
        if 2 <= f < len(db) - 2 and db[f - 2] > lim_fala + 6 and db[f + 1] > lim_fala + 6:
            alertas.append({"tipo": "emenda_na_fala", "em": round(t, 2)})

    rel = {
        "duracaoBruto": plano["duracaoBruto"],
        "duracaoFinal": plano["duracaoFinal"],
        "removido": round(plano["duracaoBruto"] - plano["duracaoFinal"], 2),
        "cortes": len(plano["cortes"]),
        "porMotivo": {},
        "roteiroFinal": plano["roteiroFinal"],
        "conferencia": " ".join(p["text"].strip() for p in ouvido_w),
        "alertas": alertas,
        "aprovado": not alertas,
    }
    for c in plano["cortes"]:
        for m in c["motivo"]:
            rel["porMotivo"][m] = rel["porMotivo"].get(m, 0) + 1
    json.dump(rel, open(os.path.join(pasta, "relatorio.json"), "w"), ensure_ascii=False, indent=1)
    return rel


if __name__ == "__main__":
    if sys.argv[1] == "verificar":
        r = verificar(sys.argv[2], sys.argv[3])
        print(json.dumps({k: r[k] for k in ("removido", "cortes", "porMotivo", "aprovado", "alertas")}, ensure_ascii=False))
        sys.exit(0)
    cmd = sys.argv[1]
    if cmd == "planejar":
        ritmo = sys.argv[sys.argv.index("--ritmo") + 1] if "--ritmo" in sys.argv else "natural"
        p = planejar(sys.argv[2], sys.argv[3], sys.argv[4], ritmo)
        print(json.dumps({k: p[k] for k in ("duracaoBruto", "duracaoFinal", "roteiroFinal")}, ensure_ascii=False))
    elif cmd == "renderizar":
        print(renderizar(sys.argv[2], sys.argv[3]))

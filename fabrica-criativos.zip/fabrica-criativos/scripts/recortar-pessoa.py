#!/usr/bin/env python3
"""Recorta o expert do fundo, quadro a quadro, e grava um vídeo com transparência.

Usado pelo nível AVANÇADO do Criativo completo: com a pessoa recortada, os
motions podem ficar ATRÁS do expert (texto gigante, partículas, cor de fundo),
sem nunca ficar na frente do rosto.

Uso:  .venv-visao/bin/python scripts/recortar-pessoa.py limpo.mp4 pessoa.webm [mascaras.npy]
Modelo local: modelos-ia/segmentacao/u2net_human_seg.onnx (roda 100% offline).
"""
import os
import subprocess
import sys
import time

import cv2
import numpy as np
import onnxruntime as ort

MODELO = os.path.join(os.path.dirname(__file__), "..", "modelos-ia", "segmentacao", "u2net_human_seg.onnx")
LADO = 320
MEDIA = np.array([0.485, 0.456, 0.406], dtype=np.float32)
DESVIO = np.array([0.229, 0.224, 0.225], dtype=np.float32)


def mascara(sessao, nome_in, quadro_rgb):
    x = cv2.resize(quadro_rgb, (LADO, LADO), interpolation=cv2.INTER_AREA).astype(np.float32) / 255.0
    x = (x - MEDIA) / DESVIO
    x = x.transpose(2, 0, 1)[None]
    m = sessao.run(None, {nome_in: x})[0][0, 0]
    m = (m - m.min()) / (m.max() - m.min() + 1e-6)
    return m


def main(entrada, saida, cache=None):
    opcoes = ort.SessionOptions()
    opcoes.intra_op_num_threads = os.cpu_count() or 2
    sessao = ort.InferenceSession(MODELO, opcoes, providers=["CPUExecutionProvider"])
    nome_in = sessao.get_inputs()[0].name

    cap = cv2.VideoCapture(entrada)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    if cache and os.path.exists(cache):
        mascaras = np.load(cache)
    else:
        mascaras = []
        t0 = time.time()
        while True:
            ok, q = cap.read()
            if not ok:
                break
            mascaras.append((mascara(sessao, nome_in, cv2.cvtColor(q, cv2.COLOR_BGR2RGB)) * 255).astype(np.uint8))
            if len(mascaras) % 50 == 0:
                print(f"{len(mascaras)}/{total} quadros ({time.time() - t0:.0f}s)", flush=True)
        mascaras = np.stack(mascaras)
        if cache:
            np.save(cache, mascaras)
        cap.release()
        cap = cv2.VideoCapture(entrada)

    # suavização temporal (evita bordas tremendo) + refino da borda
    m = mascaras.astype(np.float32) / 255.0
    suave = m.copy()
    for i in range(1, len(m)):
        suave[i] = 0.55 * m[i] + 0.45 * suave[i - 1]

    ff = subprocess.Popen(
        [
            "ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{W}x{H}", "-r", str(fps), "-i", "-",
            "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "6M", "-auto-alt-ref", "0", "-deadline", "realtime", "-cpu-used", "8", saida,
        ],
        stdin=subprocess.PIPE,
    )
    for i in range(len(suave)):
        ok, q = cap.read()
        if not ok:
            break
        a = cv2.resize(suave[i], (W, H), interpolation=cv2.INTER_LINEAR)
        # curva: corpo sólido, borda curta e macia
        a = np.clip((a - 0.25) / 0.5, 0, 1)
        a = cv2.GaussianBlur(a, (0, 0), 1.6)
        rgba = np.dstack([cv2.cvtColor(q, cv2.COLOR_BGR2RGB), (a * 255).astype(np.uint8)])
        ff.stdin.write(rgba.tobytes())
    ff.stdin.close()
    ff.wait()
    print(f"pessoa recortada: {saida}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)

#!/usr/bin/env python3
"""Detecta o rosto do expert ao longo do vídeo e gera a ZONA PROTEGIDA.

Regra primordial da Fábrica: nenhum texto, imagem, sticker ou elemento gráfico
pode ficar na frente do rosto do expert. Este script mede onde o rosto está a
cada ~1/6 s e grava rostos.json, que os modelos usam para posicionar tudo fora
da zona protegida.

Uso:  .venv-visao/bin/python scripts/detectar-rosto.py video.mp4 saida/rostos.json

Roda 100% local (OpenCV, classificadores Haar que já vêm no pacote).
"""
import json
import sys

import cv2
import numpy as np

AMOSTRAS_POR_SEG = 6
LARGURA_ANALISE = 540
# margens da zona protegida, em proporção do tamanho do rosto
MARGEM_LADOS = 0.35
MARGEM_TOPO = 0.55  # cabelo / testa
MARGEM_BAIXO = 0.40  # queixo / barba


def carregar(nome):
    return cv2.CascadeClassifier(cv2.data.haarcascades + nome)


FRONTAL = [carregar("haarcascade_frontalface_default.xml"), carregar("haarcascade_frontalface_alt2.xml")]
PERFIL = carregar("haarcascade_profileface.xml")


def detectar(cinza, anterior):
    h, w = cinza.shape
    minimo = int(w * 0.10)
    caixas = []
    for c in FRONTAL:
        caixas += [tuple(map(int, b)) for b in c.detectMultiScale(cinza, 1.1, 6, minSize=(minimo, minimo))]
    for img, espelho in ((cinza, False), (cv2.flip(cinza, 1), True)):
        for x, y, bw, bh in PERFIL.detectMultiScale(img, 1.1, 6, minSize=(minimo, minimo)):
            caixas.append((int(w - x - bw) if espelho else int(x), int(y), int(bw), int(bh)))
    if not caixas:
        return None

    def nota(b):
        x, y, bw, bh = b
        area = bw * bh
        if anterior is None:
            return area
        ax, ay, aw, ah = anterior
        dist = np.hypot((x + bw / 2) - (ax + aw / 2), (y + bh / 2) - (ay + ah / 2))
        return area - dist * aw * 0.8  # prefere o rosto perto do anterior (estabilidade)

    return max(caixas, key=nota)


def main(entrada, saida):
    cap = cv2.VideoCapture(entrada)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    H = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    passo = max(1, round(fps / AMOSTRAS_POR_SEG))
    escala = W / LARGURA_ANALISE

    amostras, anterior, n = [], None, 0
    while True:
        ok = cap.grab()
        if not ok:
            break
        if n % passo == 0:
            _, quadro = cap.retrieve()
            peq = cv2.resize(quadro, (LARGURA_ANALISE, int(H / escala)))
            cinza = cv2.equalizeHist(cv2.cvtColor(peq, cv2.COLOR_BGR2GRAY))
            b = detectar(cinza, anterior)
            if b is not None:
                anterior = b
            amostras.append({"tMs": round(n / fps * 1000), "rosto": None if b is None else [v * escala for v in b]})
        n += 1
    cap.release()

    achados = [a for a in amostras if a["rosto"]]
    if not achados:
        json.dump({"largura": W, "altura": H, "amostras": [], "uniao": None}, open(saida, "w"))
        print("nenhum rosto encontrado")
        return

    # preenche buracos com o vizinho mais próximo e suaviza (mediana de 5)
    for i, a in enumerate(amostras):
        if a["rosto"] is None:
            viz = min(achados, key=lambda x: abs(x["tMs"] - a["tMs"]))
            a["rosto"] = viz["rosto"]
    arr = np.array([a["rosto"] for a in amostras], dtype=float)
    suav = arr.copy()
    for i in range(len(arr)):
        suav[i] = np.median(arr[max(0, i - 2) : i + 3], axis=0)

    def zona(x, y, bw, bh):
        x0 = max(0.0, x - bw * MARGEM_LADOS)
        y0 = max(0.0, y - bh * MARGEM_TOPO)
        x1 = min(float(W), x + bw * (1 + MARGEM_LADOS))
        y1 = min(float(H), y + bh * (1 + MARGEM_BAIXO))
        return [round(x0), round(y0), round(x1 - x0), round(y1 - y0)]

    saida_amostras = []
    for a, (x, y, bw, bh) in zip(amostras, suav):
        saida_amostras.append({"tMs": a["tMs"], "rosto": [round(x), round(y), round(bw), round(bh)], "zona": zona(x, y, bw, bh)})

    z = np.array([s["zona"] for s in saida_amostras], dtype=float)
    # união robusta: ignora 3% de amostras fora da curva de cada lado
    x0 = np.percentile(z[:, 0], 3)
    y0 = np.percentile(z[:, 1], 3)
    x1 = np.percentile(z[:, 0] + z[:, 2], 97)
    y1 = np.percentile(z[:, 1] + z[:, 3], 97)
    uniao = [round(x0), round(y0), round(x1 - x0), round(y1 - y0)]

    json.dump(
        {"largura": W, "altura": H, "intervaloMs": round(passo / fps * 1000), "amostras": saida_amostras, "uniao": uniao},
        open(saida, "w"),
        indent=1,
    )
    print(f"{len(achados)}/{len(amostras)} amostras com rosto; zona protegida (união): x={uniao[0]} y={uniao[1]} w={uniao[2]} h={uniao[3]}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])

# Modelo "Decupagem" (Criativos em vídeo)

O editor sobe o bruto e recebe o vídeo 100% decupado: só cortes, nada é adicionado. Resolução, fps e cor ficam iguais aos do bruto.

```
node scripts/decupar.mjs --video bruto.mp4 [--id nome] [--ritmo natural|rapido|solto]
node scripts/decupar.mjs --id nome --refazer   # depois de editar public/jobs/dec-<id>/plano.json
```

Saída: `out/decupagem/<id>_decupado.mp4`. Em `public/jobs/dec-<id>/` ficam:
- `plano.json`: trechos mantidos, cortes com motivo, emendas de take e suspeitas;
- `relatorio.json`: conferência e alertas.

## Etapas
1. **Blocos de fala** (`decupar.py blocos`): a fala é separada pelo áudio (voz, volume e fricativas), com pausa de pelo menos 0,22 s entre blocos. O respiro não conta como fala.
2. **Transcrição bloco a bloco** (`transcreverBlocos`): cada bloco é transcrito sozinho. Com o áudio inteiro, o Whisper "limpa" a fala e esconde o take errado e a repetição (testado: juntou "São 300… São 300 mil pessoas no meu… no meu grupo" numa frase só).
3. **Plano** (`decupar.py planejar`):
   - **Bordas:** a borda de cada palavra é ajustada pelo áudio (ataque e fim reais), com folga de 35 ms antes e 70 ms depois.
   - **Takes e repetições pelo SOM:** em cada fim de bloco, o MFCC é comparado em fatias de 20 ms com o começo do bloco seguinte (tolera ritmo ±15%). Se o começo de B repete A inteiro, A sai como **retake**. Se repete só o fim de A, esse fim sai a partir do ponto exato, como **repetição**. Fica sempre a última tentativa. O som decide mesmo quando a transcrição escreve diferente.
   - **Pelo texto** (reforço):
     - frase recomeçada;
     - n-grama repetido ("o grupo o grupo");
     - palavra cortada seguida da palavra inteira ("gra… grátis");
     - muletas alongadas ("é…", "hã");
     - fala de bastidor ("pera, de novo", "errei"), só em frase curta feita quase toda disso, para não cortar "bateu de novo!" do roteiro;
     - palavra inventada pela transcrição onde não tem voz.
   - **Pausas e respiros:** tudo entre palavras que não é fala sai. Fica um respiro de acordo com o ritmo:

     | Ritmo | Dentro da frase | Entre frases |
     |---|---|---|
     | Rápido | 50 ms | 100 ms |
     | Natural | 80 ms | 160 ms |
     | Solto | 120 ms | 260 ms |

     Pausas menores que 160 ms dentro da frase não são mexidas (fazem parte da fala).
   - **Fala sem transcrição:** quando um bloco tem bem mais voz do que as sílabas transcritas, ele vai para revisão.
4. **Render:** os cortes caem em quadro inteiro, com fade de 8 ms no áudio de cada emenda (sem estalo). Vídeo em CRF 16 e áudio em 256k.
5. **Conferência independente** (`decupar.py verificar`): o vídeo decupado é transcrito de novo, bloco a bloco, e medido. Entra como alerta:
   - palavra que sumiu ou sobrou perto de uma emenda (longe das emendas o áudio é o original, então diferença ali é da transcrição);
   - repetição que restou;
   - pausa longa que restou;
   - respiro que restou (som sem voz por mais de 0,18 s);
   - emenda duplicada (o som antes do corte se repete depois);
   - corte em cima da palavra (no bruto, fora das emendas de take);
   - fala sem transcrição que foi mantida.

   Com qualquer alerta, o vídeo não vai para compliance: volta para o editor revisar.

## Revisão no portal
O editor vê a lista de cortes (tempo, motivo, texto removido) e pode desmarcar qualquer um. A Fábrica refaz a emenda (`--refazer`) e confere de novo.

## Testes
- `dec-gg36`: vídeo já editado. Removeu só 0,07 s. Os alertas de texto falsos que apareceram aqui levaram à regra de alertar só perto das emendas.
- `dec-sim1`: bruto simulado a partir do GRUPO_GRATIS_36, com take errado, repetição de 0,24 s ("no meu no meu"), 4 pausas longas e respiro. Resultado: tudo removido, corte da repetição a 10 ms do ponto exato, transcrição final igual ao original, conferência aprovada.
- Pendente: brutos reais do Tylty, para calibrar com erros de verdade.

## Limites conhecidos
- A transcrição local é o Whisper-small. Ele erra palavras ("desse faz", "morre de 18"), e por isso nenhuma decisão crítica depende só do texto. Na versão no ar, um Whisper maior melhora ainda mais.
- Repetição colada, sem pausa nenhuma e com ritmo bem diferente, pode passar pelo som. Nesse caso a conferência pega pela transcrição nova ou pela regra de fala sem transcrição.

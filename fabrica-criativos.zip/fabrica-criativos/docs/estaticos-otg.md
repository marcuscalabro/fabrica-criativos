# Estáticos OTG — padrão real (referências de 03/11/2026)

Fonte: 6 estáticos reais do Lucas Tylty, enviados pelo diretor criativo. Todo estático da Fábrica segue isto.

## Regras comuns (todas as peças)
- 1080x1920. O conteúdo fica **só na faixa central** (y ≈ 380–1540). Topo e base ficam vazios por causa da interface do Reels/Stories.
- **Aviso legal em linha**, sem cartão e sem etiqueta #PUBLICIDADE. Tem um "+18" num círculo vazado à esquerda, texto de ~16–17 px em 2 linhas, alinhado à esquerda, logo abaixo do CTA:
  "Jogue com responsabilidade. Palpite não é investimento. Esse conteúdo segue todas as diretrizes impostas pela regulamentação e é um conteúdo publicitário sobre jogo responsável. Ganhos passados não garantem ganhos futuros."
- **CTA**:
  - Formato: retângulo cheio na largura do bloco, ~78 px de altura, raio ~8. Fonte sans pesada em CAIXA ALTA, muitas vezes com 👇.
  - Cores vistas: vermelho #E31212 com texto branco; roxo #7B45CC com texto verde #2BEA8A; azul #0A5BFF com texto branco; rosa #FF1F5A com texto branco; pílula branca com texto preto itálico.
- **Copy**:
  - Manchete-gancho em CAIXA ALTA, corpo curto com um trecho em **negrito** ou uma palavra com marcador colorido (fundo vermelho).
  - Vocabulário recorrente: "diversão / divirta-se", "leitura dos jogos", "grupo", "pegue / copie / entra agora".
- Escudos dos times do jogo aparecem com frequência, ao lado do rosto e nunca sobre ele.

## Estilo A — Tweet (modelo `Tweet` v2)
- Fundo **branco liso**; o bloco inteiro fica centralizado verticalmente.
- **Cabeçalho**:
  - Variante `perfil` (ref. "A I.A JÁ ANALISOU"): avatar de ~80 px, "Lucas Tylty" com selo azul e @lucastylty em cinza; manchete e corpo vêm abaixo.
  - Variante `manchete` (ref. "A TROPA JÁ TÁ NO GRUPO"): avatar grande de ~166 px à esquerda e, ao lado, nome com selo e manchete em CAIXA ALTA **sublinhada linha a linha**; o corpo vem abaixo, em fonte grande (~44 px).
- **Mídia**: quadro com cantos arredondados (~14), borda cinza fina, foto do expert. Pode ser foto única larga ou dividida em 2 (ex.: escudos no gramado + foto).
- A foto fica num quadro próprio e nada a sobrepõe; o recorte é feito pela zona do rosto.

## Estilo B — Foto escura + manchete (próximo modelo a construir)
- Foto do Tylty em tela cheia, escura ou P&B, com vinheta preta.
- Manchete em sans itálica pesada (CAIXA ALTA) ou em caixas vermelhas/brancas, acima do rosto.
- Escudos ao lado do rosto; CTA em botão e aviso em linha abaixo.
- Variante "Nota de despedida": serif em caixas brancas, em cima do tronco.

## Estilo C — Recorte em fundo branco
- Foto do Tylty recortada (sem fundo) em cima.
- Manchete em CAIXA ALTA preta, risco vermelho "pincel" abaixo, corpo com trecho em negrito.
- Botão rosa e aviso em linha.

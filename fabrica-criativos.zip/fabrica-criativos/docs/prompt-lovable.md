# Prompt do portal para o Lovable (27/10/2026)

Copiado da conversa original. Atenção: é anterior aos modelos Criativo completo, Variação, Decupagem, Tweet e Bingo, e à divisão Vídeo/Estáticos — precisa ser atualizado antes de usar.

```
Crie um portal web chamado "Fábrica de Criativos" (interface 100% em português do Brasil) para uma equipe de editores de vídeo. O portal NÃO edita vídeo: ele recebe o vídeo bruto, guarda as escolhas do editor e acompanha o status. A edição é feita por um serviço externo (worker) que lê e escreve nas mesmas tabelas do Supabase. Não implemente nenhum processamento de vídeo, transcrição ou render no app.

## Stack
- React + Tailwind + shadcn/ui, Supabase (Auth, Postgres, Storage, Realtime).
- Visual: tema escuro, limpo e profissional; cor de acento configurável (ver "Configurações"); cantos arredondados; tipografia Inter.
- Responsivo, mas pensado para desktop.

## Banco de dados (crie exatamente estes nomes de tabela e coluna)

1. profiles
- id uuid (pk, = auth.users.id), nome text, papel text ('admin' | 'editor', padrão 'editor'), created_at timestamptz.

2. marcas  (cada marca é um "kit" usado na edição)
- id text pk (slug, ex.: 'tylty', 'grupo-gratis')
- nome text
- cor_primaria text (hex), cor_destaque text (hex), cor_texto_sobre_primaria text (hex, padrão '#FFFFFF')
- logo_path text null (caminho no bucket 'marcas')
- aviso_legal text null (ex.: '+18 · Jogue com responsabilidade')
- palavras_forca text[] padrão '{}'
- glossario jsonb padrão '{}' (correções de transcrição: {"Gratis": "grátis"})
- ativa boolean padrão true
- updated_at timestamptz

3. jobs
- id uuid pk default gen_random_uuid()
- created_at timestamptz default now(), updated_at timestamptz default now()
- user_id uuid (dono, = auth.uid())
- titulo text (nome do arquivo ou nome dado pelo editor)
- marca_id text references marcas(id)
- modelo text default 'fala-legendada'
- estilo_legenda text default 'editorial'  — valores: 'impacto','caixa','palavra','karaoke','limpo','faixa','marca','elegante','editorial'
- cor_legenda text null — 'dourado','verde','azul','vermelho','rosa','roxo','prata' ou um hex '#RRGGBB'; null = usar a cor da marca
- ritmo_fala text default 'auto' — 'auto','normal','rapida'
- video_ja_editado boolean default false (true = não cortar pausas)
- revisar_texto boolean default true
- gancho text default '', cta_titulo text default '', cta_subtitulo text default ''
- video_bruto_path text (caminho no bucket 'brutos')
- status text default 'na_fila' — 'na_fila','transcrevendo','aguardando_revisao','aprovado','renderizando','pronto','erro'
- progresso int default 0 (0–100, escrito pelo worker)
- legendas jsonb null — array de palavras: [{"text":" palavra","startMs":1200,"endMs":1450}, ...] (escrito pelo worker; editado na revisão)
- destaques text[] default '{}' (palavras-chave marcadas pelo editor)
- video_final_path text null (caminho no bucket 'finais', escrito pelo worker)
- erro text null
- clickup_url text null

4. configuracoes (linha única, white-label)
- id int pk default 1, nome_portal text default 'Fábrica de Criativos', logo_path text null, cor_acento text default '#FFB020'

Storage (todos privados, acesso por URL assinada): 'brutos', 'finais', 'marcas'.

RLS:
- editor: vê/cria/edita apenas os próprios jobs; lê marcas ativas e configuracoes.
- admin: acesso total a jobs, marcas, configuracoes e profiles.
- O worker usa a service role (ignora RLS) — não crie nada específico para ele.
Ative Realtime na tabela jobs. Trigger para atualizar updated_at.

## Telas

1. Login — e-mail e senha (Supabase Auth). Mostrar nome e logo de "configuracoes".

2. Meus vídeos (início)
- Lista/grade de jobs, mais recentes primeiro: título, marca, estilo, data, badge de status colorido e barra de progresso (atualização em tempo real via Realtime).
- Status em português: Na fila, Transcrevendo, Aguardando sua revisão (destaque visual, botão "Revisar"), Aprovado, Renderizando, Pronto (botão "Baixar" com URL assinada do bucket 'finais' e player de prévia), Erro (mostrar texto de "erro" e botão "Tentar de novo" que volta o status para 'na_fila').
- Filtros por marca e status. Botão grande "Nova edição".
- Admin vê os jobs de todos, com o nome do editor.

3. Nova edição (assistente em etapas, com voltar/avançar)
- Etapa 1 — Marca: cards das marcas ativas (logo + nome + bolinha com a cor de destaque).
- Etapa 2 — Modelo: card "Fala legendada" (ativo; descrição: "Pessoa falando para a câmera: legenda dinâmica, cortes de pausa e tarja da marca"). Outros cards "Em breve" desabilitados: "React + copy", "Plantão / notícia", "Oferta com contagem".
- Etapa 3 — Estilo de legenda: grade de cards com nome e descrição (sem imagens por enquanto, deixe espaço para uma prévia):
  • editorial — Editorial: palavras de ligação pequenas e palavra-chave grande em serifada itálica com brilho. Impacto, autoridade, storytelling. (padrão)
  • impacto — Impacto: caixa alta pesada, contorno preto, palavra falada colorida. Anúncios e performance.
  • caixa — Caixa na palavra: caixa colorida corre atrás da palavra falada. Negócio e educativo.
  • palavra — Uma palavra: uma palavra por vez, enorme. Ganchos e energia alta.
  • karaoke — Karaokê: frase inteira, palavras acendem ao serem faladas.
  • limpo — Limpo: discreto, caixa baixa. Talking head e depoimento.
  • faixa — Faixa escura: texto sobre caixa escura. Fundos claros ou poluídos.
  • marca — Bloco da marca: texto sobre bloco na cor da marca. Institucional.
  • elegante — Elegante: serifada refinada. Lifestyle e premium.
- Etapa 4 — Cor do destaque: amostras clicáveis (Dourado #FFB020, Verde #5EE87F, Azul #4CC3FF, Vermelho #FF6A55, Rosa #FF7AC3, Roxo #C38BFF, Prata #E7E9EE), opção "Cor da marca" (salva null) e "Personalizada" com seletor de cor (salva o hex).
- Etapa 5 — Opções: switch "O vídeo já está editado (não cortar pausas)"; switch "Revisar o texto antes do render" (ligado por padrão); campos opcionais "Gancho (texto no início)", "CTA título", "CTA subtítulo"; seletor "Ritmo da fala" (Automático / Normal / Rápida, padrão Automático); campo opcional "Link da task no ClickUp".
- Etapa 6 — Upload: área de arrastar e soltar (mp4/mov, até 500 MB), barra de progresso do upload para o bucket 'brutos' no caminho {user_id}/{job_id}/bruto.{ext}; campo "Título" preenchido com o nome do arquivo.
- Ao concluir: cria o job com status 'na_fila' e volta para "Meus vídeos".

4. Revisão (aberta pelo botão "Revisar" quando status = 'aguardando_revisao')
- Esquerda: player do vídeo bruto (URL assinada).
- Direita: o texto transcrito exibido como sequência de palavras (chips) lidas de jobs.legendas, na ordem.
  • Clicar numa palavra leva o vídeo para o startMs dela.
  • Durante a reprodução, a palavra falada fica destacada.
  • Duplo clique edita o texto da palavra (pode virar mais de uma palavra, ex.: "desse" → "se isso"); preservar startMs/endMs; manter o espaço inicial do campo text.
  • Botão de estrela em cada palavra marca/desmarca como destaque (salva em jobs.destaques, sem pontuação, em minúsculas). Palavras marcadas aparecem com a cor de destaque escolhida.
  • Botão "Excluir" em cada palavra (remove do array).
- Mostrar a estimativa de ritmo: palavras por segundo = número de palavras / duração falada.
- Botões: "Salvar rascunho" (salva legendas e destaques) e "Aprovar e renderizar" (salva e muda status para 'aprovado').

5. Marcas (só admin)
- Lista e formulário de marca: id (slug), nome, as três cores com seletor, upload de logo para o bucket 'marcas', aviso legal, palavras-força (campo de tags), glossário (tabela de pares "o Whisper escreve" → "corrigir para"), ativa.

6. Configurações (só admin)
- Nome do portal, logo e cor de acento (white-label). Gestão de usuários: listar profiles e trocar papel editor/admin.

## Regras
- Nunca apagar arquivos dos buckets pelo app.
- Todos os textos, datas e mensagens em português do Brasil.
- Não criar Edge Functions de processamento; o app só lê e escreve nas tabelas e no storage.
```

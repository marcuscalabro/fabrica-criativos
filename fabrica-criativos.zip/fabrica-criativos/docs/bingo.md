# Modelo estático "Bingo" (v1)

Base: 7 bingos reais enviados em 03/11/2026. Composition: `Bingo` (src/modelos/estaticos/Bingo.tsx).

## Formatos
- **WhatsApp:** 1080×1080
- **RCS:** 1550×1036
- **E-mail (header):** 1800×900, proporção 2:1 como nas referências de e-mail (1802×901, 1673×837, 2183×1092)

## Padrão das referências
| Elemento | Padrão |
|---|---|
| Título | Caixa de cor sólida (azul, verde, escuro ou dourado) com brilho em volta. Dentro: **destaque gigante** ("ØDD 250") em condensada pesada itálica verde-neon, amarela ou branca, e embaixo uma linha branca em caixa alta. Abaixo da caixa, frase de apoio branca em itálico. |
| Escudos | Em pares (confronto): o 2º sobrepõe o 1º, levemente girados, com sombra. Ficam empilhados em zigue-zague ao lado do Tylty, ou numa fileira nos formatos largos. |
| Tylty | Foto recortada, grande, apoiada na base, com contorno de luz na cor do tema. Ele aponta ou olha para os escudos/título. |
| Bilhete | Print do bilhete em cartão com cantos arredondados e sombra (opcional). |
| Botão | Retângulo verde, texto em itálico condensado em caixa alta ("VER BILHETE"). |
| Aviso | Barra escura arredondada com: círculo branco "+18", texto em negrito "Jogue com responsabilidade. Ministério da Fazenda adverte: Aposta não é investimento.", portaria da casa em texto normal, selo da casa à direita e pílula "#PUBLICIDADE" encostada embaixo. |
| Fundo | Estádio escuro com a cor do tema. Quando o editor não envia fundo, a Fábrica monta um em código: gramado em perspectiva, refletores, granulação e vinheta. |

## Regras automáticas
- **ODD:** sempre censurado como "ØDD" (compliance).
- **Portaria:** puxada da casa escolhida:
  - MGM 2.098
  - BetGO 2.104-7
  - Superbet 2090/2024
  - Sportingbet 247
  - Bet365 250
  - Betano 246
  - Novibet 249/2025
  - MC Games 2.104-54
- **Tamanho da foto:** calculado pelo **rosto** (rosto ≈ 20% da largura no WhatsApp, 15% no RCS, 12,5% no e-mail), não pela altura da foto.
- **Lado da foto:** o Tylty fica do lado em que a foto foi cortada, para o corpo nunca terminar no meio da arte. Título, bilhete, botão e aviso espelham para o outro lado.
- **REGRA DO ROSTO:**
  - se o rosto encosta no título, a foto anda para fora do quadro (até 40%) e, se ainda precisar, diminui;
  - os escudos são empurrados para longe do rosto;
  - os escudos ficam sempre abaixo do título.
- **Textos:** se não couberem na largura, diminuem automaticamente, sem quebrar linha.

## Escudos disponíveis (public/escudos/indice.json — 160)
- **br/:** 20 clubes do Brasileirão em vetor (SVG, nitidez máxima).
- **sulamerica/:** participantes da Libertadores 2026 em vetor.
- **europa/:** 114 clubes de Inglaterra, Espanha, Itália, França, Alemanha e Portugal. São PNG pequenos (139 px) e ficam suaves em tamanho grande; trocar pelo pacote da OTG.

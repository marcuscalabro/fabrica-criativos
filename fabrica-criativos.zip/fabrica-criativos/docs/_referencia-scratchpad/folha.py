import cv2, json, sys, numpy as np, os
raiz = "/home/claude/fabrica-criativos/public/banco/tylty"
ids = sys.argv[2:]
saida = sys.argv[1]
cores = [(60, 140, 30), (150, 70, 20), (30, 30, 35)]
tiles = []
for i, id in enumerate(ids):
    r = cv2.imread(f"{raiz}/{id}/recorte.png", cv2.IMREAD_UNCHANGED)
    al = r[..., 3:] / 255.0
    bg = np.full(r[..., :3].shape, cores[i % 3], np.uint8)
    c = (r[..., :3] * al + bg * (1 - al)).astype(np.uint8)
    c = cv2.resize(c, (300, int(300 * c.shape[0] / c.shape[1])), interpolation=cv2.INTER_AREA)
    c = c[:450]
    c = cv2.copyMakeBorder(c, 0, 450 - c.shape[0], 0, 0, cv2.BORDER_CONSTANT)
    cv2.putText(c, id[:32], (6, 440), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1, cv2.LINE_AA)
    tiles.append(c)
while len(tiles) % 5:
    tiles.append(np.zeros_like(tiles[0]))
linhas = [np.hstack(tiles[i:i + 5]) for i in range(0, len(tiles), 5)]
cv2.imwrite(saida, np.vstack(linhas), [cv2.IMWRITE_JPEG_QUALITY, 88])

# Modelo "Criativo completo" (v1)

Edição completa de alta performance a partir de um vídeo de fala do expert.
Composition: `CriativoCompleto` (src/modelos/criativo-completo/CriativoCompleto.tsx).
Exemplo de props: public/jobs/cc-gg36/props.json

## O que entra na edição
| Camada | O que faz |
|---|---|
| Corte | Pausas removidas e áudio normalizado em -14 LUFS (pipeline `editar.mjs`) |
| Câmera | Punch-ins rápidos (170 ms) nas viradas da fala, alternando planos (1.00 / 1.07 / 1.13–1.15), mais uma aproximação contínua de 3,5%. O zoom é centrado no rosto, então o rosto nunca sai do quadro |
| Flash | Clarão de 5 quadros nas viradas de assunto (`camera[].flash`) |
| Cor | Contraste +8%, saturação +16%, vinheta e escurecimento na base para dar leitura |
| Legenda | Editorial (aprovado), com palavra-chave em destaque e modo fala rápida automático |
| Gancho | 2 linhas cinéticas nos primeiros ~2,6 s: palavras entram uma a uma e a 2ª linha vem num bloco de cor |
| Cards | Assuntos citados na fala (campeonatos, times) entram no instante em que são ditos; o card ativo fica na cor de destaque |
| Selo +18 | Entra quando o expert fala de idade ou responsabilidade |
| CTA | Botão pulsando com brilho passando + frase de apoio; segura até o fim |
| Cartela final | Congela o último quadro, segue aproximando e escurece levemente; o CTA continua (`cta.cartelaSeg`) |
| Som | Whoosh no gancho e nos punch-ins, pop nos cards e no selo, impacto no CTA, tique no fim; trilha de fundo baixa |
| Base | Aviso legal OTG em linha com "+18" e barra de progresso na cor de destaque |

## Regra do rosto
A zona protegida é recalculada amostra por amostra com o zoom da câmera naquele instante, considerando ±220 ms.
A legenda recebe gancho, cards, selo e CTA como obstáculos com início e fim, e se reposiciona.
Todos os elementos ficam na faixa abaixo do rosto. Para conferir, renderize com `mostrarZona: true`.

## Decisões editoriais por vídeo (props)
- `camera`: lista de `{ms, zoom, flash?}`. Regra prática: punch-in no começo de cada frase forte e volta para 1.0 com flash na troca de assunto.
- `gancho`: texto curto que reforça a promessa do vídeo, sem repetir a primeira frase.
- `cards`: palavras concretas faladas (campeonatos, jogo, número), com o `ms` da palavra.
- `selo18`, `cta`: tempos tirados da transcrição.
Hoje essas decisões são tomadas pelo Claude lendo a transcrição. O próximo passo é o pipeline sugerir isso sozinho.

## Sons
public/sfx/ guarda whoosh, pop, impacto, tique e trilha. Todos foram sintetizados localmente com ffmpeg, sem banco externo.
A trilha é provisória: troque pelo banco de músicas licenciadas da OTG.

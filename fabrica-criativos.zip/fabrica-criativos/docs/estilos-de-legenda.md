# Estilos de legenda — pesquisa e catálogo

Atualizado em 26/10/2026. Código: `src/modelos/fala-legendada/estilos.ts`.

## O que a pesquisa mostrou

- O Captions não publica a especificação visual de cada template. A documentação oficial lista os ajustes que compõem um estilo: fonte, alinhamento, espaçamento, caixa alta, cor do texto, cor de ênfase, cor da palavra ativa, fundo atrás da palavra ativa, fundo atrás da legenda, transições, palavras por página e linhas por página, rotação aleatória, emojis e ênfase automática por IA. ([Captions: estilos](https://captions.ai/help/docs/captions/styles.md))
- O guia oficial de escolha de estilo agrupa os templates por tipo de conteúdo. ([Captions: escolhendo um estilo](https://captions.ai/help/guides/engagement/choosing-a-style.md))
  - Talking head e educativo: Clarity, Core, Byline. Fonte limpa, pouca animação, frases curtas.
  - Motivacional: Rocket, Grit, Kai. Texto grande e pesado, palavra ativa colorida, palavra a palavra.
  - Entretenimento: Film, Prism. Expressivo, uma palavra ou frases muito curtas.
  - Profissional e LinkedIn: Byline, Sonnet, Blueprint. Limpo, quase sem animação, cor da marca.
  - Beleza e lifestyle: Sonnet, Analog. Elegante, serifada ou sans refinada.
  - Anúncios: Rocket, Grit. Alto contraste, frases curtas, leitura num relance.
- Fora do Captions, os padrões que se repetem nos apps do mesmo tipo são: destaque em cor de uma palavra-chave; palavra a palavra com pop; bloco escuro atrás da frase; bloco na cor da marca no terço inferior; caixa colorida atrás da palavra falada ("estilo Hormozi", em caixa alta e com sombra forte); e karaokê. Branco com contorno preto é citado como o mais usado. ([Blitzcut](https://blitzcutai.com/blog/best-caption-style-tiktok), [ClipSpeed](https://www.clipspeed.ai/tools/caption-style-preview.html), [Submagic](https://www.submagic.co/blog/how-to-make-alex-hormozi-captions))
- Boas práticas recorrentes: sempre contorno ou sombra; terço inferior-médio, longe dos botões da direita; texto grande; palavra a palavra tende a reter mais do que frase inteira.

## Catálogo da fábrica

| ID | Nome | Família equivalente | Usar para |
| --- | --- | --- | --- |
| `impacto` | Impacto | Rocket, Grit | Anúncios, performance |
| `caixa` | Caixa na palavra | estilo "Hormozi" | Negócio e educativo com ritmo alto |
| `palavra` | Uma palavra | Film, Prism | Entretenimento, energia alta, ganchos |
| `karaoke` | Karaokê | Karaoke | Frases de efeito, motivacional |
| `limpo` | Limpo | Clarity, Core | Talking head, depoimento |
| `faixa` | Faixa escura | Subtitle Block | Fundo claro ou poluído, institucional |
| `marca` | Bloco da marca | Byline, Blueprint | Profissional, marca forte |
| `elegante` | Elegante | Sonnet, Analog | Lifestyle, premium, benefícios do clube |

Os estilos são recriações próprias a partir dessas descrições: usam fontes livres (Montserrat, Anton, Inter, Playfair Display) e as cores vêm do kit de cada marca.

## Como usar

```bash
node scripts/editar.mjs --video bruto.mp4 --marca <kit> --estilo karaoke ...
```

## Próximos estilos possíveis

Emojis por palavra-chave, ênfase com palavra ampliada (supersize), sublinhado animado e legenda com movimento automático acompanhando o rosto.

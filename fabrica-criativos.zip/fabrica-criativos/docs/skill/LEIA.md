# Skill "fabrica-de-criativos"

Proposta ao Mv em 16/11/2026 pelo cartão de revisão do Claude. O texto oficial é o que ele salvar na conta; esta nota só registra que a skill existe e o que ela cobre: regras inegociáveis, preparo do ambiente, leitura do pedido do hub, passo a passo por modelo, compliance OTG, regras do Gol da Virada e entrega.

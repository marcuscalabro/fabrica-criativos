# Variação (teste A/B de hook, corpo ou CTA)

O editor sobe o **criativo pronto** e o **trecho novo bruto**, só a fala nova sem edição, e escolhe o que trocar: **Hook**, **Corpo** ou **CTA**.
A Fábrica emenda o trecho novo no lugar certo, com a mesma edição do original.

```
node scripts/variacao.mjs --original criativo.mp4 --novo trecho.mp4 --parte cta|hook|corpo --marca <kit> [--cta-texto "..."]
```

## 1. Onde fica cada parte (`acharTrechos`, em planejar-edicao.mjs)
- **Hook**: 1ª frase da fala, no máximo ~4,2 s. Se a 1ª frase for muito curta, junta com a 2ª.
- **CTA**: começa no início da frase do último gatilho de ação (link, entra, clica, comenta, bio…) dentro do trecho final. Sem gatilho, vale a última frase.
- **Corpo**: tudo entre os dois.

## 2. O trecho novo passa pela entrada padrão da Fábrica
Corte de pausas, 1080x1920, áudio em -14 LUFS, transcrição local e zona do rosto.

## 3a. Caminho EXATO (original feito na Fábrica)
Todo vídeo da Fábrica sai com a etiqueta `fabrica-job=<id>` no arquivo. Nesse caso, a Variação:
- emenda os vídeos limpos;
- junta as legendas;
- refaz a zona do rosto;
- **replaneja** com as mesmas regras, mantendo o gancho/capa e o botão do original;
- renderiza com o mesmo modelo, nível, estilo, cor e kit (no avançado, refaz o recorte).

A emenda fica invisível porque a edição é a mesma do começo ao fim.
No teste de CTA, o botão entra na emenda e o selo +18 é encurtado para não encostar nele.

## 3b. Caminho ANÁLISE (original de fora)
`scripts/analisar-criativo.py` estuda a parte do original que fica:

| O que mede | Como usa no trecho novo |
|---|---|
| Rosto: tamanho e posição | Escala e desloca o trecho novo para o rosto ficar igual |
| Cor (média e contraste em Lab) | Transfere a cor do original |
| Elementos fixos (aviso legal, selo, logo) | Recorta em PNG e cola por cima, idêntico |
| Legenda: faixa, tamanho da letra, cor do destaque, caixa ou tamanhos mistos | Escolhe o estilo mais próximo (editorial, caixa, impacto ou limpo) e põe na mesma altura e cor |
| Volume | Ajusta o trecho novo ao LUFS do original |
| CTA (só na troca de CTA) | Recorta o botão e a frase de apoio do original e põe no trecho novo, no mesmo atraso. Detecta a cartela final (quadro parado) e repete com a mesma duração |

**REGRA DE FOCO:** quando o botão entra, a legenda sai, igual ao original.

## Limites
- **Caminho análise:** o botão copiado mantém o texto do original. Trocar o texto do botão só funciona com original feito na Fábrica.
- **Caminho análise:** motions que aparecem só no corpo do original (cards, títulos) não são recriados no trecho novo. Só a legenda, os elementos fixos e o CTA são reproduzidos.
- **Trecho novo:** precisa ser gravado no mesmo cenário e com a mesma roupa, senão a troca aparece.

# Regras de produção da Fábrica de Criativos

Valem para todo modelo, todo estilo e todo vídeo — atual ou futuro.

## 1. Nada na frente do rosto do expert (regra primordial)

Nenhum texto, legenda, headline, print, imagem, sticker/emoji, logo, tarja, sombra
ou elemento gráfico pode ficar na frente do rosto do expert, em nenhum quadro.

Como é garantido:

- `scripts/detectar-rosto.py` detecta o rosto ~6 vezes por segundo (OpenCV, local) e
  grava `rostos.json` com a **zona protegida**: o rosto mais folga para cabelo/testa
  (55% acima), queixo/barba (40% abaixo) e laterais (35%). O pipeline roda essa etapa
  sempre; sem detector instalado, o pipeline para (só passa com `--sem-rosto`).
- `src/zona-protegida.tsx` é o módulo comum que todo modelo usa:
  - `zonaNoIntervalo` — união das zonas durante o tempo em que o elemento aparece;
  - `posicaoLivre` / `alocar` — escolhe a posição fora da zona (e de outros
    elementos) e, se não couber, encolhe o elemento;
  - `ampliarRostos` — quando o modelo dá zoom no vídeo, a zona cresce junto;
  - `ZonaDebug` / `ZonaDebugNoTempo` — desenha a zona para conferência (`--mostrar-zona`).
- Por modelo:
  - **Fala legendada:** cada página/bloco de legenda é posicionado fora da zona do
    rosto durante todo o seu tempo; o gancho desvia do rosto e as legendas desviam
    do gancho; o logo vai para o primeiro canto livre (ou não entra); a tarja legal
    sobe para o topo se o rosto chegar embaixo.
  - **Fundo aleatório:** o bloco de headline fica no maior espaço livre; se não
    couber, encolhe até 82%; se ainda não couber, **o vídeo de fundo desce** e o topo
    vira área de texto (preenchido com o próprio fundo desfocado), com o aviso legal
    logo abaixo do texto. Stickers que encostariam no rosto vão para a lateral livre
    ou saem.
- Modelo novo só entra na fábrica depois de passar por um render com `--mostrar-zona`.

## 2. Compliance de apostas

Toda copy de apostas segue o checklist de compliance da OTG (palavras proibidas,
censuras, CTA sem "grupo grátis" e sem chamada para apostar, aviso +18). O status
máximo que a fábrica dá é "pronto para revisão de compliance"; a aprovação é da Júlia.

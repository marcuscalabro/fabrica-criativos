# Fábrica de Criativos — memória do projeto

Projeto do Mv (Marcus, Grupo OTG), migrado em 16/11/2026 de outra conta. Conversa original: 22/10 a 04/11/2026.
Histórico completo: anexos `Fabrica-de-Criativos.md` (conversa) e `Fabrica-de-Criativos-arquivos-criados.md` (código).
Quando houver conflito, vale a decisão mais recente.

## O que é
- Portal **white-label** do Grupo OTG para a equipe de **editores**. O editor escolhe um modelo, sobe o material (vídeo bruto, fotos, copy) e recebe o criativo editado pronto.
- O "motor" é este projeto: modelos em **Remotion** (vídeo e estáticos) + scripts de pipeline (ffmpeg, Whisper local, OpenCV, recorte local).
- Marca principal nos testes: **Lucas Tylty** (@lucastylty), tipster; conteúdo de **apostas** (Grupo Grátis, casas MGM, BetGO, Superbet etc.). Origem da ideia: clube de benefícios + assinatura.
- Fase atual: **teste no chat**. Depois de otimizado, vai para os editores (inicialmente sem API da Anthropic; regras fixas + planejador automático. API do Claude fica para depois).

## Regras inegociáveis
1. **REGRA PRIMORDIAL: nada na frente do rosto do expert.** Nenhum texto, legenda, headline, print, emoji, logo, tarja, sombra ou elemento, em nenhum quadro. Rosto detectado (~6x/s) → zona protegida (+55% topo, +40% baixo, +35% lados) → tudo se posiciona fora. Sem detector instalado, o motor não renderiza. Modelo novo só entra depois de render com `--mostrar-zona`. Vale também para estáticos (foto anda/encolhe, escudos são empurrados).
2. **REGRA DE FOCO: um elemento por vez, centralizado.** Legenda OU motion na frente, nunca os dois. Motion entra numa fala, legenda volta na seguinte. Ficam no centro, logo abaixo do rosto (nunca motion lá embaixo). Palavras faladas durante um motion não viram legenda. Sem barra de progresso; na base só o aviso legal. Poluição visual derruba conversão. Alternativa aprovada: legenda simples na frente + motions **atrás** do expert (recorte).
3. **Sem IA generativa externa.** Toda edição sai do Claude + skills/ferramentas locais (Remotion, ffmpeg, Whisper local, OpenCV, U2Net local). Nada de imagem gerada, rosto/escudo/texto inventado. Estáticos montados em camadas como um designer, com fotos, escudos e fontes reais. Não instalar binário de origem desconhecida.
4. **Compliance de apostas OTG.** Palavras como grátis, lucro, ganho, dinheiro, aposta, bet, green, banca nunca viram título/card/faixa. Sem "grupo grátis" no CTA, sem chamada para apostar, sem promessa de resultado nem histórico de acertos, "ODD" → "ØDD", aviso +18. Escassez ("vagas acabando") bloqueada. Bilhete: data borrada, sem valores em R$. Status máximo da Fábrica: **"pronto para revisão de compliance"**; aprovação é da **Júlia**. Números (ex.: "300 mil") precisam ser reais. Patrocínio na camisa (Spotify, VW) → confirmar com a Júlia.
5. **Qualidade de designer profissional** em todo estático. Sem "cara de IA".
6. **Decupagem: tolerância zero a erro.**
7. **Honestidade sobre o que foi conferido**: dizer o que foi checado quadro a quadro e o que não foi. Eu não ouço áudio: fala precisa virar texto (Whisper local). Nunca dizer que legendei algo que não transcrevi.

## Modelos
### Criativos em vídeo
- **Criativo completo** (1º no portal). Edição completa de alta performance: corte, câmera (punch-ins centrados no rosto, flash nas viradas), cor, legenda Editorial, gancho de abertura, cards dos assuntos no momento da fala, selo +18, CTA pulsando, cartela final congelada, sons (whoosh/pop/impacto, trilha provisória sintetizada), aviso legal. Dois níveis:
  - **Médio** (v2 aprovado): regra de foco, um elemento por vez no centro.
  - **Avançado** (aprovado, padrão no portal): expert recortado (U2Net local) → motions **atrás** dele: título capa de revista, chuva de bolas, faixas inclinadas, onda de cor, raios, fundo escurece/desfoca + contorno de luz, borrão de movimento, tremor. ~7 min a mais por vídeo.
  - **Planejamento automático** (`planejar-edicao.mjs`): decide zooms, cards, títulos, selo, CTA a partir da transcrição, em <1 s. Editor pode escrever chamada/botão ou deixar em branco.
- **Variação**: troca **Hook**, **Corpo** ou **CTA** de um criativo pronto (teste A/B). Caminho EXATO (original da Fábrica, etiqueta `fabrica-job`) refaz a edição inteira; caminho ANÁLISE (original de fora) copia enquadramento, cor, volume, estilo de legenda, camada fixa, botão do CTA e cartela. Testado só com trecho simulado.
- **Fala legendada**: legenda dinâmica, corte de pausas, 9:16, -14 LUFS, glossário por marca, palavras-força. 9 estilos: impacto, caixa, palavra, karaoke, limpo, faixa, marca, elegante, **editorial** (aprovado "100%").
  - Editorial: ligação em sans pequena caixa baixa + palavra-chave grande em Instrument Serif itálica, degradê e brilho; entrada letra a letra com desfoque; saída com desfoque.
  - **Modo fala rápida** automático a partir de 3,3 palavras/s: saída só até 75% de opacidade, quase sem desfoque, letras entram quase juntas, bloco fica mais tempo. Linhas pequenas longas quebram em duas.
  - **Cor do destaque**: dourado (padrão), verde, azul, vermelho, rosa, roxo, prata + hex personalizado (degradê calculado).
- **Fundo aleatório** (v2): vídeo de tipster nítido como fundo (só escurecido/tingido, áudio original), headline FIXA no topo (digitando na entrada, depois parada), print de prova, linha de apoio, faixa, botão contornado "VEM PRO GRUPO", emojis, aviso "+18 · Ministério da Fazenda adverte" + #PUBLICIDADE. Temas: faixa-amarela (S4, Bebas), neon (S1), limão (S2, Poppins). Uso típico: bingos. Se não couber fora do rosto, o vídeo desce e o topo vira área de texto. Falta: recorte de reação (rosto no canto).
- **Decupagem**: bruto entra, sai 100% decupado (só cortes, mesma resolução/fps/cor). Blocos de fala pelo áudio, transcrição bloco a bloco, takes e repetições pelo SOM (MFCC 20 ms), vale a última tentativa, respiros cortados inteiros (separa respiro de consoante), "é" só sai solto entre pausas, ritmos rápido/natural/solto, render em pedaços (sem estourar memória), fade 8 ms nas emendas, conferência independente com alertas → volta ao editor. **1104 (65 s → 25,8 s) aprovado como padrão de referência**. "que que" e "ó" mantidos como fala natural.
- *(Fundo + copy v1: primeira tentativa, substituída pelo Fundo aleatório v2.)*
- Ideias ainda não feitas: React + copy, Ganchos A/B, Troca de jogo (Ajuste), Plantão/notícia, Multiformato, Oferta/benefício (clube).

### Criativos estáticos
- **Tweet** (v2, padrão OTG real): fundo branco liso, conteúdo na faixa central do 9:16 (y≈380–1540), variantes `perfil` e `manchete`, foto em quadro separado de cantos arredondados (nada sobre a foto), botão retangular cheio com 👇 (vermelho, roxo/verde, azul, rosa), aviso legal OTG em linha com "+18". Sem logo de rede social nem números de curtidas.
- **Bingo** (v3): formatos WhatsApp 1080×1080, RCS 1550×1036, E-mail/Header 1800×900. Campos: casa + selo, copy (destaque, linha, apoio, botão), foto do Tylty (banco ou upload), escudos (160, pares por clique), formato, fundo (Fábrica escolhe ou editor envia), bilhete opcional, cor. Fonte **Anton** (número com sombra 3D), apoio/botão em itálico; caixa de título justa; Tylty em altura total, cabeça perto do topo, contorno de luz; escudos encavalados logo após o dedo; fundos = 4 fotos de estádio (Unsplash) desfocadas/tingidas; granulação leve. Tamanho da foto pelo rosto; lado pelo corte/gesto (aponta para a direita → foto à esquerda). Portarias por casa em docs/bingo.md.
- **Banco de imagens do Tylty**: 58 fotos de estúdio recortadas (lotes de 20 + 20 + 18), classificadas por pose, camisa, enquadramento, qualidade e lado; rosto mapeado em todas (detector com 2ª tentativa mais sensível). Galeria com filtro no portal.
- **Removido**: Nota oficial (03/11, a pedido).
- Próximos estilos de estático anotados: Foto escura + manchete (com escudos); Recorte em fundo branco.

## Portal (protótipo publicado como Artifact na conta antiga)
Primeiro passo: "O que você vai criar?" → **Criativos em vídeo** (padrão: Criativo completo, Variação, Fala legendada, Fundo aleatório, Decupagem) ou **Criativos estáticos** (Tweet, Bingo). Depois: modelo → envio → ajustes → "Gerar criativo" → fila (simulada). Precisa de tela de **revisão da transcrição** antes do render (Whisper erra frases: "desse faz sentido" → "se isso faz sentido").

## Arquitetura planejada
- **Site**: Lovable (atalho aceito pelo Mv) ou React na Vercel (Pro p/ uso comercial). Prompt do Lovable em `docs/prompt-lovable.md` (desatualizado).
- **Supabase**: Auth, tabelas `profiles`, `marcas` (kits: cores, logo, aviso, palavras-força, glossário), `jobs` (status na_fila → transcrevendo → aguardando_revisao → aprovado → renderizando → pronto/erro), `configuracoes` (white-label); buckets `brutos`, `finais`, `marcas`; Realtime em jobs. Plano Pro (limite de 50 MB no grátis).
- **Worker**: máquina sempre ligada (VPS 4–8 núcleos, ~US$ 20–50/mês, recomendado; ou Mac no escritório) com Node, Chrome, ffmpeg, Whisper local, OpenCV, U2Net. `worker.mjs` (ainda não escrito) lê a fila com a service role (em `.env`, nunca no chat).
- Licença Remotion de empresa necessária (> 3 pessoas, a partir de US$ 100/mês).

## Feedback de qualidade do Mv (não repetir)
- Copiar o padrão **real** das referências OTG, não inventar layout (Tweet v1 estava "bem diferente do verdadeiro modelo").
- Fundo aleatório é headline fixa sobre vídeo nítido, não telas animadas sobre fundo desfocado.
- Informação demais polui e derruba conversão; motions não podem ficar lá embaixo com legenda no meio.
- Bingo v1: dedo do Tylty cortado, escudos mal posicionados, fonte feia, espaços ruins. v2 ainda fraco. v3 "ficaram melhores". Sempre: mão inteira, corpo encostando na borda, escudos onde o dedo aponta, tipografia medida para preencher a caixa.
- Recorte de fotos "delicado/perfeito": cabelo e barba soltos, sem halo branco, camisa branca sem ser comida, elementos da parede fora.
- Fala rápida: legenda precisa continuar legível (menos opacidade na saída só nesses vídeos).
- Decupagem: usar bruto real, não vídeo já editado; não confundir fala natural com erro.
- Não pedir passos manuais que já foram resolvidos antes (ex.: transcrição local funciona sem .srt).

## Onde paramos (04/11/2026)
Decupagem aprovada ("ficou perfeito"). Todos os modelos acima funcionavam no ambiente antigo.

## Próximos passos pendentes
1. Reconstituir o ambiente (package.json, fontes, kits, assets, modelos de IA, venv) — o export não trouxe binários nem as edições feitas via terminal.
2. Ligar portal ↔ Supabase ↔ worker (escrever `worker.mjs`, SQL, atualizar prompt do Lovable com todos os modelos).
3. Tela de revisão da transcrição no portal.
4. Pendências de material: selos das casas (PNG), escudos europeus em alta, banco de fundos/trilhas licenciadas, mais brutos com outros erros (palavra trocada, "é…" alongado, risada, ruído), CTA novo gravado para a Variação, foto do Tylty à direita para Bingo, tamanho real do e-mail (fixado 1800×900).
5. Confirmar com a Júlia: expressões das referências ("buscar retorno", "entrar grátis", escassez), bilhete com valores, patrocínios nas camisas.

## Estado dos arquivos recriados (16/11/2026)
Recriados de `arquivos-criados.md`, que só tem as versões das ações Write/Edit. **Desatualizados** (edições feitas por terminal se perderam): `src/Root.tsx` (só FalaLegendada), `src/kit.ts`, `FalaLegendada.tsx`, `Legenda.tsx` (usa Fragment sem import), `LegendaEditorial.tsx` (sem fala rápida, paleta e rosto), `zona-protegida.tsx` (sem `alocar`, `ampliarRostos`, `ZonaDebugNoTempo`), `editar.mjs` (sem rosto, estilo, cor, `--modelo completo`, planejador), `FundoAleatorio.tsx` (sem regra do rosto), `decupar.py` e `docs/decupagem.md` (sem os ajustes do 1104), `NotaOficial.tsx` (removido depois), protótipo do portal em `docs/_referencia-scratchpad/fabrica-src.html` (1ª versão). **Ausentes**: package.json/tsconfig/src/index.ts/remotion.config, `scripts/resolver-banco.mjs`, `docs/banco-de-imagens.md`, todo `public/` (fontes, kits, jobs/props, sfx, escudos, banco, fundos), `modelos-ia/` (Whisper-small ONNX, u2net_human_seg.onnx), `.venv-visao`.

## Hub e Estúdio de IA: descartados (16/11/2026)
Foi montado um protótipo de hub com um "Estúdio de IA" (geração por chave de API via fal.ai e Google). O Mv mandou **remover a aba de IA** no mesmo dia. O **hub continua existindo** só com Início + Fábrica de Criativos (`hub/hub.tpl.html` + `portal/index.html` → `python3 hub/build.py`). O código do Estúdio ficou só no histórico do git.
Motivo, com dados da conta Higgsfield do grupo (plano Ultra anual US$ 1.548, 3.000 créditos/mês; recarga US$ 50 por 1.000 créditos; ~US$ 450 em recargas de 1 a 13/11):
- Seedance 2.5, 30 s, 1080p: ~480 créditos = US$ 20,64 a 24,00 no Higgsfield contra ~US$ 34,92 na fal.ai.
- 19 dos 24 vídeos recentes são Cinema Studio 4.0 (80 créditos por 5 s), modelo exclusivo do Higgsfield, sem API.
- Kling 3.0, 5 s: 30 créditos (4K) contra US$ 0,70 na fal; pouco peso no uso.
- A economia real está em reduzir tentativas no modelo caro (rascunho no Kling ou Unlimited mode, final no Cinema Studio).
Não voltar a propor API direta ou plataforma própria de geração sem dado novo. PDF para a liderança: `analise-apis-vs-higgsfield.pdf`.

## Hub: seletor de produto (16/11/2026)
"Fábrica de Criativos" no hub abre dois botões com logo: **OTG Partners** (a Fábrica atual, Tylty e casas de aposta) e **Gol da Virada** (produto próprio do grupo, com configurações próprias). Rotas: `#fabrica` (seletor), `#otg-partners`, `#gol-da-virada`.
- O portal ficou ciente da marca: `window.fabricaAplicarMarca({nome, tag, expert, fotos, modelos, cta})`.
- Gol da Virada tem painel de configurações (cor de destaque, expert, CTA padrão, palavras-força, aviso legal, glossário, modelos ativos), salvo no navegador. **Valores reais ainda não definidos pelo Mv**: logos dos dois produtos (hoje são siglas provisórias), cores, expert, aviso legal, regras de compliance e banco de fotos do Gol da Virada. A cor verde e a sigla "GV" são provisórias.
- Hoje a configuração só afeta o protótipo (cor, CTA padrão, modelos visíveis, banco vazio). A fila de produção ainda é única e simulada.
- **Gol da Virada tem só Criativos estáticos** (decisão do Mv, 16/11/2026): sem a seção de vídeo; modelos possíveis Tweet e Bingo. A fila de produção passou a ser separada por produto.
- **Gol da Virada é 100% composto com elementos próprios** (Mv, 16/11/2026): os pets da marca, Ronaldinho, e o conhecimento dos criativos passados. Nada do OTG Partners (Tylty, casas, layouts) entra nessa área. O hub tem a "Base do Gol da Virada" com 4 bancos: Nossos pets, Ronaldinho, Criativos passados, Identidade visual. **Nenhum material chegou ainda.** "Treinar" aqui = guardar os assets em `public/` + documentar o padrão em `docs/` (como foi feito com o Tylty em docs/estaticos-otg.md e docs/bingo.md), não treinar modelo. Os modelos Tweet e Bingo no Gol são provisórios: os modelos reais saem da análise dos criativos passados. Ronaldinho: usar só fotos reais aprovadas no contrato de imagem; nunca gerar ou alterar a imagem dele.

## Claude na conta de cada usuário (decisão do Mv, 16/11/2026)
A Fábrica deve usar o Claude **da conta de quem está usando**, gastando o uso dessa pessoa, e não uma chave central.
- Implementado no hub publicado como Artifact, com a capacidade `sample` (`capabilities: {sample: {}}`): `claude.use("sample")` → `sample.json(prompt)`. Gasta o uso do próprio visualizador e pede consentimento na primeira chamada. Fora do claude.ai (arquivo local) a função fica desativada.
- Primeiro uso: botão "Escrever a copy com o Claude" em Tweet, Bingo e Fundo aleatório (código em `portal/index.html`, `blocoClaude`). Regras de compliance vão dentro do prompt (OTG: `REGRAS_OTG`; Gol da Virada: montadas da configuração do produto).
- **Testado só com um Claude simulado.** A chamada real só roda no navegador do usuário; ninguém confirmou ainda.
- Limites: assinatura do claude.ai e API (Console) são cobranças separadas; a assinatura não vira chave de API. O render de vídeo (Remotion, ffmpeg, Whisper) roda no worker e não gasta uso do Claude. Próximos candidatos a usar o Claude do usuário: revisão da transcrição, escolha de palavras-chave, checagem de compliance, planejamento do Criativo completo.

## Render pelo Claude do usuário + Central de dúvidas (decisão do Mv, 16/11/2026)
**Substitui a arquitetura de worker central** (Supabase + máquina de render): o render dos vídeos também roda no Claude da conta de cada usuário (Cowork ou Claude Code com o plugin Remotion e o projeto `fabrica-criativos`).
- No hub, "Gerar criativo" não simula mais render: monta um **pedido pronto** (produto, modelo, configuração, etapas, regras) que o usuário cola numa tarefa do próprio Claude (`montarPedido` em `portal/index.html`).
- Nova seção **Central de dúvidas** (`#ajuda`): como funciona, o que instalar (Cowork/Claude Code, plugin Remotion, projeto, skill de copy da OTG, pasta conectada), dicas de desempenho e perguntas frequentes.
- Pendências para isso funcionar de verdade: (1) projeto num repositório que os editores acessem (GitHub ainda não conectado); (2) motor reconstituído (versões perdidas na migração, package.json, assets); (3) a skill de copy da OTG existia na conta antiga (`copywriter-otg`) e não foi migrada; (4) uma skill própria da Fábrica ainda não existe (oferecida ao Mv, não criada); (5) caminho exato do menu para instalar plugin/skill não foi verificado.
- **Skill `fabrica-de-criativos`** proposta ao Mv em 16/11/2026 (cartão de revisão; só vale depois que ele salvar e distribuir aos editores). A Central de dúvidas já a lista como instalação obrigatória, junto com o plugin Remotion e o projeto. A skill de copy da OTG saiu da lista: as regras de compliance foram para dentro da skill da Fábrica.

## Hospedagem provisória (16/11/2026)
- Pasta `site/` = só o `index.html` do hub + `vercel.json` (sem indexação em buscadores). Gerada por `python3 hub/build.py`. Na Vercel: importar o repositório e definir Root Directory = `site`, sem build.
- GitHub do Mv conectado (conta `marcuscalabro`), mas a sessão do Claude não consegue **criar** repositório nem acessar repositório que não esteja anexado à tarefa. O Claude também não tem acesso à Vercel. Criar o repositório e o projeto na Vercel é passo manual do Mv.
- Fora do claude.ai, o botão "Escrever a copy com o Claude" fica desativado.
